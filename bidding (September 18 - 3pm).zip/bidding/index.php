<?php
session_start();

if (($_GET['action'] ?? '') === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    require_once __DIR__ . '/dbconn.php';
    require_once __DIR__ . '/mailer/includes/send_mail.php';

    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $email     = trim($input['email'] ?? '');
    $password  = (string) ($input['password'] ?? '');
    $remember  = (bool) ($input['remember'] ?? false);
    $asCreator = (bool) ($input['asCreator'] ?? false);
    $role      = $asCreator ? 'creator' : 'bidder';

    $errors = [];

    if ($email === '') {
        $errors['email'] = 'Enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address.';
    }

    if ($password === '') {
        $errors['password'] = 'Enter your password.';
    }

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }

    // Admin sign-in lives on its own page (admin/login.php) with its own
    // rate limiting, deliberately kept separate from this shared endpoint —
    // this handler only ever authenticates bidder/creator accounts.
    $stmt = $conn->prepare(
        'SELECT id, first_name, email, password_hash, is_verified FROM users WHERE email = ? AND role = ? LIMIT 1'
    );
    $stmt->bind_param('ss', $email, $role);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Same error either way — don't reveal whether the email exists.
    if (!$user || !password_verify($password, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'errors' => ['password' => 'Incorrect email or password.']]);
        exit;
    }

    if ((int) $user['is_verified'] === 0) {
        // Never finished verifying — send a fresh code and route back to it
        // instead of leaving them on a confusing "wrong password" message.
        $otp        = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $otpHash    = password_hash($otp, PASSWORD_DEFAULT);
        $otpExpires = date('Y-m-d H:i:s', time() + 10 * 60);

        $upd = $conn->prepare('UPDATE users SET otp_code_hash = ?, otp_expires_at = ? WHERE id = ?');
        $upd->bind_param('ssi', $otpHash, $otpExpires, $user['id']);
        $upd->execute();
        $upd->close();

        send_email(
            $email,
            'Your CanvasBid verification code',
            "<p>Hi {$user['first_name']},</p><p>Your CanvasBid verification code is:</p><h2>{$otp}</h2><p>This code expires in 10 minutes.</p>"
        );

        $_SESSION['pending_verification'] = [
            'user_id' => $user['id'],
            'email'   => $email,
            'role'    => $role,
        ];

        echo json_encode([
            'success'           => false,
            'needsVerification' => true,
            'redirect'          => 'verify.php',
        ]);
        exit;
    }

    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_role']  = $role;
    $_SESSION['user_email'] = $user['email'];

    if ($remember) {
        setcookie(session_name(), session_id(), time() + 30 * 24 * 60 * 60, '/');
    }

    echo json_encode([
        'success'  => true,
        'role'     => $role,
        // Creator dashboard now lives inside this SPA's router; bidder side isn't converted yet.
        'redirect' => $role === 'creator' ? '/creator/dashboard' : 'bidder/bidder_dashboard.php',
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CanvasBid</title>
    <script src="js/vue.global.js"></script>
    <script src="js/vue-router.global.js"></script>
    <script src="js/tailwind.js"></script>
    <script src="js/sweetalert2@11.js"></script>
    <script src="js/tabulator.min.js"></script>
    <link rel="stylesheet" href="css/tabulator.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        serif: ['Georgia', 'Cambria', 'Times New Roman', 'Times', 'serif'],
                        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    },
                },
            },
        };
    </script>
    <style>
        [v-cloak] {
            display: none;
        }

        .bg-canvas-art {
            background-image: url('images/sunflower.jpg');
            background-size: cover;
            background-position: center;
            background-color:
                #0B1526;
        }

        .bg-bidder-art {
            background-image: url('images/collage.png');
            background-size: cover;
            background-position: center;
            background-color:
                #0B1526;
        }

        .art-vignette {
            background:
                linear-gradient(180deg, rgba(6, 10, 20, 0.35) 0%, rgba(6, 10, 20, 0.25) 35%, rgba(6, 10, 20, 0.55) 65%, rgba(6, 10, 20, 0.82) 100%),
                rgba(6, 10, 20, 0.28);
        }

        .field-input {
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .field-input:focus {
            outline: none;
            border-color:
                #0F2245;
            box-shadow: 0 0 0 3px rgba(15, 34, 69, 0.12);
        }

        @keyframes canvasbid-spin {
            to {
                transform: rotate(360deg);
            }
        }

        .canvasbid-spin {
            animation: canvasbid-spin 0.8s linear infinite;
            transform-origin: center;
        }

        @media (prefers-reduced-motion: reduce) {
            *:not(.canvasbid-spin) {
                animation: none !important;
                transition: none !important;
            }
        }

        .canvasbid-swal-popup {
            border-radius: 16px !important;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
        }

        .canvasbid-swal-title {
            font-family: Georgia, Cambria, 'Times New Roman', Times, serif !important;
            color:
                #101828 !important;
            font-size: 1.375rem !important;
        }

        .canvasbid-swal-text {
            color:
                #6B7280 !important;
        }
    </style>

    <!-- Every view's component definition, loaded before router.js references them -->
    <script src="components/loading.js"></script>
    <script src="bidder/bidder_register.js"></script>
    <script src="creator/creator_register.js"></script>
    <script src="creator/creator_dashboard.js"></script>
    <script src="creator/new_auction.js"></script>
    <script src="creator/manage_auction.js"></script>
    <script src="admin/admin_dashboard.js"></script>
    <script src="admin/auction_queue.js"></script>
    <script src="creator/creator_profile.js"></script>
    <script src="creator/deposit_tracker.js"></script>
</head>

<body class="bg-[#F6F7F9] font-sans text-[#101828] antialiased">

    <div id="app" v-cloak>
        <router-view></router-view>
    </div>

    <script>
        // Login lives right here rather than in its own file, per how this SPA is organized:
        // registration views get their own file+folder, login stays with the shell.
        const loginView = {
            template: `
                <div class="min-h-screen flex flex-col lg:flex-row lg:h-screen">

                    <section class="relative bg-canvas-art overflow-hidden shrink-0 h-[34vh] min-h-[220px] lg:h-auto lg:min-h-screen lg:w-1/2">
                        <div class="absolute inset-0 art-vignette"></div>

                        <div class="relative h-full flex flex-col justify-between px-6 py-6 sm:px-10 sm:py-8 lg:px-14 lg:py-12">
                            <div class="flex items-center gap-2.5">
                                <span class="flex items-center justify-center w-8 h-8 rounded-md bg-white/10 border border-white/15 text-white font-serif font-semibold text-sm">C</span>
                                <span class="text-white font-medium tracking-wide">CanvasBid</span>
                            </div>

                            <div class="max-w-md">
                                <div class="flex items-center gap-2 mb-3">
                                    <span class="w-6 h-px bg-[#3E8F6B]"></span>
                                    <span class="text-[#3E8F6B] text-xs font-medium tracking-[0.16em] uppercase">Live auctions · Philippines</span>
                                </div>
                                <h1 class="font-serif text-white text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.08] font-semibold">
                                    Own a piece<br class="hidden sm:block" />
                                    of Filipino art.
                                </h1>
                                <p class="hidden sm:block mt-4 text-white/60 text-[15px] leading-relaxed max-w-sm">
                                    A transparent auction platform connecting collectors with Filipino creators — secured by deposit protection.
                                </p>
                            </div>

                            <p class="hidden lg:block text-white/35 text-xs">© 2026 CanvasBid. All rights reserved.</p>
                        </div>
                    </section>

                    <section class="flex-1 flex items-start lg:items-center justify-center px-6 py-10 sm:px-10 lg:px-16">
                        <div class="w-full max-w-sm">

                            <h2 class="font-serif text-2xl sm:text-[1.75rem] font-semibold text-[#101828]">Welcome back</h2>
                            <p class="mt-1.5 text-sm text-[#6B7280]">Sign in to your CanvasBid account.</p>

                            <p v-if="serverError" class="mt-5 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm px-3.5 py-2.5">
                                {{ serverError }}
                            </p>

                            <form class="mt-7 space-y-5" @submit.prevent="handleSubmit" novalidate>

                                <div>
                                    <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Email address</label>
                                    <input type="email" v-model.trim="form.email" placeholder="you@example.com" autocomplete="email"
                                        class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                        :class="errors.email ? 'border-red-400' : 'border-[#DEE2E8]'">
                                    <p v-if="errors.email" class="mt-1.5 text-xs text-red-500">{{ errors.email }}</p>
                                </div>

                                <div>
                                    <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Password</label>
                                    <div class="relative">
                                        <input :type="showPassword ? 'text' : 'password'" v-model="form.password" placeholder="••••••••" autocomplete="current-password"
                                            class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                            :class="errors.password ? 'border-red-400' : 'border-[#DEE2E8]'">
                                        <button type="button" @click="showPassword = !showPassword"
                                            class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                            :aria-label="showPassword ? 'Hide password' : 'Show password'">
                                            <svg v-if="!showPassword" class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                            <svg v-else class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                                        </button>
                                    </div>
                                    <p v-if="errors.password" class="mt-1.5 text-xs text-red-500">{{ errors.password }}</p>
                                </div>

                                <div class="flex items-center justify-between pt-1">
                                    <label class="flex items-center gap-2 text-sm text-[#101828] select-none">
                                        <input type="checkbox" v-model="form.remember" class="w-4 h-4 rounded border-[#DEE2E8] text-[#0F2245] focus:ring-[#0F2245]/30">
                                        Remember me
                                    </label>
                                    <a href="#" class="text-sm text-[#0F2245] hover:underline">Forgot password?</a>
                                </div>

                                <label class="flex items-center gap-3 rounded-lg border bg-white px-3.5 py-3 cursor-pointer select-none transition-colors"
                                    :class="form.asCreator ? 'border-[#0F2245] bg-[#0F2245]/5' : 'border-[#DEE2E8] hover:border-[#0F2245]/40'">
                                    <input type="checkbox" v-model="form.asCreator" class="w-4 h-4 rounded border-[#DEE2E8] text-[#0F2245] focus:ring-[#0F2245]/30">
                                    <span class="flex-1">
                                        <span class="block text-sm font-medium text-[#101828]">Sign in as Creator</span>
                                        <span class="block text-xs text-[#6B7280] mt-0.5">Access your auction dashboard</span>
                                    </span>
                                    <svg class="w-[18px] h-[18px] shrink-0" :class="form.asCreator ? 'text-[#0F2245]' : 'text-[#94A3B8]'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/>
                                    </svg>
                                </label>

                                <button type="submit" :disabled="submitting"
                                    class="w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] disabled:opacity-70 text-white text-[15px] font-medium transition-colors flex items-center justify-center gap-2">
                                    <svg v-if="submitting" class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                                    </svg>
                                    {{ submitting ? 'Signing in…' : 'Sign In' }}
                                </button>
                            </form>

                            <div class="flex items-center gap-3 my-7">
                                <span class="h-px flex-1 bg-[#DEE2E8]"></span>
                                <span class="text-xs text-[#6B7280]">or</span>
                                <span class="h-px flex-1 bg-[#DEE2E8]"></span>
                            </div>

                            <p class="text-center text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-3">Create an account as</p>

                            <div class="grid grid-cols-2 gap-3">
                                <router-link to="/register/bidder"
                                    class="h-11 rounded-lg border border-[#DEE2E8] hover:border-[#0F2245] hover:bg-[#0F2245]/5 flex items-center justify-center gap-2 text-sm font-medium text-[#101828] transition-colors">
                                    <svg class="w-4 h-4 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M9 12h6M12 9v6" stroke-linecap="round"/></svg>
                                    Bidder
                                </router-link>
                                <router-link to="/register/creator"
                                    class="h-11 rounded-lg border border-[#DEE2E8] hover:border-[#0F2245] hover:bg-[#0F2245]/5 flex items-center justify-center gap-2 text-sm font-medium text-[#101828] transition-colors">
                                    <svg class="w-4 h-4 text-[#0F2245]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>
                                    Creator
                                </router-link>
                            </div>

                            <p class="lg:hidden mt-10 text-center text-xs text-[#6B7280]">© 2026 CanvasBid. All rights reserved.</p>
                        </div>
                    </section>
                </div>
            `,
            data() {
                return {
                    form: {
                        email: '',
                        password: '',
                        remember: false,
                        asCreator: false
                    },
                    showPassword: false,
                    submitting: false,
                    errors: {},
                    serverError: '',
                };
            },
            methods: {
                validate() {
                    const errors = {};
                    if (!this.form.email) {
                        errors.email = 'Enter your email address.';
                    } else if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
                        errors.email = 'Enter a valid email address.';
                    }
                    if (!this.form.password) {
                        errors.password = 'Enter your password.';
                    }
                    this.errors = errors;
                    return Object.keys(errors).length === 0;
                },
                async handleSubmit() {
                    if (!this.validate() || this.submitting) return;
                    this.submitting = true;
                    this.serverError = '';

                    try {
                        // Root-relative — index.php is always the actual document,
                        // hash routing never changes what the browser thinks the URL is.
                        const res = await fetch('index.php?action=login', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(this.form),
                        });
                        const data = await res.json();

                        if (data.success) {
                            await Swal.fire({
                                icon: 'success',
                                title: 'Signed in!',
                                text: 'Welcome back to CanvasBid.',
                                timer: 1500,
                                showConfirmButton: false,
                                background: '#FFFFFF',
                                color: '#101828',
                                iconColor: '#3E8F6B',
                                confirmButtonColor: '#0F2245',
                                customClass: {
                                    popup: 'canvasbid-swal-popup',
                                    title: 'canvasbid-swal-title',
                                    htmlContainer: 'canvasbid-swal-text',
                                },
                            });
                            // SPA routes (e.g. /creator/dashboard) live inside this same page --
                            // navigate in-app so the browser never requests them as real files.
                            if (data.redirect && data.redirect.startsWith('/')) {
                                this.$router.push(data.redirect);
                            } else {
                                window.location.href = data.redirect || '/';
                            }
                        } else if (data.redirect) {
                            window.location.href = data.redirect;
                        } else if (data.errors) {
                            this.errors = data.errors;
                        } else {
                            this.serverError = data.message || 'Something went wrong. Please try again.';
                        }
                    } catch (e) {
                        this.serverError = 'Network error. Please try again.';
                    } finally {
                        this.submitting = false;
                    }
                },
            },
        };
    </script>

    <script src="router.js"></script>

    <script>
        const app = Vue.createApp({});
        app.component('loading-spinner', LoadingSpinner);
        app.use(router);
        app.mount('#app');
    </script>
</body>

</html>