const ADMIN_NAV_ITEMS = [
  {
    label: "Dashboard Overview",
    to: "/admin/dashboard",
    icon: '<path d="M4 4h7v7H4V4zM13 4h7v7h-7V4zM4 13h7v7H4v-7zM13 13h7v7h-7v-7z" stroke-linecap="round" stroke-linejoin="round"/>',
  },
  {
    label: "Auction Queue",
    to: "/admin/auction-queue",
    icon: '<path d="M20.59 13.41L11 3.83A2 2 0 009.59 3.24L4 3a1 1 0 00-1 1l.24 5.59a2 2 0 00.58 1.41l9.59 9.59a2 2 0 002.83 0l4.35-4.35a2 2 0 000-2.83z" stroke-linecap="round" stroke-linejoin="round"/><circle cx="8" cy="8" r="1.4" fill="currentColor" stroke="none"/>',
  },
  {
    label: "User Management",
    to: null,
    icon: '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c.7-3.4 3.4-5.5 6.5-5.5s5.8 2.1 6.5 5.5" stroke-linecap="round"/><path d="M16 8.2a3 3 0 110 5.8" stroke-linecap="round"/><path d="M18.2 14.6c2.3.5 4 2.3 4.5 5" stroke-linecap="round"/>',
  },
  {
    label: "Escrow Ledger",
    to: null,
    icon: '<rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M2.5 10.5h19" stroke-linecap="round"/><circle cx="7" cy="14.5" r="1.1" fill="currentColor" stroke="none"/>',
  },
  {
    label: "Flagged Disputes",
    to: null,
    icon: '<path d="M12 3.5l9 15.5a1 1 0 01-.87 1.5H3.87A1 1 0 013 19l9-15.5z" stroke-linejoin="round"/><path d="M12 10v4" stroke-linecap="round"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/>',
  },
  {
    label: "System Settings",
    to: null,
    icon: '<circle cx="12" cy="12" r="3"/><path d="M19.4 13.5a1.7 1.7 0 00.34 1.87l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.7 1.7 0 00-1.87-.34 1.7 1.7 0 00-1 1.56V19.5a2 2 0 11-4 0v-.09a1.7 1.7 0 00-1-1.56 1.7 1.7 0 00-1.87.34l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.7 1.7 0 00.34-1.87 1.7 1.7 0 00-1.56-1H4.5a2 2 0 110-4h.09a1.7 1.7 0 001.56-1 1.7 1.7 0 00-.34-1.87l-.06-.06a2 2 0 112.83-2.83l.06.06a1.7 1.7 0 001.87.34H10a1.7 1.7 0 001-1.56V4.5a2 2 0 114 0v.09a1.7 1.7 0 001 1.56 1.7 1.7 0 001.87-.34l.06-.06a2 2 0 112.83 2.83l-.06.06a1.7 1.7 0 00-.34 1.87V10a1.7 1.7 0 001.56 1h.09a2 2 0 110 4h-.09a1.7 1.7 0 00-1.56 1z" stroke-linecap="round" stroke-linejoin="round"/>',
  },
];

const ADMIN_STATS = [
  {
    label: "Total Users",
    value: "3,842",
    valueClass: "text-[#0F172A]",
    delta: "+12% this month",
  },
  {
    label: "Pending Auctions",
    value: "27",
    valueClass: "text-[#F59E0B]",
    delta: "+5 this month",
  },
  {
    label: "Active Auctions",
    value: "184",
    valueClass: "text-[#10B981]",
    delta: "+8% this month",
  },
  {
    label: "Funds in Escrow",
    value: "\u20B12.4M",
    valueClass: "text-[#1A56DB]",
    delta: "+\u20B1180K this month",
  },
];

// Purely decorative — swap for real daily registration counts once the
// endpoint exists. Values are relative heights (0-100) for the bar chart.
const REGISTRATIONS_CHART_DATA = [
  18, 22, 20, 28, 26, 32, 30, 36, 34, 40, 38, 44, 42, 48, 46, 52, 50, 58, 55,
  62, 60, 68, 66, 72, 78, 74, 82, 88, 92, 100,
];

const ADMIN_ACTIVITY = [
  {
    text: "User @mariasantos registered",
    time: "2m ago",
    color: "#1A56DB",
    icon: '<circle cx="9" cy="7" r="3"/><path d="M2.5 18c.6-3 3-5 6.5-5s5.9 2 6.5 5" stroke-linecap="round"/>',
  },
  {
    text: "Payment #TXN-9982 secured",
    time: "8m ago",
    color: "#F59E0B",
    icon: '<rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M2.5 10h19" stroke-linecap="round"/>',
  },
  {
    text: "Creator @juandc approved",
    time: "14m ago",
    color: "#10B981",
    icon: '<path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round"/>',
  },
  {
    text: "Dispute on Roots & Branches",
    time: "31m ago",
    color: "#F59E0B",
    icon: '<path d="M12 3.5l9 15.5a1 1 0 01-.87 1.5H3.87A1 1 0 013 19l9-15.5z" stroke-linejoin="round"/><path d="M12 10v4" stroke-linecap="round"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/>',
  },
  {
    text: "Escrow released for #TXN-9910",
    time: "1h ago",
    color: "#10B981",
    icon: '<rect x="5" y="10.5" width="14" height="9" rx="1.5"/><path d="M8 10.5V7a4 4 0 018 0v3.5" stroke-linecap="round"/>',
  },
];

const adminDashboardView = {
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                        {{ adminInitials }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                        <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                    </div>
                    <button type="button" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">Dashboard Overview</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 px-4 sm:px-6 py-6 sm:py-8">

                    <!-- ============ STAT CARDS ============ -->
                    <div class="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div v-for="stat in stats" :key="stat.label"
                            class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">{{ stat.label }}</p>
                            <p class="mt-2 text-2xl sm:text-3xl font-bold" :class="stat.valueClass">{{ stat.value }}</p>
                            <p class="mt-1.5 flex items-center gap-1 text-xs font-medium text-[#10B981]">
                                <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
                                {{ stat.delta }}
                            </p>
                        </div>
                    </div>

                    <!-- ============ CHART + ACTIVITY ============ -->
                    <div class="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-4">

                        <div class="lg:col-span-2 bg-white rounded-xl border border-[#DEE2E8] p-5 sm:p-6">
                            <h2 class="text-sm font-semibold text-[#0F172A]">New Registrations — This Month</h2>
                            <div class="mt-6 flex items-end gap-[3px] h-40 sm:h-48">
                                <div v-for="(v, i) in chartData" :key="i"
                                    class="flex-1 rounded-t bg-[#DBEAFE] hover:bg-[#93C5FD] transition-colors"
                                    :style="{ height: v + '%' }"
                                    :title="'Day ' + (i + 1) + ': ' + v"></div>
                            </div>
                            <div class="mt-3 flex items-center justify-between text-xs text-[#94A3B8]">
                                <span>Sep 1</span>
                                <span>Sep 30</span>
                            </div>
                        </div>

                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5 sm:p-6">
                            <h2 class="text-sm font-semibold text-[#0F172A]">Recent Activity</h2>
                            <ul class="mt-4 divide-y divide-[#DEE2E8]">
                                <li v-for="(item, i) in activity" :key="i" class="py-3 first:pt-0 last:pb-0 flex items-start gap-3">
                                    <span class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                                        :style="{ backgroundColor: item.color + '1A', color: item.color }">
                                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" v-html="item.icon"></svg>
                                    </span>
                                    <div class="min-w-0">
                                        <p class="text-sm text-[#0F172A] leading-snug">{{ item.text }}</p>
                                        <p class="text-xs text-[#94A3B8] mt-0.5">{{ item.time }}</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      admin: { name: "Super Admin", email: "admin@canvasbid.ph" },
      navItems: ADMIN_NAV_ITEMS,
      stats: ADMIN_STATS,
      chartData: REGISTRATIONS_CHART_DATA,
      activity: ADMIN_ACTIVITY,
    };
  },
  computed: {
    adminInitials() {
      return this.admin.name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
  },
};
