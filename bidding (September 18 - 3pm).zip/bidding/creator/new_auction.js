const newAuctionView = {
  template: `
<div class="min-h-screen flex flex-col bg-[#F4F6F9]">

  <!-- ============ TOP NAV ============ -->
  <header class="bg-[#0F2245] text-white sticky top-0 z-40">
    <div class="w-full px-4 sm:px-6 lg:px-8">
      <div class="h-14 sm:h-16 flex items-center justify-between gap-4">

        <div class="flex items-center gap-8 min-w-0">
          <router-link to="/creator/dashboard" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

          <nav class="hidden md:flex items-center gap-6">
            <template v-for="item in navItems" :key="item.label">
              <router-link v-if="item.to" :to="item.to"
                class="text-sm transition-colors"
                :class="activeNav === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                {{ item.label }}
              </router-link>
              <span v-else class="text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
            </template>
          </nav>
        </div>

        <div class="flex items-center gap-2 sm:gap-3 shrink-0">
          <button type="button" @click="$router.push('/creator/profile')" aria-label="View profile"
            class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
            {{ initials }}
          </button>

          <button type="button" @click="mobileMenu = !mobileMenu"
            class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors"
            aria-label="Toggle navigation">
            <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M3 6h18M3 12h18M3 18h18" />
            </svg>
            <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <nav v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
      <div class="px-4 py-3 space-y-1">
        <template v-for="item in navItems" :key="item.label">
          <router-link v-if="item.to" :to="item.to" @click="mobileMenu = false"
            class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
            :class="activeNav === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
            {{ item.label }}
          </router-link>
          <span v-else class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
        </template>
      </div>
    </nav>
  </header>

  <main class="flex-1">
    <div class="px-4 py-8">
      <div class="w-[80%] mx-auto">
        <div class="mb-6">
          <h2 class="text-2xl font-bold text-[#1A202C]">Create New Auction</h2>
          <p class="text-sm text-[#64748b] mt-1">Fill in all the details below to publish your auction.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Left Column -->
          <div class="flex flex-col gap-5">

            <!-- Artwork Image -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Artwork Image</p>
              <label class="block cursor-pointer">
                <div
                  class="w-full rounded-xl border-2 border-dashed flex flex-col items-center justify-center overflow-hidden transition-colors hover:border-[#003366]"
                  :class="preview ? 'border-solid border-[#e2e8f0]' : 'border-[#cbd5e1]'"
                  style="aspect-ratio: 4/3">
                  <img v-if="preview" :src="preview" class="w-full h-full object-cover" alt="Preview" />
                  <div v-else class="text-center py-10 px-4">
                    <div class="text-5xl text-[#cbd5e1] mb-2">🖼</div>
                    <p class="text-sm font-semibold text-[#64748b]">Click to upload artwork</p>
                    <p class="text-xs text-[#94a3b8] mt-1">PNG, JPG · Max 10 MB</p>
                  </div>
                </div>
                <input type="file" accept="image/*" class="hidden" @change="handleFile" />
              </label>
              <button v-if="preview" @click="preview = null" class="mt-2 text-xs text-[#DC3545] hover:underline">
                Remove image
              </button>
            </div>

            <!-- Bid Type -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Bid Type</p>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  v-for="t in BID_TYPES"
                  :key="t.id"
                  type="button"
                  @click="bidType = t.id"
                  class="flex flex-col items-start gap-1 p-3 rounded-xl border-2 cursor-pointer transition-all text-left"
                  :class="bidType === t.id ? 'border-[#003366] bg-[#e8f0f9]' : 'border-[#e2e8f0] hover:border-[#93b4d8]'">
                  <div class="flex items-center gap-2 w-full">
                    <span class="text-lg leading-none">{{ t.emoji }}</span>
                    <div
                      class="w-3.5 h-3.5 rounded-full border-2 ml-auto shrink-0 flex items-center justify-center"
                      :class="bidType === t.id ? 'border-[#003366]' : 'border-[#cbd5e1]'">
                      <div v-if="bidType === t.id" class="w-2 h-2 rounded-full bg-[#003366]"></div>
                    </div>
                  </div>
                  <p class="text-[13px] font-bold leading-snug" :class="bidType === t.id ? 'text-[#003366]' : 'text-[#374151]'">
                    {{ t.label }}
                  </p>
                  <span
                    class="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md"
                    :class="bidType === t.id ? 'bg-[#003366] text-white' : 'bg-[#f1f5f9] text-[#64748b]'">
                    {{ t.subtitle }}
                  </span>
                  <p class="text-[11px] text-[#94a3b8] leading-snug mt-0.5">{{ t.desc }}</p>
                </button>
              </div>
            </div>

            <!-- Pricing -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Pricing</p>

              <div v-if="bidType === 'english'" class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <php-input label="Starting Price (₱)" placeholder="500"></php-input>
                <php-input label="Min. Bid Increment (₱)" placeholder="50"></php-input>
              </div>

              <div v-else-if="bidType === 'dutch'" class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <php-input label="Starting Price (₱)" placeholder="10,000"></php-input>
                <php-input label="Floor Price (₱)" placeholder="500"></php-input>
                <div>
                  <label class="block text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-1.5">Drop Interval</label>
                  <select class="w-full h-11 px-4 text-sm text-[#374151] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366]">
                    <option>Every 5 minutes</option>
                    <option>Every 10 minutes</option>
                    <option>Every 30 minutes</option>
                    <option>Every 1 hour</option>
                  </select>
                </div>
                <php-input label="Drop Amount (₱)" placeholder="200"></php-input>
              </div>

              <div v-else-if="bidType === 'sealed'" class="flex flex-col gap-3">
                <php-input label="Minimum Bid (₱)" placeholder="500"></php-input>
                <info-note emoji="🙈" text="Each bidder submits one secret offer without knowing competing bids. The highest offer at close wins."></info-note>
              </div>

              <div v-else-if="bidType === 'proxy'" class="flex flex-col gap-3">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <php-input label="Starting Price (₱)" placeholder="500"></php-input>
                  <php-input label="Min. Bid Increment (₱)" placeholder="50"></php-input>
                </div>
                <info-note emoji="🤖" text="Bidders enter their maximum willing price. The platform automatically bids the minimum needed to keep them in the lead — up to their max."></info-note>
              </div>

              <div v-else-if="bidType === 'buy-now'" class="flex flex-col gap-3">
                <php-input label="Fixed Purchase Price (₱)" placeholder="5,000"></php-input>
                <info-note emoji="⚡" text="The first buyer to pay the fixed price immediately wins the artwork. No bidding — instant purchase."></info-note>
              </div>
            </div>

          </div>

          <!-- Right Column -->
          <div class="flex flex-col gap-5">

            <!-- Title + Description -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5 flex flex-col gap-4">
              <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Title</p>
                <input
                  type="text"
                  placeholder="e.g. Sunset in Dasma"
                  class="w-full h-11 px-4 text-sm placeholder-[#94a3b8] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366] focus:ring-2 focus:ring-[#003366]/10 transition-all" />
              </div>
              <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Description</p>
                <textarea
                  rows="4"
                  placeholder="Describe your artwork — medium, dimensions, inspiration, condition..."
                  class="w-full px-4 py-3 text-sm placeholder-[#94a3b8] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366] focus:ring-2 focus:ring-[#003366]/10 resize-none transition-all"></textarea>
              </div>
            </div>

            <!-- Time Frame (hidden for Blind Bidding) -->
            <div v-if="bidType !== 'sealed'" class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Time Frame</p>
              <div class="flex gap-2 flex-wrap">
                <button
                  v-for="opt in timeframeOptions"
                  :key="opt[0]"
                  @click="timeframe = opt[0]"
                  class="h-9 px-4 text-[13px] font-semibold rounded-xl border transition-all"
                  :class="timeframe === opt[0] ? 'bg-[#003366] text-white border-[#003366]' : 'bg-white text-[#374151] border-[#e2e8f0] hover:border-[#003366]'">
                  {{ opt[1] }}
                </button>
              </div>
              <p class="text-xs text-[#94a3b8] mt-3">
                Auction runs for <span class="font-semibold text-[#374151]">{{ timeframeLabel }}</span> from the bidding start period.
              </p>
            </div>

            <!-- Bidding Start Period -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Bidding Start Period</p>
              <div class="flex flex-col gap-2 mb-3">
                <label
                  v-for="o in startOptions"
                  :key="o.id"
                  @click="startPeriod = o.id"
                  class="flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all"
                  :class="startPeriod === o.id ? 'border-[#003366] bg-[#e8f0f9]' : 'border-[#e2e8f0] hover:border-[#cbd5e1]'">
                  <div
                    class="w-4 h-4 rounded-full border-2 mt-0.5 shrink-0 flex items-center justify-center"
                    :class="startPeriod === o.id ? 'border-[#003366]' : 'border-[#cbd5e1]'">
                    <div v-if="startPeriod === o.id" class="w-2 h-2 rounded-full bg-[#003366]"></div>
                  </div>
                  <div>
                    <p class="text-[13px] font-bold" :class="startPeriod === o.id ? 'text-[#003366]' : 'text-[#374151]'">{{ o.label }}</p>
                    <p class="text-xs text-[#94a3b8] mt-0.5">{{ o.desc }}</p>
                  </div>
                </label>
              </div>
              <div v-if="startPeriod === 'scheduled'" class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-1">
                <div>
                  <label class="block text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-1.5">Date</label>
                  <input type="date" class="w-full h-11 px-4 text-sm text-[#374151] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366]" />
                </div>
                <div>
                  <label class="block text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-1.5">Time</label>
                  <input type="time" class="w-full h-11 px-4 text-sm text-[#374151] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366]" />
                </div>
              </div>
            </div>

            <!-- Payment Period -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Payment Period</p>
              <p class="text-xs text-[#94a3b8] mb-3">How long does the winner have to complete payment after the auction closes?</p>
              <div class="flex gap-2 flex-wrap">
                <button
                  v-for="opt in paymentOptions"
                  :key="opt[0]"
                  @click="paymentPeriod = opt[0]"
                  class="h-9 px-4 text-[13px] font-semibold rounded-xl border transition-all"
                  :class="paymentPeriod === opt[0] ? 'bg-[#003366] text-white border-[#003366]' : 'bg-white text-[#374151] border-[#e2e8f0] hover:border-[#003366]'">
                  {{ opt[1] }}
                </button>
              </div>
            </div>

            <!-- Delivery Commitment -->
            <div class="bg-white border border-[#e2e8f0] rounded-2xl p-5">
              <p class="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-3">Delivery Commitment</p>
              <p class="text-xs text-[#94a3b8] mb-3">How many days after payment will you ship the artwork?</p>
              <div class="flex gap-2 flex-wrap">
                <button
                  v-for="opt in deliveryOptions"
                  :key="opt[0]"
                  @click="delivery = opt[0]"
                  class="h-9 px-4 text-[13px] font-semibold rounded-xl border transition-all"
                  :class="delivery === opt[0] ? 'bg-[#003366] text-white border-[#003366]' : 'bg-white text-[#374151] border-[#e2e8f0] hover:border-[#003366]'">
                  {{ opt[1] }}
                </button>
              </div>
              <div class="flex items-start gap-2 mt-3 bg-[#F4F6F9] rounded-xl px-3 py-2.5">
                <span class="text-sm mt-0.5">📦</span>
                <p class="text-xs text-[#64748b] leading-relaxed">
                  You commit to shipping within <span class="font-semibold text-[#374151]">{{ delivery }} days</span> of deposit confirmation. Late shipping may affect your creator rating.
                </p>
              </div>
            </div>

            <!-- Actions -->
            <div class="flex flex-col-reverse sm:flex-row gap-3 justify-end pt-2">
              <button @click="$router.push('/creator/dashboard')" class="h-11 px-6 text-sm font-semibold text-[#374151] border border-[#e2e8f0] rounded-xl hover:bg-[#F4F6F9] transition-colors">
                Cancel
              </button>
              <button @click="publish" class="h-11 px-8 text-sm font-bold text-white bg-[#003366] rounded-xl hover:bg-[#002244] transition-colors">
                Publish Auction
              </button>
            </div>

          </div>
        </div>
      </div>
    </div>
  </main>
</div>
`,
  components: {
    "php-input": {
      props: { label: String, placeholder: String },
      template: `
<div>
  <label class="block text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-1.5">{{ label }}</label>
  <input type="text" :placeholder="placeholder" class="w-full h-11 px-4 text-sm placeholder-[#94a3b8] bg-white border border-[#e2e8f0] rounded-xl outline-none focus:border-[#003366] focus:ring-2 focus:ring-[#003366]/10 transition-all" />
</div>
`,
    },
    "info-note": {
      props: { emoji: String, text: String },
      template: `
<div class="flex items-start gap-2 bg-[#F4F6F9] rounded-xl px-3 py-2.5">
  <span class="text-sm mt-0.5">{{ emoji }}</span>
  <p class="text-xs text-[#64748b] leading-relaxed">{{ text }}</p>
</div>
`,
    },
  },
  data() {
    return {
      activeNav: "My Auctions",
      mobileMenu: false,
      user: {
        firstName: "Maria",
        lastName: "Santos",
      },
      navItems: [
        { label: "My Auctions", to: "/creator/dashboard" },
        { label: "Orders", to: null },
        { label: "Deposit Tracker", to: "/creator/deposit-tracker" },
      ],

      preview: null,
      bidType: "english",
      timeframe: "24",
      startPeriod: "now",
      delivery: "7",
      paymentPeriod: "48",

      BID_TYPES: [
        {
          id: "english",
          emoji: "📈",
          label: "English Auction",
          subtitle: "Ascending",
          desc: "Bidders raise the price; highest bid at close wins",
        },
        {
          id: "dutch",
          emoji: "📉",
          label: "Dutch Auction",
          subtitle: "Descending",
          desc: "Price drops over time until a bidder accepts",
        },
        {
          id: "sealed",
          emoji: "🙈",
          label: "Blind Bidding",
          subtitle: "Secret offers",
          desc: "Bids submitted in secret — no one sees competing amounts until close",
        },
        {
          id: "proxy",
          emoji: "🤖",
          label: "Proxy / Auto Bidding",
          subtitle: "Automatic",
          desc: "System bids up to your max on your behalf",
        },
        {
          id: "buy-now",
          emoji: "⚡",
          label: "Buy-It-Now",
          subtitle: "Instant purchase",
          desc: "Buyer pays a fixed price to close immediately",
        },
      ],

      timeframeOptions: [
        ["1", "1 hr"],
        ["2", "2 hrs"],
        ["6", "6 hrs"],
        ["12", "12 hrs"],
        ["24", "24 hrs"],
        ["48", "48 hrs"],
        ["72", "3 days"],
        ["168", "7 days"],
      ],

      startOptions: [
        {
          id: "now",
          label: "Start immediately",
          desc: "Goes live as soon as you publish",
        },
        {
          id: "scheduled",
          label: "Schedule a date & time",
          desc: "Set a specific launch time",
        },
      ],

      paymentOptions: [
        ["24", "24 hrs"],
        ["48", "48 hrs"],
        ["72", "3 days"],
        ["168", "7 days"],
      ],
      deliveryOptions: [
        ["3", "3 days"],
        ["5", "5 days"],
        ["7", "7 days"],
        ["14", "14 days"],
        ["30", "30 days"],
      ],
    };
  },
  computed: {
    initials() {
      return (this.user.firstName[0] + this.user.lastName[0]).toUpperCase();
    },
    timeframeLabel() {
      const map = { 168: "7 days", 72: "3 days", 48: "48 hours" };
      return (
        map[this.timeframe] ??
        `${this.timeframe} hour${this.timeframe === "1" ? "" : "s"}`
      );
    },
  },
  methods: {
    handleFile(e) {
      const file = e.target.files && e.target.files[0];
      if (file) this.preview = URL.createObjectURL(file);
    },
    publish() {
      // Front-end only: no auction is actually created/persisted yet.
      console.log(
        "Publish auction (stub) — wire this up to the real endpoint later.",
      );
    },
  },
};
