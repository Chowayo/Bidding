const MANAGE_AUCTION_DATA = {
  1: {
    title: "Sunset in Dasma",
    status: "Live",
    timeLeft: "02h 15m",
    image:
      "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=200&q=70",
    bids: [
      { id: 1, amount: 5000, name: "Maria Santos", contact: "@mariasantos" },
      { id: 2, amount: 4200, name: "Juan dela Cruz", contact: "@juandc_art" },
      { id: 3, amount: 3800, name: "Andrea Reyes", contact: "@andreareyes" },
      { id: 4, amount: 3100, name: "Carlo Mendez", contact: "@carlomendez" },
      { id: 5, amount: 2500, name: "Sofia Lim", contact: "@sofilm_draws" },
    ],
  },
  2: {
    title: "Blue Hour Manila",
    status: "Live",
    timeLeft: "05h 40m",
    image:
      "https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=200&q=70",
    bids: [
      { id: 1, amount: 3200, name: "Andrea Reyes", contact: "@andreareyes" },
      { id: 2, amount: 2900, name: "Carlo Mendez", contact: "@carlomendez" },
      { id: 3, amount: 2400, name: "Sofia Lim", contact: "@sofilm_draws" },
    ],
  },
  3: {
    title: "Roots & Branches",
    status: "Ending",
    timeLeft: "00h 08m",
    image:
      "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
    bids: [
      { id: 1, amount: 8750, name: "Juan dela Cruz", contact: "@juandc_art" },
      { id: 2, amount: 8200, name: "Maria Santos", contact: "@mariasantos" },
      { id: 3, amount: 7600, name: "Sofia Lim", contact: "@sofilm_draws" },
      { id: 4, amount: 6900, name: "Carlo Mendez", contact: "@carlomendez" },
    ],
  },
};

const bidTable = {
  props: {
    bids: { type: Array, required: true },
  },
  emits: ["reject"],
  data() {
    return {
      // If js/tabulator.min.js isn't on disk yet, Tabulator is undefined here.
      // Fall back to a plain table instead of throwing and taking the page down.
      tabulatorAvailable: typeof Tabulator !== "undefined",
      pageSize: 10,
      currentPage: 1,
    };
  },
  computed: {
    totalPages() {
      return Math.max(1, Math.ceil(this.bids.length / this.pageSize));
    },
    pagedBids() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.bids.slice(start, start + this.pageSize);
    },
  },
  methods: {
    // Global (whole-list) rank for the i-th row on the current fallback page —
    // Tabulator's getPosition(true) does this automatically; the plain-table
    // fallback has to compute it itself so rank numbers don't reset to 1 on page 2+.
    rankOf(i) {
      return (this.currentPage - 1) * this.pageSize + i;
    },
    goToPage(p) {
      this.currentPage = Math.min(Math.max(1, p), this.totalPages);
    },
  },
  template: `
        <div>
            <!-- Tabulator handles its own responsive column collapsing (see mounted()).
                 overflow-x-auto is kept as a safety net so nothing gets silently clipped. -->
            <div v-if="tabulatorAvailable" ref="tableEl" class="w-full overflow-x-auto"></div>

            <template v-else>
                <!-- Mobile fallback: stacked cards instead of a cramped table -->
                <ul class="sm:hidden divide-y divide-[#DEE2E8]">
                    <li v-for="(bid, i) in pagedBids" :key="bid.id" class="p-5 flex items-start justify-between gap-3">
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center gap-2 text-sm text-[#94A3B8]">
                                <svg v-if="rankOf(i) === 0" class="w-4 h-4 text-amber-500 shrink-0" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <span :class="rankOf(i) === 0 ? 'font-bold text-[#0F172A]' : ''">Rank {{ rankOf(i) + 1 }}</span>
                            </div>
                            <p class="mt-1.5 text-lg font-semibold text-[#10B981]">&#8369; {{ Number(bid.amount).toLocaleString('en-PH') }}</p>
                            <p class="mt-1 text-base font-medium text-[#0F172A] truncate">{{ bid.name }}</p>
                            <p class="text-sm text-[#64748B] truncate">{{ bid.contact }}</p>
                        </div>
                        <button type="button" @click="$emit('reject', bid)"
                            class="shrink-0 h-9 px-3.5 rounded-full border border-[#EF4444] text-[#EF4444] text-sm font-medium hover:bg-red-50 transition-colors inline-flex items-center gap-1">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 18L18 6M6 6l12 12"/></svg>
                            Reject
                        </button>
                    </li>
                </ul>

                <!-- Desktop / tablet fallback: full table, scrolls horizontally if it ever needs to -->
                <div class="hidden sm:block overflow-x-auto">
                    <table class="w-full text-base min-w-[560px]">
                        <thead>
                            <tr class="text-left text-xs font-semibold uppercase tracking-wider text-[#94A3B8] border-b border-[#DEE2E8]">
                                <th class="py-4 px-5 font-semibold">Rank</th>
                                <th class="py-4 px-5 font-semibold">Bid Amount</th>
                                <th class="py-4 px-5 font-semibold">Name</th>
                                <th class="py-4 px-5 font-semibold">Contact</th>
                                <th class="py-4 px-5 font-semibold text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(bid, i) in pagedBids" :key="bid.id" class="border-b border-[#DEE2E8] last:border-0">
                                <td class="py-5 px-5">
                                    <span v-if="rankOf(i) === 0" class="text-amber-500 mr-1">★</span>
                                    <span :class="rankOf(i) === 0 ? 'font-bold' : ''">{{ rankOf(i) + 1 }}</span>
                                </td>
                                <td class="py-5 px-5 font-semibold text-[#10B981]">&#8369; {{ Number(bid.amount).toLocaleString('en-PH') }}</td>
                                <td class="py-5 px-5">{{ bid.name }}</td>
                                <td class="py-5 px-5 text-[#64748B]">{{ bid.contact }}</td>
                                <td class="py-5 px-5 text-right">
                                    <button type="button" @click="$emit('reject', bid)"
                                        class="h-9 px-4 rounded-full border border-[#EF4444] text-[#EF4444] text-sm font-medium hover:bg-red-50 transition-colors">
                                        Reject
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination (fallback only — Tabulator renders its own when active) -->
                <div v-if="totalPages > 1" class="flex items-center justify-between gap-3 px-5 py-4 border-t border-[#DEE2E8]">
                    <p class="text-sm text-[#64748B]">Page {{ currentPage }} of {{ totalPages }}</p>
                    <div class="flex items-center gap-2">
                        <button type="button" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
                            class="h-9 px-3.5 rounded-lg border border-[#DEE2E8] text-sm font-medium text-[#374151] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            Prev
                        </button>
                        <button type="button" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
                            class="h-9 px-3.5 rounded-lg border border-[#DEE2E8] text-sm font-medium text-[#374151] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            Next
                        </button>
                    </div>
                </div>
            </template>
        </div>
    `,
  mounted() {
    if (!this.tabulatorAvailable) {
      console.warn(
        "[CanvasBid] Tabulator isn't loaded (add js/tabulator.min.js + css/tabulator.min.css) — showing a plain table for now.",
      );
      return;
    }
    // responsiveLayout:"collapse" is what actually fixes mobile: instead of the
    // row overflowing (and the card's overflow-hidden silently clipping the
    // Contact/Action columns, as in the old build), lower-priority columns fold
    // into an expandable "+" row so every column stays reachable at any width.
    //
    // Tabulator's default theme is quite compact, so we also bump font size,
    // padding, and row height for a more comfortable, larger-reading table.
    // Injected once and scoped to .canvasbid-bid-table so multiple tables on
    // a page don't duplicate the <style> tag.
    if (!document.getElementById("canvasbid-bid-table-style")) {
      const style = document.createElement("style");
      style.id = "canvasbid-bid-table-style";
      style.textContent = `
        .canvasbid-bid-table .tabulator-header .tabulator-col-content { padding: 16px 18px; }
        .canvasbid-bid-table .tabulator-header .tabulator-col-title { font-size: 13px; letter-spacing: 0.04em; }
        .canvasbid-bid-table .tabulator-row .tabulator-cell { font-size: 16px; padding: 20px 18px; }
        .canvasbid-bid-table .tabulator-row { min-height: 76px; }
      `;
      document.head.appendChild(style);
    }
    this.$refs.tableEl.classList.add("canvasbid-bid-table");
    this.table = new Tabulator(this.$refs.tableEl, {
      data: this.bids,
      layout: "fitColumns",
      responsiveLayout: "collapse",
      responsiveLayoutCollapseStartOpen: false,
      headerVisible: true,
      renderVertical: "basic",
      rowHeight: 76,
      pagination: true,
      paginationSize: 10,
      paginationCounter: "rows",
      columns: [
        {
          title: "Rank",
          field: "_rank",
          width: 90,
          minWidth: 70,
          hozAlign: "left",
          headerSort: false,
          responsive: 0,
          formatter: (cell) => {
            const rank = cell.getRow().getPosition(true);
            const star =
              rank === 1
                ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="#F59E0B" stroke="#F59E0B" stroke-width="1.5" style="display:inline-block;vertical-align:-3px;margin-right:5px"><polygon points="12 2 15 9 22 9 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9 9 9"/></svg>'
                : "";
            const weight = rank === 1 ? "font-weight:700" : "";
            return `<span style="${weight};font-size:16px">${star}${rank}</span>`;
          },
        },
        {
          title: "Bid Amount",
          field: "amount",
          width: 160,
          minWidth: 130,
          headerSort: false,
          responsive: 0,
          formatter: (cell) =>
            `<span style="color:#10B981;font-weight:600;font-size:16px">\u20B1 ${Number(cell.getValue()).toLocaleString("en-PH")}</span>`,
        },
        {
          title: "Name",
          field: "name",
          minWidth: 130,
          headerSort: false,
          responsive: 1,
        },
        {
          title: "Contact",
          field: "contact",
          minWidth: 140,
          headerSort: false,
          responsive: 3,
          formatter: (cell) =>
            `<span style="color:#64748B;font-size:16px">${cell.getValue()}</span>`,
        },
        {
          title: "Action",
          field: "_action",
          width: 130,
          minWidth: 100,
          hozAlign: "right",
          headerSort: false,
          responsive: 2,
          formatter: () =>
            `<button type="button" style="height:38px;padding:0 16px;border-radius:9999px;border:1px solid #EF4444;color:#EF4444;background:#fff;font-size:14px;font-weight:500;cursor:pointer;white-space:nowrap">Reject</button>`,
          cellClick: (e, cell) => {
            if (e.target.tagName === "BUTTON") {
              this.$emit("reject", cell.getRow().getData());
            }
          },
        },
      ],
    });
  },
  watch: {
    bids: {
      deep: true,
      handler(val) {
        if (this.table) this.table.setData(val);
        if (this.currentPage > this.totalPages)
          this.currentPage = this.totalPages;
      },
    },
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
};

const manageAuctionView = {
  components: { "bid-table": bidTable },
  template: `
        <div class="min-h-screen flex flex-col">

            <!-- ============ TOP NAV ============ -->
            <header class="bg-[#0F2245] text-white sticky top-0 z-40">
                <div class="w-full px-4 sm:px-6 lg:px-8">
                    <div class="h-14 sm:h-16 flex items-center justify-between gap-4">
                        <div class="flex items-center gap-8 min-w-0">
                            <router-link to="/creator/dashboard" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

                            <nav class="hidden md:flex items-center gap-6">
                                <template v-for="item in navItems" :key="item.label">
                                    <router-link v-if="item.to" :to="item.to"
                                        class="text-sm transition-colors"
                                        :class="activeNav === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                                        {{ item.label }}
                                    </router-link>
                                    <span v-else class="text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                                </template>
                            </nav>
                        </div>

                        <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                            <button type="button" @click="$router.push('/creator/new-auction')"
                                class="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-white text-[#0F2245] text-sm font-medium hover:bg-white/90 transition-colors">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
                                New Auction
                            </button>
                            <button type="button" @click="$router.push('/creator/profile')" aria-label="View profile"
                                class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
                                {{ initials }}
                            </button>
                            <button type="button" @click="mobileMenu = !mobileMenu"
                                class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors"
                                aria-label="Toggle navigation">
                                <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                                <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                            </button>
                        </div>
                    </div>
                </div>

                <nav v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
                    <div class="px-4 py-3 space-y-1">
                        <template v-for="item in navItems" :key="item.label">
                            <router-link v-if="item.to" :to="item.to" @click="mobileMenu = false"
                                class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
                                :class="activeNav === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
                                {{ item.label }}
                            </router-link>
                            <span v-else class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                        </template>
                    </div>
                </nav>
            </header>

            <!-- ============ MAIN ============ -->
            <main class="flex-1 w-[80%] px-4 sm:px-6 lg:px-8 py-6 sm:py-10 mx-auto">

                <div v-if="!auction" class="text-center py-20">
                    <p class="font-medium">Auction not found</p>
                    <router-link to="/creator/dashboard" class="mt-2 inline-block text-sm text-[#0F2245] hover:underline">Back to My Auctions</router-link>
                </div>

                <template v-else>
                    <router-link to="/creator/dashboard" class="inline-flex items-center gap-1.5 text-sm text-[#6B7280] hover:text-[#101828] transition-colors">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        Back to My Auctions
                    </router-link>

                    <div class="mt-4 flex flex-col sm:flex-row sm:flex-wrap items-start sm:items-center justify-between gap-4">
                        <div class="flex items-center gap-3 min-w-0 w-full sm:w-auto">
                            <img :src="auction.image" :alt="auction.title" class="w-12 h-12 rounded-lg object-cover shrink-0 bg-[#0B1526]">
                            <div class="min-w-0">
                                <h1 class="font-serif text-lg sm:text-2xl font-bold truncate">{{ auction.title }}</h1>
                                <p class="text-xs sm:text-sm text-[#64748B] mt-0.5">
                                    Status:
                                    <span class="font-semibold" :class="statusTextClass">{{ auction.status.toUpperCase() }}</span>
                                    · Ends in <span class="font-semibold text-[#0F172A]">{{ auction.timeLeft }}</span>
                                    · {{ bids.length }} bids
                                </p>
                            </div>
                        </div>

                        <div class="flex items-center gap-2 w-full sm:w-auto sm:shrink-0">
                            <button type="button" @click="copyBidLink"
                                class="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 h-9 px-4 rounded-lg border border-[#DEE2E8] bg-white text-sm font-medium text-[#374151] hover:border-[#1A56DB] transition-colors">
                                <svg class="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2"/></svg>
                                <span class="truncate">Copy Bid Link</span>
                            </button>
                            <button type="button" @click="endAuction"
                                class="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 h-9 px-4 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-sm font-medium transition-colors">
                                <svg class="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9 9h6v6H9z"/></svg>
                                <span class="truncate">End Auction</span>
                            </button>
                        </div>
                    </div>

                    <div class="mt-5 bg-white rounded-xl border border-[#DEE2E8] shadow-card overflow-hidden">
                        <bid-table :bids="bids" @reject="rejectBid" />
                    </div>
                </template>
            </main>
        </div>
    `,
  data() {
    return {
      activeNav: null,
      mobileMenu: false,
      user: { firstName: "Maria", lastName: "Santos" },
      navItems: [
        { label: "My Auctions", to: "/creator/dashboard" },
        { label: "Orders", to: null },
        { label: "Deposit Tracker", to: "/creator/deposit-tracker" },
      ],
      bids: [],
    };
  },
  computed: {
    initials() {
      return (this.user.firstName[0] + this.user.lastName[0]).toUpperCase();
    },
    auction() {
      return MANAGE_AUCTION_DATA[this.$route.params.id] || null;
    },
    statusTextClass() {
      const map = {
        Live: "text-[#10B981]",
        Ending: "text-[#EF4444]",
        Scheduled: "text-[#F59E0B]",
        Closed: "text-[#94A3B8]",
      };
      return this.auction ? map[this.auction.status] || "text-[#94A3B8]" : "";
    },
  },
  created() {
    if (this.auction) this.bids = [...this.auction.bids];
  },
  methods: {
    copyBidLink() {
      const link = `${window.location.origin}${window.location.pathname}#/bid/${this.$route.params.id}`;
      navigator.clipboard?.writeText(link);
      Swal.fire({
        icon: "success",
        title: "Link copied",
        text: "The bid link is on your clipboard.",
        timer: 1400,
        showConfirmButton: false,
        confirmButtonColor: "#0F2245",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
          htmlContainer: "canvasbid-swal-text",
        },
      });
    },
    async endAuction() {
      // Front-end only: no request sent yet, just a confirm + local state flip.
      const result = await Swal.fire({
        icon: "warning",
        title: "End this auction?",
        text: "Bidding will close immediately and can't be reopened.",
        showCancelButton: true,
        confirmButtonText: "End auction",
        confirmButtonColor: "#EF4444",
        cancelButtonColor: "#94A3B8",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
          htmlContainer: "canvasbid-swal-text",
        },
      });
      if (result.isConfirmed && this.auction) {
        this.auction.status = "Closed";
      }
    },
    rejectBid(bid) {
      // Front-end only: removes locally, doesn't call the backend yet.
      this.bids = this.bids.filter((b) => b.id !== bid.id);
    },
  },
};
