const { createRouter, createWebHashHistory } = VueRouter;

const routes = [
  { path: "/", component: directoryView },
  { path: "/analytics", component: analyticsView },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});
