const routes = [
  { path: "/", component: loginView },
  { path: "/register/bidder", component: bidderRegisterView },
  { path: "/register/creator", component: creatorRegisterView },
  { path: "/creator/dashboard", component: creatorDashboardView },
  { path: "/creator/profile", component: creatorProfileView },
  { path: "/creator/new-auction", component: newAuctionView },
  { path: "/creator/auctions/:id", component: manageAuctionView },
  { path: "/admin/dashboard", component: adminDashboardView },
  { path: "/admin/auction-queue", component: adminAuctionQueueView },
  { path: "/admin/user-management", component: adminUserManagementView },
  { path: "/admin/escrow-ledger", component: adminEscrowLedgerView },
  { path: "/admin/flagged-disputes", component: adminFlaggedDisputesView },
  { path: "/admin/profile", component: adminProfileView },
  { path: "/creator/deposit-tracker", component: depositTrackerView },
  { path: "/creator/orders", component: creatorOrdersView },
  { path: "/discover", component: discoverAuctionsView },
  { path: "/bid/:id", component: bidPageView },
  { path: "/bidder/profile", component: bidderProfileView },
  { path: "/bidder/winning-bids", component: winningBidsView },
];

const router = VueRouter.createRouter({
  // Hash history ("index.php#/register/bidder") needs zero server config —
  // XAMPP always serves index.php itself regardless of what's after the #.
  history: VueRouter.createWebHashHistory(),
  routes,
});
