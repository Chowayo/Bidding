<?php
//SESSION

session_start();
header('Content-Type: application/json');

//DB CONNECTION
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "bidding";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


//Loader of all info based on what's needed
$action = $_GET['action'] ?? '';

switch ($action) {

    //To check if session is active
    case 'session_checker':
        sessionCheck($conn);
        break;

    //To get creator Info
    case 'get_all_auctions':
        getAuctions($conn);
        break;

    default:
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing action parameter"]);
        break;
}


function sessionCheck($conn) {
    if(isset($_SESSION['user_id'])){
        $session_status = $_SESSION['user_id'];
    }else{
        $session_status = "Inactive";
    }
    echo json_encode($session_status);
}

function getAuctions($conn) {
    $auction_list = $conn->execute_query("SELECT * FROM auctions WHERE status = 'Approval Pending'")->fetch_all(MYSQLI_ASSOC);

    $auction_array = [];

    

    foreach ($auction_list as $row) {

        if($row["time_start"]!="PENDING"){
            $startPeriod = "Scheduled";
        }else{
            $startPeriod = "Immediately";
        }

        //Creator Email
        $creator_email = $conn->execute_query('SELECT email FROM users WHERE id = ?', [$row['creator_id']])->fetch_assoc();
        $creator_email = $creator_email['email'] ?? 'Unknown Email';

        //Creator Name
        $creator_name = $conn->execute_query('SELECT first_name, last_name FROM users WHERE id = ?', [$row['creator_id']])->fetch_assoc();
        $creator_name = $creator_name['first_name']." ".$creator_name['last_name'] ?? 'Unknown Email';


        // $row['id'], $row['title'], etc.
        array_push($auction_array, [
            'id' => $row['id'],
            'title' => $row['title'],
            'bidType' => $row['type'],
            'creatorName' => $creator_name,
            'creatorEmail' => $creator_email,
            'startingPrice' => $row['minimum'],
            'submitted' => $row['date_start']."T".$row['time_start'],
            'description' =>$row['description'],
            'timeFrame' => $row['time_frame']." hrs",
            'paymentPeriod' => $row['payment_period']." hrs",
            'startPeriod' => $startPeriod,
            'delivery' => $row['delivery']." days",
        ]);
    }
    echo json_encode($auction_array);
}


?>