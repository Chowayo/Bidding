// Icons sourced from Lucide (lucide.dev, ISC licensed) — same inline-SVG
// convention as creator_profile.js / admin_dashboard.js.
const ADMIN_PROFILE_ICONS = {
  chevronRight: '<path d="M9 18l6-6-6-6"/>',
  checkCircle:
    '<circle cx="12" cy="12" r="9"/><path d="M8.5 12.2l2.4 2.4 4.6-5.2"/>',
  logOut:
    '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
};

const AdminProfileIcon = {
  props: { name: String },
  template: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" v-html="ADMIN_PROFILE_ICONS[name] || ''"></svg>`,
  created() {
    this.ADMIN_PROFILE_ICONS = ADMIN_PROFILE_ICONS;
  },
};

const adminProfileView = {
  components: { "profile-icon": AdminProfileIcon },
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <!-- This block is now the "My Profile" entry point — clicking the
                     avatar/name comes here. The link and the logout button are
                     kept as SIBLINGS on purpose: nesting a <button> inside the
                     <router-link> (which renders as <a>) is invalid HTML, and
                     browsers "fixing" that broken nesting is what made clicks
                     land on the wrong element and trigger logout instead. -->
                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <router-link to="/admin/profile"
                        class="flex items-center gap-3 min-w-0 flex-1 -m-1 p-1 rounded-lg transition-colors"
                        :class="$route.path === '/admin/profile' ? 'bg-white/10' : 'hover:bg-white/5'">
                        <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                            {{ adminInitials }}
                        </span>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                            <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                        </div>
                    </router-link>
                    <button type="button" @click="logOut" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <profile-icon name="logOut" class="w-[18px] h-[18px]" />
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">My Profile</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 w-[80%] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">

                    <!-- Profile header card -->
                    <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                        <div class="relative h-20 sm:h-24 bg-[#0F2245]"
                            style="background-image: repeating-linear-gradient(135deg, rgba(255,255,255,0.04) 0 2px, transparent 2px 14px);">
                            <span class="absolute top-3 right-3 text-[10px] font-semibold uppercase tracking-wider bg-white/15 text-white rounded-full px-2.5 py-1">
                                Admin Account
                            </span>
                        </div>

                        <div class="px-5 sm:px-6 pt-4 pb-5 sm:pb-6">
                            <h1 class="text-lg sm:text-xl font-semibold">{{ admin.name }}</h1>
                            <p class="mt-0.5 text-sm text-[#64748B]">{{ admin.email }}</p>

                            <div class="mt-3 flex flex-wrap items-center gap-2">
                                <span class="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-[#10B981]/10 text-[#10B981]">
                                    <profile-icon name="checkCircle" class="w-3.5 h-3.5" />
                                    Verified Admin
                                </span>
                                <span class="text-xs font-medium px-2.5 py-1 rounded-full bg-[#1A56DB]/10 text-[#1A56DB]">
                                    {{ admin.role }}
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- ============ CONTENT GRID ============ -->
                    <div class="mt-4 sm:mt-5 grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5">

                        <!-- Right column on desktop, shown first on mobile -->
                        <div class="order-1 lg:order-2 lg:col-span-2 space-y-4 sm:space-y-5">

                            <!-- Stat cards -->
                            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                                <div v-for="stat in stats" :key="stat.label" class="bg-white rounded-xl border border-[#DEE2E8] px-4 py-4">
                                    <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B] truncate">{{ stat.label }}</p>
                                    <p class="mt-1.5 font-serif text-xl sm:text-2xl font-bold leading-none" :class="stat.accent">{{ stat.value }}</p>
                                </div>
                            </div>

                            <!-- Recent Activity -->
                            <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                                <div class="px-5 py-4 border-b border-[#DEE2E8]">
                                    <h2 class="text-sm font-semibold">Recent Activity</h2>
                                </div>
                                <ul class="divide-y divide-[#DEE2E8]">
                                    <li v-for="(item, i) in activity" :key="i" class="flex items-start gap-3 px-5 py-3.5">
                                        <span class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                                            :style="{ backgroundColor: item.color + '1A', color: item.color }">
                                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" v-html="item.icon"></svg>
                                        </span>
                                        <div class="min-w-0">
                                            <p class="text-sm text-[#0F172A] leading-snug">{{ item.text }}</p>
                                            <p class="text-xs text-[#94A3B8] mt-0.5">{{ item.time }}</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <!-- Left column on desktop, shown second on mobile -->
                        <div class="order-2 lg:order-1 space-y-4 sm:space-y-5">

                            <!-- Personal info -->
                            <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                                <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Personal Info</p>
                                <dl class="mt-3 space-y-3">
                                    <div v-for="field in personalFields" :key="field.label">
                                        <dt class="text-[11px] font-semibold tracking-[0.06em] uppercase text-[#94A3B8]">{{ field.label }}</dt>
                                        <dd class="text-sm mt-0.5">{{ field.value }}</dd>
                                    </div>
                                </dl>
                            </div>

                            <!-- Security -->
                            <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                                <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Security</p>
                                <div class="mt-2 divide-y divide-[#DEE2E8]">
                                    <button type="button" @click="changePassword" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                        Change Password
                                        <profile-icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                    </button>
                                    <button type="button" @click="manageTwoFactor" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                        Two-Factor Auth
                                        <profile-icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                    </button>
                                </div>
                            </div>

                            <button type="button" @click="logOut"
                                class="w-full h-11 rounded-lg border border-[#EF4444]/30 text-[#EF4444] text-sm font-medium hover:bg-[#EF4444]/5 transition-colors flex items-center justify-center gap-2">
                                <profile-icon name="logOut" class="w-4 h-4" />
                                Log Out
                            </button>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      navItems: typeof ADMIN_NAV_ITEMS !== "undefined" ? ADMIN_NAV_ITEMS : [],
      // Name/role aren't returned by admin/session.php yet — email is live,
      // the rest stays placeholder until that endpoint returns more fields.
      admin: {
        name: "Super Admin",
        email: "admin@canvasbid.ph",
        role: "Super Admin",
      },
      // Front-end only — swap for the real admin-profile endpoint once it exists.
      metrics: {
        disputesResolved: 38,
        auctionsReviewed: 214,
        usersManaged: 3842,
        escrowReleased: 1240000,
      },
      activity: typeof ADMIN_ACTIVITY !== "undefined" ? ADMIN_ACTIVITY : [],
    };
  },
  computed: {
    adminInitials() {
      return this.admin.name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    personalFields() {
      return [
        { label: "Name", value: this.admin.name },
        { label: "Role", value: this.admin.role },
        { label: "Email", value: this.admin.email },
      ];
    },
    stats() {
      return [
        {
          label: "Disputes Resolved",
          value: this.metrics.disputesResolved,
          accent: "text-[#10B981]",
        },
        {
          label: "Auctions Reviewed",
          value: this.metrics.auctionsReviewed,
          accent: "text-[#1A56DB]",
        },
        {
          label: "Users Managed",
          value: this.metrics.usersManaged.toLocaleString("en-PH"),
          accent: "text-[#0F172A]",
        },
        {
          label: "Escrow Released",
          value: "\u20B1" + this.formatMoney(this.metrics.escrowReleased),
          accent: "text-[#F59E0B]",
        },
      ];
    },
  },
  mounted() {
    // Deliberately NOT doing a live session check here (this used to call
    // admin/session.php and redirect on failure) — this was the only admin
    // page doing that check, and it turned out to fire false positives,
    // sending people to admin/login.php while still logged in. Every other
    // admin page skips this too, so removing it just makes this page
    // consistent with the rest until the underlying session issue (see
    // admin/session.php + the shared $_SESSION['user_role'] key with
    // bidder/creator login) is confirmed and fixed server-side.
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
    formatMoney(value) {
      return Number(value).toLocaleString("en-PH");
    },
    changePassword() {
      Swal.fire({
        title: "Change Password",
        text: "Not wired up yet.",
        confirmButtonColor: "#0F2245",
      });
    },
    manageTwoFactor() {
      Swal.fire({
        title: "Two-Factor Auth",
        text: "Not wired up yet.",
        confirmButtonColor: "#0F2245",
      });
    },
    logOut() {
      Swal.fire({
        icon: "question",
        title: "Log out?",
        showCancelButton: true,
        confirmButtonText: "Log Out",
        confirmButtonColor: "#EF4444",
      }).then((result) => {
        if (result.isConfirmed) window.location.href = "admin/logout.php";
      });
    },
  },
};
