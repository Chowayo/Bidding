// Front-end only: everything here operates on the mock array below. Swap
// ESCROW_LEDGER_DATA for a fetch() to the real endpoint once it exists, and
// point viewReceipt() at wherever the real receipt document should come from.

// Reuses the shared nav model declared in admin_dashboard.js (loaded first —
// see index.php's <head>), so every admin page stays in sync on one array.
const PAYMONGO_STATUS_STYLES = {
  Holding: { badge: "bg-blue-50 text-blue-600" },
  Released: { badge: "bg-emerald-50 text-emerald-600" },
  Voided: { badge: "bg-slate-100 text-slate-400" },
};

const ESCROW_LEDGER_DATA = [
  {
    id: "TXN-9982",
    item: "Sunset in Dasma",
    creator: "Juan dela Cruz",
    buyerName: "Maria Santos",
    buyerEmail: "maria@email.com",
    paymentMethod: "GCash",
    amount: 5000,
    status: "Holding",
    datetime: "2026-09-17T14:32:00",
  },
  {
    id: "TXN-9981",
    item: "Blue Hour Manila",
    creator: "Lena Buenaventura",
    buyerName: "Nico Reyes",
    buyerEmail: "nico@email.com",
    paymentMethod: "Credit Card •••• 4242",
    amount: 3200,
    status: "Released",
    datetime: "2026-09-17T11:15:00",
  },
  {
    id: "TXN-9980",
    item: "Roots & Branches",
    creator: "Marco Villanueva",
    buyerName: "Chloe Tan",
    buyerEmail: "chloe@email.com",
    paymentMethod: "Maya",
    amount: 8750,
    status: "Holding",
    datetime: "2026-09-16T09:44:00",
  },
  {
    id: "TXN-9979",
    item: "Morning Mist Bataan",
    creator: "Aisha Dela Torre",
    buyerName: "Diego Ramos",
    buyerEmail: "diego@email.com",
    paymentMethod: "GCash",
    amount: 1500,
    status: "Voided",
    datetime: "2026-09-15T17:02:00",
  },
  {
    id: "TXN-9976",
    item: "Halo-Halo Series #3",
    creator: "Paola Reyes",
    buyerName: "Isabel Cruz",
    buyerEmail: "isabel@email.com",
    paymentMethod: "Credit Card •••• 8810",
    amount: 2800,
    status: "Released",
    datetime: "2026-09-14T08:30:00",
  },
];

// Marketplace commission withheld from the sale price before payout to the
// creator. Adjust once the real fee schedule exists.
const PLATFORM_FEE_RATE = 0.01;

const adminEscrowLedgerView = {
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                        {{ adminInitials }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                        <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                    </div>
                    <button type="button" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">Escrow Ledger</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 px-4 sm:px-6 py-6 sm:py-8">

                    <!-- ============ TABLE CARD ============ -->
                    <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">

                        <!-- Card header: title + search, inside the card per the mockup -->
                        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between px-5 sm:px-6 py-5 border-b border-[#DEE2E8]">
                            <h1 class="text-base sm:text-lg font-semibold text-[#0F172A]">Transaction &amp; Escrow Ledger</h1>
                            <div class="relative w-full sm:w-64">
                                <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
                                <input v-model="searchQuery" type="text" placeholder="Search transactions..."
                                    class="w-full h-10 pl-9 pr-3 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] text-sm placeholder:text-[#94A3B8] focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15 focus:bg-white transition-colors">
                            </div>
                        </div>

                        <div v-if="tableError" class="p-6 text-sm text-red-600 bg-red-50">
                            <p class="font-medium">The transaction table failed to load.</p>
                            <p class="mt-1 text-red-500">{{ tableError }}</p>
                            <p class="mt-1 text-red-500">Open the browser console for the full error, and confirm <code>js/tabulator.min.js</code> and <code>css/tabulator.min.css</code> are both being loaded (check the Network tab for a 404).</p>
                        </div>
                        <div v-show="!tableError" ref="tableEl"></div>
                        <div v-if="!tableError && transactions.length === 0" class="py-16 text-center">
                            <svg class="w-10 h-10 mx-auto text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M2.5 10.5h19"/></svg>
                            <p class="mt-3 text-sm font-medium text-[#0F172A]">No transactions yet</p>
                            <p class="text-sm text-[#64748B]">Escrow activity will show up here once auctions start closing.</p>
                        </div>
                    </div>

                </main>
            </div>

            <!-- ============ RECEIPT MODAL ============ -->
            <div v-if="selected" class="fixed inset-0 z-[60] flex items-center justify-center p-4"
                @click.self="closeReceipt">
                <div class="absolute inset-0 bg-black/50 cb-no-print"></div>

                <div class="cb-receipt relative bg-white w-full max-w-sm rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">

                    <div class="cb-no-print sticky top-0 bg-white flex items-center justify-between px-5 py-4 border-b border-[#DEE2E8] rounded-t-2xl">
                        <h2 class="text-base font-semibold text-[#0F172A]">Receipt</h2>
                        <button type="button" @click="closeReceipt" aria-label="Close"
                            class="w-8 h-8 rounded-lg flex items-center justify-center text-[#64748B] hover:bg-[#F8FAFC] transition-colors">
                            <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>

                    <div class="p-6">
                        <!-- Letterhead -->
                        <div class="text-center pb-4 border-b border-dashed border-[#CBD5E1]">
                            <p class="font-serif font-bold text-xl text-[#0F2245]">CanvasBid</p>
                            <p class="mt-0.5 text-xs text-[#94A3B8] tracking-wide">ESCROW PAYMENT RECEIPT</p>
                            <span class="mt-3 inline-block text-xs font-semibold uppercase tracking-wide rounded-full px-2.5 py-1"
                                :class="statusStyle(selected.status).badge">{{ selected.status }}</span>
                        </div>

                        <!-- Transaction meta -->
                        <div class="py-4 border-b border-dashed border-[#CBD5E1] space-y-2 text-sm">
                            <div class="flex justify-between gap-3">
                                <span class="text-[#94A3B8]">Receipt No.</span>
                                <span class="font-medium text-[#0F172A]">#{{ selected.id }}</span>
                            </div>
                            <div class="flex justify-between gap-3">
                                <span class="text-[#94A3B8]">Date &amp; Time</span>
                                <span class="font-medium text-[#0F172A]">{{ formatDateTime(selected.datetime) }}</span>
                            </div>
                            <div class="flex justify-between gap-3">
                                <span class="text-[#94A3B8]">Payment Method</span>
                                <span class="font-medium text-[#0F172A]">{{ selected.paymentMethod }}</span>
                            </div>
                        </div>

                        <!-- Artwork + parties -->
                        <div class="py-4 border-b border-dashed border-[#CBD5E1]">
                            <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Artwork</p>
                            <p class="mt-1 text-sm font-semibold text-[#0F172A]">{{ selected.item }}</p>

                            <div class="mt-3 space-y-2 text-sm">
                                <div class="flex justify-between gap-3">
                                    <span class="text-[#94A3B8]">Creator</span>
                                    <span class="text-right text-[#0F172A]">{{ selected.creator }}</span>
                                </div>
                                <div class="flex justify-between gap-3">
                                    <span class="text-[#94A3B8]">Buyer</span>
                                    <span class="text-right text-[#0F172A]">{{ selected.buyerName }}</span>
                                </div>
                                <div class="flex justify-between gap-3">
                                    <span class="text-[#94A3B8]">Buyer Email</span>
                                    <span class="text-right text-[#0F172A] truncate">{{ selected.buyerEmail }}</span>
                                </div>
                            </div>
                        </div>

                        <!-- Price breakdown -->
                        <div class="py-4 space-y-2 text-sm">
                            <div class="flex justify-between gap-3">
                                <span class="text-[#64748B]">Final Bid Amount</span>
                                <span class="text-[#0F172A]">{{ formatAmount(selected.amount) }}</span>
                            </div>
                            <div class="flex justify-between gap-3">
                                <span class="text-[#64748B]">Platform Fee ({{ feeRatePercent }}%)</span>
                                <span class="text-[#0F172A]">&minus;{{ formatAmount(platformFee(selected.amount)) }}</span>
                            </div>
                            <div class="flex justify-between gap-3 pt-2 border-t border-[#DEE2E8]">
                                <span class="font-semibold text-[#0F172A]">{{ selected.status === 'Voided' ? 'Refunded to Buyer' : 'Net Payout to Creator' }}</span>
                                <span class="font-bold text-[#0F172A]">{{ formatAmount(selected.status === 'Voided' ? selected.amount : payoutAmount(selected.amount)) }}</span>
                            </div>
                        </div>

                        <p class="text-center text-[11px] text-[#94A3B8]">This is a system-generated receipt confirming escrow status via PayMongo.</p>

                        <div class="cb-no-print mt-5 flex flex-col sm:flex-row gap-3">
                            <button type="button" @click="printReceipt"
                                class="flex-1 h-11 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-medium transition-colors flex items-center justify-center gap-1.5">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                                Print
                            </button>
                            <button type="button" @click="closeReceipt"
                                class="flex-1 h-11 rounded-lg border border-[#DEE2E8] hover:bg-[#F8FAFC] text-sm font-medium text-[#0F172A] transition-colors">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      admin: { name: "Super Admin", email: "admin@canvasbid.ph" },
      navItems: typeof ADMIN_NAV_ITEMS !== "undefined" ? ADMIN_NAV_ITEMS : [],
      transactions: ESCROW_LEDGER_DATA.slice(),
      searchQuery: "",
      selected: null,
      table: null,
      tableError: "",
    };
  },
  computed: {
    adminInitials() {
      return this.admin.name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    feeRatePercent() {
      return (PLATFORM_FEE_RATE * 100).toFixed(0);
    },
  },
  watch: {
    searchQuery(value) {
      if (!this.table) return;
      const q = value.trim().toLowerCase();
      if (!q) {
        this.table.clearFilter();
        return;
      }
      this.table.setFilter((data) =>
        [data.id, data.item, data.creator, data.status]
          .join(" ")
          .toLowerCase()
          .includes(q),
      );
    },
  },
  mounted() {
    this.injectTableStyles();
    this.injectPrintStyles();
    // Deferred + try/caught on purpose: a thrown error straight out of
    // mounted() can jam Vue's reactivity scheduler for the whole app (other
    // router-links stop responding), so a Tabulator/DOM problem here must
    // never escape uncaught.
    this.$nextTick(() => this.initTable());
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
    statusStyle(status) {
      return (
        PAYMONGO_STATUS_STYLES[status] || {
          badge: "bg-slate-100 text-[#64748B]",
        }
      );
    },
    formatAmount(value) {
      return "\u20B1" + Number(value).toLocaleString("en-PH");
    },
    formatDateTime(iso) {
      const d = new Date(iso);
      return (
        d.toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
        }) +
        " \u00B7 " +
        d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
      );
    },
    viewReceipt(data) {
      this.selected = data;
    },
    closeReceipt() {
      this.selected = null;
    },
    platformFee(amount) {
      return Math.round(amount * PLATFORM_FEE_RATE);
    },
    payoutAmount(amount) {
      return amount - this.platformFee(amount);
    },
    printReceipt() {
      // Scoped via .cb-receipt / .cb-no-print in injectPrintStyles() so only
      // the receipt itself prints, not the sidebar/table behind it.
      window.print();
    },
    initTable() {
      const self = this;

      if (typeof Tabulator === "undefined") {
        this.tableError =
          "Tabulator library not found (window.Tabulator is undefined).";
        console.error(
          '[escrow_ledger] Tabulator is undefined — check that <script src="js/tabulator.min.js"> loads before router.js and returns 200, not 404.',
        );
        return;
      }
      if (!this.$refs.tableEl) return;

      try {
        this.table = new Tabulator(this.$refs.tableEl, {
          data: this.transactions,
          index: "id",
          layout: "fitColumns",
          responsiveLayout: "collapse",
          responsiveLayoutCollapseStartOpen: false,
          rowHeight: 76,
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: false,
          placeholder: "No transactions found",
          headerSort: true,
          paginationCounter: "rows",
          columns: [
            {
              title: "Transaction ID",
              field: "id",
              minWidth: 150,
              responsive: 0,
              formatter(cell) {
                return `<span style="color:#64748B;font-weight:500;font-size:16px">#${cell.getValue()}</span>`;
              },
            },
            {
              title: "Item & Creator",
              field: "item",
              minWidth: 200,
              responsive: 0,
              formatter(cell) {
                const d = cell.getRow().getData();
                return `
                <div style="display:flex;flex-direction:column;min-width:0">
                    <span style="font-weight:500;color:#0F172A;font-size:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${d.item}</span>
                    <span style="color:#94A3B8;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${d.creator}</span>
                </div>`;
              },
            },
            {
              title: "Amount",
              field: "amount",
              minWidth: 130,
              responsive: 1,
              formatter(cell) {
                return `<span style="font-weight:600;color:#0F172A;font-size:16px">${self.formatAmount(cell.getValue())}</span>`;
              },
            },
            {
              title: "PayMongo Status",
              field: "status",
              minWidth: 160,
              responsive: 2,
              formatter(cell) {
                const status = cell.getValue();
                const style = self.statusStyle(status);
                return `<span class="cb-badge ${style.badge}">${status}</span>`;
              },
            },
            {
              title: "Date & Time",
              field: "datetime",
              minWidth: 170,
              responsive: 3,
              formatter(cell) {
                return `<span style="color:#64748B;font-size:16px">${self.formatDateTime(cell.getValue())}</span>`;
              },
            },
            {
              title: "Actions",
              field: "id",
              minWidth: 130,
              hozAlign: "right",
              headerSort: false,
              responsive: 0,
              formatter() {
                return `<button type="button" class="cb-view-btn" data-view>View Receipt</button>`;
              },
              cellClick(e, cell) {
                if (e.target.closest("[data-view]")) {
                  self.viewReceipt(cell.getRow().getData());
                }
              },
            },
          ],
        });
      } catch (err) {
        this.tableError = err && err.message ? err.message : String(err);
        console.error("[escrow_ledger] Tabulator failed to initialize:", err);
      }
    },
    injectTableStyles() {
      if (document.getElementById("cb-tabulator-theme")) return;
      const style = document.createElement("style");
      style.id = "cb-tabulator-theme";
      style.textContent = `
        .tabulator { border: none; background: transparent; font-family: inherit; font-size: 1rem; }
        .tabulator-header { background: #F8FAFC; border-bottom: 1px solid #DEE2E8; }
        .tabulator-headers { display: flex; }
        .tabulator-col { background: #F8FAFC !important; border-right: none !important; float: none !important; }
        .tabulator-col .tabulator-col-content { padding: 16px 18px; }
        .tabulator-col-title { color: #94A3B8; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; white-space: nowrap; }
        .tabulator-col-sorter { color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col-sorter .tabulator-arrow { border-bottom-color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter,
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter .tabulator-arrow { color: #94A3B8 !important; border-bottom-color: #94A3B8 !important; }
        .tabulator-row { border-bottom: 1px solid #DEE2E8; background: #fff !important; display: flex !important; align-items: stretch; float: none !important; min-height: 76px; }
        .tabulator-row:hover { background: #F8FAFC !important; }
        .tabulator-row .tabulator-cell { display: flex; align-items: center; padding: 20px 18px; font-size: 16px; color: #0F172A; box-sizing: border-box; overflow: hidden; float: none !important; }
        .tabulator-tableholder { overflow: auto; }
        .tabulator-table { display: block; width: 100%; }
        .cb-badge { font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; border-radius: 999px; padding: 6px 14px; }
        .cb-view-btn { height: 38px; padding: 0 16px; border-radius: 8px; border: 1px solid #DEE2E8; background: #fff; color: #0F172A; font-size: 0.875rem; font-weight: 500; cursor: pointer; white-space: nowrap; transition: border-color .15s, color .15s; }
        .cb-view-btn:hover { border-color: #1A56DB; color: #1A56DB; }
        .tabulator .tabulator-footer { background: #fff !important; border-top: 1px solid #DEE2E8 !important; padding: 10px 14px; display: flex !important; align-items: center !important; justify-content: flex-end !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-footer-contents { display: flex !important; align-items: center !important; justify-content: flex-end !important; width: 100% !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-page-counter { color: #94A3B8; font-size: 0.8rem; margin-right: auto !important; order: 1; }
        .tabulator .tabulator-paginator { display: flex !important; align-items: center; gap: 4px; order: 2; margin-left: 0 !important; float: none !important; }
        .tabulator .tabulator-page { border-radius: 8px !important; border: 1px solid #DEE2E8 !important; background: #fff !important; color: #64748B !important; min-width: 30px; padding: 4px 8px !important; font-size: 0.8rem !important; }
        .tabulator .tabulator-page.active { background: #1A56DB !important; border-color: #1A56DB !important; color: #fff !important; }
        .tabulator .tabulator-page:disabled { opacity: 0.4; }
        @media (max-width: 640px) {
          .tabulator .tabulator-footer { display: flex; flex-wrap: wrap; gap: 8px; }
        }
      `;
      document.head.appendChild(style);
    },
    injectPrintStyles() {
      // Separate from the shared cb-tabulator-theme id on purpose: that id is
      // reused across admin pages (auction_queue.js, user_management.js), so
      // whichever page mounts first "wins" and later pages' additions to it
      // never get injected. This stays independent so it's always applied.
      if (document.getElementById("cb-receipt-print")) return;
      const style = document.createElement("style");
      style.id = "cb-receipt-print";
      style.textContent = `
        @media print {
          body * { visibility: hidden; }
          .cb-receipt, .cb-receipt * { visibility: visible; }
          .cb-no-print { display: none !important; }
          .cb-receipt { position: fixed; inset: 0; box-shadow: none !important; border-radius: 0 !important; max-height: none !important; overflow: visible !important; }
        }
      `;
      document.head.appendChild(style);
    },
  },
};
