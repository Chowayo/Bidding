<?php

//SESSION
session_start();

//DB CONNECTION
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "bidding";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Auction Posting
header('Content-Type: application/json');
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    //Auction Approved
    if (isset($_POST['approved_id'])) {
        // Extract all payload variables sent via AJAX
        $id     = $_POST['approved_id'] ?? '';
        $stmt = $conn->prepare("
            UPDATE auctions 
            SET status = 'Approved' 
            WHERE id = ?
        ");

        if ($stmt->execute([$id])) {
            echo json_encode([
                'status'  => 'success',
                'message' => 'Auction approved successfully!'
            ]);
        } else {
            echo json_encode([
                'status'  => 'error', 
                'message' => 'Database error executing update query.'
            ]);
        }
    }

    //Auction Rejected
    if (isset($_POST['reject_id'])) {
        // Extract all payload variables sent via AJAX
        $id     = $_POST['reject_id'] ?? '';
        $stmt = $conn->prepare("
            UPDATE auctions 
            SET status = 'Rejected' 
            WHERE id = ?
        ");

        if ($stmt->execute([$id])) {
            echo json_encode([
                'status'  => 'success',
                'message' => 'Auction rejected successfully!'
            ]);
        } else {
            echo json_encode([
                'status'  => 'error', 
                'message' => 'Database error executing update query.'
            ]);
        }
    }
}




?>