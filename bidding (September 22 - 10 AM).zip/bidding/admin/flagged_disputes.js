// Front-end only: everything here operates on the mock array below. Swap
// FLAGGED_DISPUTES_DATA for a fetch() to the real endpoint once it exists.

// Reuses the shared nav model declared in admin_dashboard.js (loaded first —
// see index.php's <head>), so every admin page stays in sync on one array.
const DISPUTE_STATUS_STYLES = {
  Disputed: { badge: "bg-amber-50 text-amber-600" },
  Resolved: { badge: "bg-emerald-50 text-emerald-600" },
};

const FLAGGED_DISPUTES_DATA = [
  {
    id: "DSP-241",
    item: "Sunset in Dasma",
    creator: "Juan dela Cruz",
    buyerName: "Maria Santos",
    reason: "Item damaged in transit",
    status: "Disputed",
    evidence: {
      type: "photo",
      url: "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=900&q=75",
    },
  },
  {
    id: "DSP-240",
    item: "Roots & Branches",
    creator: "Marco Villanueva",
    buyerName: "Chloe Tan",
    reason: "Fake tracking number provided",
    status: "Disputed",
    evidence: {
      type: "video",
      url: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    },
  },
  {
    id: "DSP-239",
    item: "Blue Hour Manila",
    creator: "Lena Buenaventura",
    buyerName: "Nico Reyes",
    reason: "Item not as described",
    status: "Disputed",
    evidence: {
      type: "photo",
      url: "https://images.unsplash.com/photo-1518818419377-a0a4b8d1f0e8?auto=format&fit=crop&w=900&q=75",
    },
  },
];

const adminFlaggedDisputesView = {
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                        {{ adminInitials }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                        <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                    </div>
                    <button type="button" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">Flagged Disputes</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 px-4 sm:px-6 py-6 sm:py-8">

                    <!-- ============ TABLE CARD ============ -->
                    <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">

                        <!-- Card header: title + auto-release badge + search -->
                        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between px-5 sm:px-6 py-5 border-b border-[#DEE2E8]">
                            <h1 class="text-base sm:text-lg font-semibold text-[#0F172A]">Flagged Disputes</h1>
                            <div class="flex items-center gap-2 w-full sm:w-auto">
                                <div class="relative flex-1 sm:flex-initial sm:w-56">
                                    <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
                                    <input v-model="searchQuery" type="text" placeholder="Search disputes..."
                                        class="w-full h-10 pl-9 pr-3 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] text-sm placeholder:text-[#94A3B8] focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15 focus:bg-white transition-colors">
                                </div>
                                <span v-if="hasOpenDisputes" class="shrink-0 inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg bg-amber-50 text-amber-600 whitespace-nowrap">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                    Auto-release paused
                                </span>
                            </div>
                        </div>

                        <div v-if="tableError" class="p-6 text-sm text-red-600 bg-red-50">
                            <p class="font-medium">The disputes table failed to load.</p>
                            <p class="mt-1 text-red-500">{{ tableError }}</p>
                            <p class="mt-1 text-red-500">Open the browser console for the full error, and confirm <code>js/tabulator.min.js</code> and <code>css/tabulator.min.css</code> are both being loaded (check the Network tab for a 404).</p>
                        </div>
                        <div v-show="!tableError" ref="tableEl"></div>
                        <div v-if="!tableError && disputes.length === 0" class="py-16 text-center">
                            <svg class="w-10 h-10 mx-auto text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5l9 15.5a1 1 0 01-.87 1.5H3.87A1 1 0 013 19l9-15.5z"/><path d="M12 10v4"/></svg>
                            <p class="mt-3 text-sm font-medium text-[#0F172A]">No flagged disputes</p>
                            <p class="text-sm text-[#64748B]">Anything a buyer or creator flags will show up here.</p>
                        </div>
                    </div>

                </main>
            </div>

            <!-- ============ EVIDENCE LIGHTBOX ============ -->
            <div v-if="viewingEvidence" class="fixed inset-0 z-[60] flex items-center justify-center p-4"
                @click.self="closeEvidence">
                <div class="absolute inset-0 bg-black/70"></div>

                <div class="relative bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden">
                    <div class="flex items-center justify-between px-5 py-4 border-b border-[#DEE2E8]">
                        <h2 class="text-sm font-semibold text-[#0F172A]">Submitted evidence \u2014 #{{ viewingEvidence.id }}</h2>
                        <button type="button" @click="closeEvidence" aria-label="Close"
                            class="w-8 h-8 rounded-lg flex items-center justify-center text-[#64748B] hover:bg-[#F8FAFC] transition-colors">
                            <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <div class="bg-[#0B1526] flex items-center justify-center">
                        <img v-if="viewingEvidence.evidence.type === 'photo'" :src="viewingEvidence.evidence.url"
                            :alt="'Evidence for ' + viewingEvidence.item" class="max-h-[70vh] w-full object-contain">
                        <video v-else :src="viewingEvidence.evidence.url" controls autoplay class="max-h-[70vh] w-full"></video>
                    </div>
                    <div class="px-5 py-4 text-sm text-[#64748B]">
                        Submitted by {{ viewingEvidence.buyerName }} regarding "{{ viewingEvidence.item }}" \u2014 {{ viewingEvidence.reason }}
                    </div>
                </div>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      admin: { name: "Super Admin", email: "admin@canvasbid.ph" },
      navItems: typeof ADMIN_NAV_ITEMS !== "undefined" ? ADMIN_NAV_ITEMS : [],
      disputes: FLAGGED_DISPUTES_DATA.slice(),
      searchQuery: "",
      viewingEvidence: null,
      table: null,
      tableError: "",
    };
  },
  computed: {
    adminInitials() {
      return this.admin.name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    hasOpenDisputes() {
      return this.disputes.some((d) => d.status === "Disputed");
    },
  },
  watch: {
    searchQuery(value) {
      if (!this.table) return;
      const q = value.trim().toLowerCase();
      if (!q) {
        this.table.clearFilter();
        return;
      }
      this.table.setFilter((data) =>
        [
          data.id,
          data.item,
          data.creator,
          data.buyerName,
          data.reason,
          data.status,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q),
      );
    },
  },
  mounted() {
    this.injectTableStyles();
    this.injectDisputeActionStyles();
    // Deferred + try/caught on purpose: a thrown error straight out of
    // mounted() can jam Vue's reactivity scheduler for the whole app (other
    // router-links stop responding), so a Tabulator/DOM problem here must
    // never escape uncaught.
    this.$nextTick(() => this.initTable());
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
    statusStyle(status) {
      return (
        DISPUTE_STATUS_STYLES[status] || {
          badge: "bg-slate-100 text-[#64748B]",
        }
      );
    },
    initials(name) {
      return name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    viewEvidence(data) {
      this.viewingEvidence = data;
    },
    closeEvidence() {
      this.viewingEvidence = null;
    },
    async forceRelease(data) {
      const result = await Swal.fire({
        icon: "warning",
        title: "Force release funds?",
        text: `This releases the escrowed payment for "${data.item}" to ${data.creator}, overriding the dispute.`,
        showCancelButton: true,
        confirmButtonText: "Force Release",
        confirmButtonColor: "#10B981",
        cancelButtonColor: "#94A3B8",
      });
      if (result.isConfirmed) {
        this.resolveDispute(data);
        await Swal.fire({
          icon: "success",
          title: "Funds released",
          text: `Payment for "${data.item}" has been released to ${data.creator}.`,
          confirmButtonColor: "#0F2245",
        });
      }
    },
    async refundBuyer(data) {
      const result = await Swal.fire({
        icon: "warning",
        title: "Refund the buyer?",
        text: `This refunds the escrowed payment for "${data.item}" back to ${data.buyerName}, overriding the dispute.`,
        showCancelButton: true,
        confirmButtonText: "Refund Buyer",
        confirmButtonColor: "#EF4444",
        cancelButtonColor: "#94A3B8",
      });
      if (result.isConfirmed) {
        this.resolveDispute(data);
        await Swal.fire({
          icon: "success",
          title: "Refund issued",
          text: `${data.buyerName} has been refunded for "${data.item}".`,
          confirmButtonColor: "#0F2245",
        });
      }
    },
    resolveDispute(data) {
      // Front-end only: drops it from the list rather than calling a real endpoint.
      this.disputes = this.disputes.filter((d) => d.id !== data.id);
      if (this.table) this.table.setData(this.disputes);
    },
    initTable() {
      const self = this;

      if (typeof Tabulator === "undefined") {
        this.tableError =
          "Tabulator library not found (window.Tabulator is undefined).";
        console.error(
          '[flagged_disputes] Tabulator is undefined — check that <script src="js/tabulator.min.js"> loads before router.js and returns 200, not 404.',
        );
        return;
      }
      if (!this.$refs.tableEl) return;

      try {
        this.table = new Tabulator(this.$refs.tableEl, {
          data: this.disputes,
          index: "id",
          layout: "fitColumns",
          responsiveLayout: "collapse",
          responsiveLayoutCollapseStartOpen: false,
          rowHeight: 76,
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: false,
          placeholder: "No flagged disputes found",
          headerSort: true,
          paginationCounter: "rows",
          columns: [
            {
              title: "Auction Item",
              field: "item",
              minWidth: 170,
              responsive: 0,
              formatter(cell) {
                return `<span style="font-weight:500;color:#0F172A;font-size:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${cell.getValue()}</span>`;
              },
            },
            {
              title: "Buyer",
              field: "buyerName",
              minWidth: 170,
              responsive: 1,
              formatter(cell) {
                const name = cell.getValue();
                return `
                <div style="display:flex;align-items:center;gap:10px;min-width:0">
                    <span style="width:28px;height:28px;border-radius:9999px;background:#FFF1F2;color:#E11D48;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0">${self.initials(name)}</span>
                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${name}</span>
                </div>`;
              },
            },
            {
              title: "Creator",
              field: "creator",
              minWidth: 170,
              responsive: 1,
              formatter(cell) {
                const name = cell.getValue();
                return `
                <div style="display:flex;align-items:center;gap:10px;min-width:0">
                    <span style="width:28px;height:28px;border-radius:9999px;background:#EFF6FF;color:#1D4ED8;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0">${self.initials(name)}</span>
                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${name}</span>
                </div>`;
              },
            },
            {
              title: "Reported Reason",
              field: "reason",
              minWidth: 200,
              responsive: 2,
              formatter(cell) {
                return `<span style="color:#64748B;font-size:16px">${cell.getValue()}</span>`;
              },
            },
            {
              title: "Evidence",
              field: "evidence",
              minWidth: 90,
              hozAlign: "center",
              headerSort: false,
              responsive: 0,
              formatter(cell) {
                const d = cell.getRow().getData();
                const isVideo = d.evidence.type === "video";
                const playBadge = isVideo
                  ? `<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.35)"><svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg></span>`
                  : "";
                return `
                <button type="button" data-evidence style="position:relative;width:44px;height:44px;border-radius:8px;overflow:hidden;border:1px solid #DEE2E8;padding:0;cursor:pointer;background:#0B1526">
                    <img src="${d.evidence.url}" alt="" style="width:100%;height:100%;object-fit:cover;display:block" />
                    ${playBadge}
                </button>`;
              },
              cellClick(e, cell) {
                if (e.target.closest("[data-evidence]")) {
                  self.viewEvidence(cell.getRow().getData());
                }
              },
            },
            {
              title: "Status",
              field: "status",
              minWidth: 120,
              responsive: 0,
              formatter(cell) {
                const status = cell.getValue();
                const style = self.statusStyle(status);
                return `<span class="cb-badge ${style.badge}">${status}</span>`;
              },
            },
            {
              title: "Actions",
              field: "id",
              minWidth: 230,
              hozAlign: "left",
              headerSort: false,
              responsive: 0,
              formatter() {
                return `
                <div style="display:flex;gap:8px">
                    <button type="button" data-release class="cb-action-btn cb-action-green">Force Release</button>
                    <button type="button" data-refund class="cb-action-btn cb-action-red">Refund Buyer</button>
                </div>`;
              },
              cellClick(e, cell) {
                const data = cell.getRow().getData();
                if (e.target.closest("[data-release]")) self.forceRelease(data);
                if (e.target.closest("[data-refund]")) self.refundBuyer(data);
              },
            },
          ],
        });
      } catch (err) {
        this.tableError = err && err.message ? err.message : String(err);
        console.error(
          "[flagged_disputes] Tabulator failed to initialize:",
          err,
        );
      }
    },
    injectTableStyles() {
      if (document.getElementById("cb-tabulator-theme")) return;
      const style = document.createElement("style");
      style.id = "cb-tabulator-theme";
      style.textContent = `
        .tabulator { border: none; background: transparent; font-family: inherit; font-size: 1rem; }
        .tabulator-header { background: #F8FAFC; border-bottom: 1px solid #DEE2E8; }
        .tabulator-headers { display: flex; }
        .tabulator-col { background: #F8FAFC !important; border-right: none !important; float: none !important; }
        .tabulator-col .tabulator-col-content { padding: 16px 18px; }
        .tabulator-col-title { color: #94A3B8; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; white-space: nowrap; }
        .tabulator-col-sorter { color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col-sorter .tabulator-arrow { border-bottom-color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter,
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter .tabulator-arrow { color: #94A3B8 !important; border-bottom-color: #94A3B8 !important; }
        .tabulator-row { border-bottom: 1px solid #DEE2E8; background: #fff !important; display: flex !important; align-items: stretch; float: none !important; min-height: 76px; }
        .tabulator-row:hover { background: #F8FAFC !important; }
        .tabulator-row .tabulator-cell { display: flex; align-items: center; padding: 20px 18px; font-size: 16px; color: #0F172A; box-sizing: border-box; overflow: hidden; float: none !important; }
        .tabulator-tableholder { overflow: auto; }
        .tabulator-table { display: block; width: 100%; }
        .cb-badge { font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; border-radius: 999px; padding: 6px 14px; white-space: nowrap; }
        .cb-view-btn { height: 38px; padding: 0 16px; border-radius: 8px; border: 1px solid #DEE2E8; background: #fff; color: #0F172A; font-size: 0.875rem; font-weight: 500; cursor: pointer; white-space: nowrap; transition: border-color .15s, color .15s; }
        .cb-view-btn:hover { border-color: #1A56DB; color: #1A56DB; }
        .tabulator .tabulator-footer { background: #fff !important; border-top: 1px solid #DEE2E8 !important; padding: 10px 14px; display: flex !important; align-items: center !important; justify-content: flex-end !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-footer-contents { display: flex !important; align-items: center !important; justify-content: flex-end !important; width: 100% !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-page-counter { color: #94A3B8; font-size: 0.8rem; margin-right: auto !important; order: 1; }
        .tabulator .tabulator-paginator { display: flex !important; align-items: center; gap: 4px; order: 2; margin-left: 0 !important; float: none !important; }
        .tabulator .tabulator-page { border-radius: 8px !important; border: 1px solid #DEE2E8 !important; background: #fff !important; color: #64748B !important; min-width: 30px; padding: 4px 8px !important; font-size: 0.8rem !important; }
        .tabulator .tabulator-page.active { background: #1A56DB !important; border-color: #1A56DB !important; color: #fff !important; }
        .tabulator .tabulator-page:disabled { opacity: 0.4; }
        @media (max-width: 640px) {
          .tabulator .tabulator-footer { display: flex; flex-wrap: wrap; gap: 8px; }
        }
      `;
      document.head.appendChild(style);
    },
    injectDisputeActionStyles() {
      // Kept independent of #cb-tabulator-theme on purpose — that id is
      // reused across admin pages (auction_queue.js, user_management.js,
      // escrow_ledger.js), so whichever page mounts first "wins" and later
      // pages' additions to it never get injected. These classes are unique
      // to this page, so they always need to land regardless of load order.
      if (document.getElementById("cb-dispute-actions")) return;
      const style = document.createElement("style");
      style.id = "cb-dispute-actions";
      style.textContent = `
        .cb-action-btn { height: 34px; padding: 0 14px; border-radius: 8px; border: none; font-size: 0.8125rem; font-weight: 500; cursor: pointer; white-space: nowrap; transition: filter .15s; }
        .cb-action-btn:hover { filter: brightness(0.96); }
        .cb-action-green { background: #ECFDF5; color: #059669; }
        .cb-action-red { background: #FEF2F2; color: #DC2626; }
      `;
      document.head.appendChild(style);
    },
  },
};
