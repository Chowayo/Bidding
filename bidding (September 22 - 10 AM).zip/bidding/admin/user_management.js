const ROLE_STYLES = {
  Bidder: "bg-blue-50 text-blue-600",
  Creator: "bg-purple-50 text-purple-600",
};

const STATUS_STYLES = {
  Active: "bg-emerald-50 text-emerald-600",
  Suspended: "bg-red-50 text-red-600",
};

const USER_MANAGEMENT_DATA = [
  {
    id: 1,
    name: "Maria Santos",
    phone: "+63 912 345 6789",
    email: "maria@mail.com",
    role: "Bidder",
    status: "Active",
    joined: "2026-02-11",
  },
  {
    id: 2,
    name: "Juan dela Cruz",
    phone: "+63 917 234 5678",
    email: "juan@mail.com",
    role: "Creator",
    status: "Active",
    joined: "2026-01-28",
  },
  {
    id: 3,
    name: "Andrea Reyes",
    phone: "+63 920 111 2222",
    email: "andrea@mail.com",
    role: "Bidder",
    status: "Active",
    joined: "2026-03-02",
  },
  {
    id: 4,
    name: "Carlo Mendez",
    phone: "+63 908 999 0001",
    email: "carlo@mail.com",
    role: "Creator",
    status: "Suspended",
    joined: "2025-11-19",
  },
  {
    id: 5,
    name: "Sofia Lim",
    phone: "+63 915 777 8888",
    email: "sofia@mail.com",
    role: "Bidder",
    status: "Active",
    joined: "2026-04-06",
  },
  {
    id: 6,
    name: "Nico Reyes",
    phone: "+63 919 333 4444",
    email: "nico@mail.com",
    role: "Bidder",
    status: "Suspended",
    joined: "2025-12-30",
  },
  {
    id: 7,
    name: "Patricia Uy",
    phone: "+63 917 555 1212",
    email: "patricia@mail.com",
    role: "Creator",
    status: "Active",
    joined: "2026-05-14",
  },
  {
    id: 8,
    name: "Enzo Lim",
    phone: "+63 921 444 7890",
    email: "enzo@mail.com",
    role: "Bidder",
    status: "Active",
    joined: "2026-02-27",
  },
  {
    id: 9,
    name: "Grace Espino",
    phone: "+63 918 222 3344",
    email: "grace@mail.com",
    role: "Creator",
    status: "Active",
    joined: "2026-01-05",
  },
  {
    id: 10,
    name: "Miguel Cruz",
    phone: "+63 910 666 9988",
    email: "miguel@mail.com",
    role: "Bidder",
    status: "Suspended",
    joined: "2025-10-22",
  },
  {
    id: 11,
    name: "Iris Manalo",
    phone: "+63 927 888 0033",
    email: "iris@mail.com",
    role: "Bidder",
    status: "Active",
    joined: "2026-03-19",
  },
  {
    id: 12,
    name: "Renz Katigbak",
    phone: "+63 905 111 6677",
    email: "renz@mail.com",
    role: "Creator",
    status: "Active",
    joined: "2026-04-30",
  },
];

const USER_FILTER_OPTIONS = [
  { value: "all", label: "All Users" },
  { value: "bidder", label: "Bidders" },
  { value: "creator", label: "Creators" },
  { value: "active", label: "Active" },
  { value: "suspended", label: "Suspended" },
];

const adminUserManagementView = {
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                        {{ adminInitials }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                        <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                    </div>
                    <button type="button" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">User Management</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 px-4 sm:px-6 py-6 sm:py-8">

                    <!-- ============ PAGE HEADER ============ -->
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div class="min-w-0">
                            <h1 class="text-lg sm:text-xl font-semibold text-[#0F172A]">User & Ban Management</h1>
                            <p class="mt-0.5 text-sm text-[#64748B]">View, search, and manage bidder and creator accounts</p>
                        </div>

                        <div class="flex items-center gap-2.5 shrink-0">
                            <div class="relative flex-1 sm:flex-none">
                                <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
                                <input v-model="searchQuery" type="text" placeholder="Search users..."
                                    class="w-full sm:w-56 h-10 pl-9 pr-3 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] text-sm placeholder:text-[#94A3B8] focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15 focus:bg-white transition-colors">
                            </div>
                            <div class="relative shrink-0">
                                <select v-model="roleFilter"
                                    class="h-10 pl-3.5 pr-9 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] text-sm text-[#0F172A] focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15 focus:bg-white transition-colors appearance-none cursor-pointer">
                                    <option v-for="opt in filterOptions" :key="opt.value" :value="opt.value">{{ opt.label }}</option>
                                </select>
                                <svg class="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] pointer-events-none" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>
                            </div>
                        </div>
                    </div>

                    <!-- ============ TABLE CARD ============ -->
                    <div class="mt-4 bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                        <div v-if="tableError" class="p-6 text-sm text-red-600 bg-red-50">
                            <p class="font-medium">The user table failed to load.</p>
                            <p class="mt-1 text-red-500">{{ tableError }}</p>
                            <p class="mt-1 text-red-500">Open the browser console for the full error, and confirm <code>js/tabulator.min.js</code> and <code>css/tabulator.min.css</code> are both being loaded (check the Network tab for a 404).</p>
                        </div>
                        <div v-show="!tableError" ref="tableEl"></div>
                        <div v-if="!tableError && users.length === 0" class="py-16 text-center">
                            <svg class="w-10 h-10 mx-auto text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c.7-3.4 3.4-5.5 6.5-5.5s5.8 2.1 6.5 5.5"/></svg>
                            <p class="mt-3 text-sm font-medium text-[#0F172A]">No users found</p>
                            <p class="text-sm text-[#64748B]">Try a different search term or filter.</p>
                        </div>
                    </div>

                </main>
            </div>

            <!-- ============ ROW ACTIONS MENU (floating, escapes table overflow) ============ -->
            <div v-if="menuUser" class="fixed inset-0 z-[55]" @click="closeMenu"></div>
            <div v-if="menuUser" class="fixed z-[56] w-48 bg-white rounded-lg border border-[#DEE2E8] shadow-lg py-1.5"
                :style="{ top: menuPos.top + 'px', left: menuPos.left + 'px' }">
                <button type="button" @click="viewProfile(menuUser)"
                    class="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-[#0F172A] hover:bg-[#F8FAFC] transition-colors">
                    <svg class="w-4 h-4 text-[#64748B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                    View Profile
                </button>
                <button v-if="menuUser.status === 'Active'" type="button" @click="confirmSuspend(menuUser)"
                    class="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-[#EF4444] hover:bg-red-50 transition-colors">
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 8l8 8"/></svg>
                    Suspend Account
                </button>
                <button v-else type="button" @click="confirmReactivate(menuUser)"
                    class="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-[#10B981] hover:bg-emerald-50 transition-colors">
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                    Reactivate Account
                </button>
            </div>

            <!-- ============ PROFILE MODAL ============ -->
            <div v-if="selected" class="fixed inset-0 z-[60] flex items-center justify-center p-4"
                @click.self="closeModal">
                <div class="absolute inset-0 bg-black/50"></div>

                <div class="relative bg-white w-full max-w-sm rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
                    <div class="sticky top-0 bg-white flex items-center justify-between px-5 py-4 border-b border-[#DEE2E8] rounded-t-2xl">
                        <h2 class="text-base font-semibold text-[#0F172A]">User Profile</h2>
                        <button type="button" @click="closeModal" aria-label="Close"
                            class="w-8 h-8 rounded-lg flex items-center justify-center text-[#64748B] hover:bg-[#F8FAFC] transition-colors">
                            <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>

                    <div class="p-5">
                        <div class="flex items-center gap-3">
                            <span class="w-14 h-14 rounded-full bg-slate-100 text-[#334155] flex items-center justify-center text-base font-semibold shrink-0">{{ initials(selected.name) }}</span>
                            <div class="min-w-0">
                                <p class="text-base font-semibold text-[#0F172A] truncate">{{ selected.name }}</p>
                                <div class="mt-1 flex items-center gap-1.5 flex-wrap">
                                    <span class="text-xs font-semibold uppercase tracking-wide rounded-full px-2 py-0.5" :class="roleStyle(selected.role)">{{ selected.role }}</span>
                                    <span class="text-xs font-semibold uppercase tracking-wide rounded-full px-2 py-0.5" :class="statusStyle(selected.status)">{{ selected.status }}</span>
                                </div>
                            </div>
                        </div>

                        <div class="mt-5 grid grid-cols-1 gap-3 bg-[#F8FAFC] rounded-lg p-4">
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Email</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.email }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Phone</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.phone }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Member Since</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ formatDate(selected.joined) }}</p>
                            </div>
                        </div>

                        <div class="mt-5">
                            <button v-if="selected.status === 'Active'" type="button" @click="confirmSuspend(selected)"
                                class="w-full h-11 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-sm font-medium transition-colors flex items-center justify-center gap-1.5">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 8l8 8"/></svg>
                                Suspend Account
                            </button>
                            <button v-else type="button" @click="confirmReactivate(selected)"
                                class="w-full h-11 rounded-lg bg-[#10B981] hover:bg-emerald-600 text-white text-sm font-medium transition-colors flex items-center justify-center gap-1.5">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                                Reactivate Account
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      admin: { name: "Super Admin", email: "admin@canvasbid.ph" },
      navItems: typeof ADMIN_NAV_ITEMS !== "undefined" ? ADMIN_NAV_ITEMS : [],
      users: USER_MANAGEMENT_DATA.slice(),
      filterOptions: USER_FILTER_OPTIONS,
      searchQuery: "",
      roleFilter: "all",
      selected: null,
      menuUser: null,
      menuPos: { top: 0, left: 0 },
      table: null,
      tableError: "",
    };
  },
  computed: {
    adminInitials() {
      return this.initials(this.admin.name);
    },
  },
  watch: {
    searchQuery() {
      this.applyFilter();
    },
    roleFilter() {
      this.applyFilter();
    },
  },
  mounted() {
    this.injectTableStyles();
    this.$nextTick(() => this.initTable());
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
    initials(name) {
      return name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    roleStyle(role) {
      return ROLE_STYLES[role] || "bg-slate-100 text-[#64748B]";
    },
    statusStyle(status) {
      return STATUS_STYLES[status] || "bg-slate-100 text-[#64748B]";
    },
    formatDate(iso) {
      const d = new Date(iso);
      return d.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      });
    },
    applyFilter() {
      if (!this.table) return;
      const q = this.searchQuery.trim().toLowerCase();
      const f = this.roleFilter;
      this.table.setFilter((data) => {
        const matchesQuery =
          !q ||
          [data.name, data.email, data.phone]
            .join(" ")
            .toLowerCase()
            .includes(q);
        let matchesFilter = true;
        if (f === "bidder") matchesFilter = data.role === "Bidder";
        else if (f === "creator") matchesFilter = data.role === "Creator";
        else if (f === "active") matchesFilter = data.status === "Active";
        else if (f === "suspended") matchesFilter = data.status === "Suspended";
        return matchesQuery && matchesFilter;
      });
    },
    openMenu(event, user) {
      if (this.menuUser && this.menuUser.id === user.id) {
        this.closeMenu();
        return;
      }
      const rect = event.currentTarget.getBoundingClientRect();
      const menuWidth = 192;
      this.menuPos = {
        top: rect.bottom + 6,
        left: Math.min(
          rect.right - menuWidth,
          window.innerWidth - menuWidth - 12,
        ),
      };
      this.menuUser = user;
    },
    closeMenu() {
      this.menuUser = null;
    },
    viewProfile(user) {
      this.selected = user;
      this.closeMenu();
    },
    closeModal() {
      this.selected = null;
    },
    async confirmSuspend(user) {
      this.closeMenu();
      const result = await Swal.fire({
        icon: "warning",
        title: "Suspend this account?",
        html: `<span style="color:#64748B">${user.name} will lose access to bidding and creator tools until reactivated.</span>`,
        showCancelButton: true,
        confirmButtonText: "Suspend",
        cancelButtonText: "Cancel",
        confirmButtonColor: "#EF4444",
        cancelButtonColor: "#E2E8F0",
        reverseButtons: true,
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
      if (!result.isConfirmed) return;
      this.setStatus(user.id, "Suspended");
      Swal.fire({
        icon: "success",
        title: "Account suspended",
        text: `${user.name} has been suspended.`,
        timer: 1600,
        showConfirmButton: false,
        iconColor: "#EF4444",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
    },
    async confirmReactivate(user) {
      this.closeMenu();
      const result = await Swal.fire({
        icon: "question",
        title: "Reactivate this account?",
        html: `<span style="color:#64748B">${user.name} will regain full access immediately.</span>`,
        showCancelButton: true,
        confirmButtonText: "Reactivate",
        cancelButtonText: "Cancel",
        confirmButtonColor: "#10B981",
        cancelButtonColor: "#E2E8F0",
        reverseButtons: true,
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
      if (!result.isConfirmed) return;
      this.setStatus(user.id, "Active");
      Swal.fire({
        icon: "success",
        title: "Account reactivated",
        text: `${user.name} can access CanvasBid again.`,
        timer: 1600,
        showConfirmButton: false,
        iconColor: "#10B981",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
    },
    setStatus(id, status) {
      const user = this.users.find((u) => u.id === id);
      if (user) user.status = status;
      if (this.selected && this.selected.id === id)
        this.selected.status = status;
      if (this.table) this.table.updateData([{ id, status }]);
    },
    initTable() {
      const self = this;

      if (typeof Tabulator === "undefined") {
        this.tableError =
          "Tabulator library not found (window.Tabulator is undefined).";
        console.error(
          '[user_management] Tabulator is undefined — check that <script src="js/tabulator.min.js"> loads before router.js and returns 200, not 404.',
        );
        return;
      }
      if (!this.$refs.tableEl) return;

      try {
        this.table = new Tabulator(this.$refs.tableEl, {
          data: this.users,
          index: "id",
          layout: "fitColumns",
          responsiveLayout: "collapse",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: false,
          paginationCounter: "rows",
          placeholder: "No users found",
          headerSort: true,
          columns: [
            {
              title: "User Info",
              field: "name",
              minWidth: 240,
              responsive: 0,
              formatter(cell) {
                const d = cell.getRow().getData();
                return `
                  <div class="cb-user-cell">
                      <span class="cb-avatar">${self.initials(d.name)}</span>
                      <div class="cb-user-text">
                          <span class="cb-user-name">${d.name}</span>
                          <span class="cb-user-sub">${d.phone} \u00B7 ${d.email}</span>
                      </div>
                  </div>`;
              },
            },
            {
              title: "Role",
              field: "role",
              minWidth: 110,
              responsive: 2,
              formatter(cell) {
                const role = cell.getValue();
                return `<span class="cb-badge ${self.roleStyle(role)}">${role}</span>`;
              },
            },
            {
              title: "Status",
              field: "status",
              minWidth: 110,
              responsive: 1,
              formatter(cell) {
                const status = cell.getValue();
                return `<span class="cb-badge ${self.statusStyle(status)}">${status}</span>`;
              },
            },
            {
              title: "Actions",
              field: "id",
              minWidth: 120,
              hozAlign: "right",
              headerSort: false,
              responsive: 0,
              formatter() {
                return `<button type="button" class="cb-view-btn" data-view>View Profile</button>`;
              },
              cellClick(e, cell) {
                const btn = e.target.closest("[data-view]");
                if (btn) self.viewProfile(cell.getRow().getData());
              },
            },
          ],
        });
      } catch (err) {
        this.tableError = err && err.message ? err.message : String(err);
        console.error("[user_management] Tabulator failed to initialize:", err);
      }
    },
    injectTableStyles() {
      if (document.getElementById("cb-tabulator-theme")) return;
      const style = document.createElement("style");
      style.id = "cb-tabulator-theme";
      style.textContent = `
        .tabulator { border: none; background: transparent; font-family: inherit; font-size: 0.875rem; }
        .tabulator-header { background: #F8FAFC; border-bottom: 1px solid #DEE2E8; }
        .tabulator-headers { display: flex; }
        .tabulator-col { background: #F8FAFC !important; border-right: none !important; float: none !important; }
        .tabulator-col-title { color: #94A3B8; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; white-space: nowrap; }
        .tabulator-row { border-bottom: 1px solid #DEE2E8; background: #fff !important; display: flex !important; align-items: stretch; float: none !important; }
        .tabulator-row:hover { background: #F8FAFC !important; }
        .tabulator-row .tabulator-cell { display: flex; align-items: center; padding: 10px 14px; color: #0F172A; box-sizing: border-box; overflow: hidden; float: none !important; }
        .tabulator-tableholder { overflow: auto; }
        .tabulator-table { display: block; width: 100%; }
        .cb-user-cell { display: flex; align-items: center; gap: 10px; min-width: 0; }
        .cb-avatar { width: 34px; height: 34px; border-radius: 9999px; background: #F1F5F9; color: #334155; font-size: 0.7rem; font-weight: 600; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .cb-user-text { display: flex; flex-direction: column; min-width: 0; }
        .cb-user-name { font-weight: 500; color: #0F172A; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cb-user-sub { color: #94A3B8; font-size: 0.75rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cb-badge { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; border-radius: 999px; padding: 2px 10px; }
        .cb-dots-btn { width: 32px; height: 32px; border-radius: 8px; border: none; background: transparent; color: #64748B; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: background-color .15s, color .15s; margin-left: auto; }
        .cb-dots-btn:hover { background: #F1F5F9; color: #0F172A; }
        .cb-view-btn { margin-left: auto; height: 32px; padding: 0 14px; border-radius: 8px; border: 1px solid #DEE2E8; background: #fff; color: #0F172A; font-size: 0.8rem; font-weight: 500; cursor: pointer; transition: background-color .15s, border-color .15s; }
        .cb-view-btn:hover { background: #F8FAFC; border-color: #94A3B8; }
        .tabulator-footer { background: #fff !important; border-top: 1px solid #DEE2E8 !important; padding: 10px 14px; display: flex !important; align-items: center !important; justify-content: flex-end !important; flex-wrap: wrap; gap: 12px; }
        .tabulator-footer-contents { display: flex !important; align-items: center !important; justify-content: flex-end !important; width: 100% !important; flex-wrap: wrap; gap: 12px; }
        .tabulator-page-counter { color: #94A3B8; font-size: 0.8rem; margin-right: auto; order: 1; }
        .tabulator-paginator { display: flex !important; align-items: center; gap: 4px; order: 2; margin-left: 0 !important; float: none !important; }
        .tabulator-paginator > button:first-child,
        .tabulator-paginator > button:last-child { display: none; }
        .tabulator-page { border-radius: 8px !important; border: 1px solid #DEE2E8 !important; background: #fff !important; color: #64748B !important; min-width: 30px; padding: 4px 8px !important; font-size: 0.8rem !important; }
        .tabulator-page.active { background: #1A56DB !important; border-color: #1A56DB !important; color: #fff !important; }
        .tabulator-page:disabled { opacity: 0.4; }
        @media (max-width: 640px) {
          .tabulator-footer { display: flex; flex-wrap: wrap; gap: 8px; }
        }
      `;
      document.head.appendChild(style);
    },
  },
};
