<?php

//SESSION
session_start();

//DB CONNECTION
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "bidding";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Auction Posting
header('Content-Type: application/json');
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['bidType'])) {
        // Extract all payload variables sent via AJAX
        $creatorId     = $_POST['creatorId'] ?? '';
        $bidType       = $_POST['bidType'] ?? '';
        $title         = $_POST['title'] ?? '';
        $description   = $_POST['description'] ?? '';
        $minimum       = $_POST['minimum'] ?? '';
        $increment     = $_POST['increment'] ?? '';
        $dutchFloor    = $_POST['dutchFloor'] ?? '';
        $dutchInterval = $_POST['dutchInterval'] ?? '';
        $dutchDrop     = $_POST['dutchDrop'] ?? '';
        $timeStart     = $_POST['timeStart'] ?? ''; //NOTE: Ma s-set lang to kapag na approve na if instant yung naka select pero kapag may sched, sa sched parin mag b-base
        $dateStart      = $_POST['dateStart'] ?? ''; //NOTE: Ma s-set lang to kapag na approve na if instant yung naka select pero kapag may sched, sa sched parin mag b-base
        $timeFrame     = $_POST['timeFrame'] ?? '';
        $delivery      = $_POST['delivery'] ?? '';
        $paymentPeriod = $_POST['paymentPeriod'] ?? '';

        // "No Info" defaults based on bidType
        if (empty($increment)) $increment = "No Info";
        if (empty($dutchFloor)) $dutchFloor = "No Info";
        if (empty($dutchInterval) || $bidType !== "dutch") $dutchInterval = "No Info";
        if (empty($dutchDrop)) $dutchDrop = "No Info";

        if (!empty($title) && !empty($description)) {

            // Handle Image Upload First
            $imagePath = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['image'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

                if ($file['size'] > 5 * 1024 * 1024) {
                    echo json_encode(['status' => 'error', 'message' => 'File size exceeds 5MB limit.']);
                    exit();
                }

                if (!in_array($ext, $allowed)) {
                    echo json_encode(['status' => 'error', 'message' => 'Invalid file extension.']);
                    exit();
                }

                if (!is_dir('uploads')) {
                    mkdir('uploads', 0755, true);
                }

                $target = 'uploads/' . uniqid('img_', true) . '.' . $ext;
                if (move_uploaded_file($file['tmp_name'], $target)) {
                    $imagePath = $target;
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to save uploaded image.']);
                    exit();
                }
            }

            $stmt = $conn->prepare("
                INSERT INTO auctions (
                    creator_id, type, title, description, minimum, increment, 
                    dutch_floor, dutch_interval, dutch_drop, time_start, date_start,
                    time_frame, delivery, payment_period, image_path
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $params = [
                $creatorId, $bidType, $title, $description, $minimum, $increment,
                $dutchFloor, $dutchInterval, $dutchDrop, $timeStart, $dateStart, 
                $timeFrame, $delivery, $paymentPeriod, $imagePath
            ];

            if ($stmt->execute($params)) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Auction created successfully!',
                    'filePath' => $imagePath
                ]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database error executing query.']);
            }

        } else {
            echo json_encode(['status' => 'error', 'message' => 'Title and Description are required.']);
        }
    }
}




?>