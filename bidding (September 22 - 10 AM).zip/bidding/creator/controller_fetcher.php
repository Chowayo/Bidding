<?php
//SESSION

session_start();
header('Content-Type: application/json');

//DB CONNECTION
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "bidding";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


//Loader of all info based on what's needed
$action = $_GET['action'] ?? '';

switch ($action) {

    //To check if session is active
    case 'session_checker':
        sessionCheck($conn);
        break;

    //To get creator Info
    case 'get_creator_info':
        getInfo($conn);
        break;

    case 'get_creator_auctions':
        getAuctions($conn);
        break;

    default:
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing action parameter"]);
        break;
}


function sessionCheck($conn) {
    if(isset($_SESSION['user_id'])){
        $session_status = $_SESSION['user_id'];
    }else{
        $session_status = "Inactive";
    }
    echo json_encode($session_status);
}

function getInfo($conn) {
    $user = $conn->execute_query(
    'SELECT * FROM users WHERE id = ? LIMIT 1', 
        [$_SESSION['user_id']]
    )->fetch_assoc();
    
    echo json_encode($user);
}

function getAuctions($conn) {
    $auctions = $conn->execute_query(
        'SELECT * FROM auctions WHERE creator_id = ?',
        [$_SESSION['user_id']]
    )->fetch_all(MYSQLI_ASSOC);

    echo json_encode($auctions);
}

?>