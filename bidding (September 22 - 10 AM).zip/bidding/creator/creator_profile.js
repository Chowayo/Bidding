// Icons sourced from Lucide (lucide.dev, ISC licensed) — rendered as plain
// inline SVG, same convention as creator_dashboard.js / admin_dashboard.js.
const PROFILE_ICONS = {
  chevronRight: '<path d="M9 18l6-6-6-6"/>',
  checkCircle:
    '<circle cx="12" cy="12" r="9"/><path d="M8.5 12.2l2.4 2.4 4.6-5.2"/>',
  wallet:
    '<path d="M3 7a2 2 0 012-2h13a1 1 0 011 1v3"/><path d="M3 7v11a2 2 0 002 2h15a1 1 0 001-1v-7a1 1 0 00-1-1h-5a2 2 0 000 4h5.5"/>',
  logOut:
    '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
};

const ProfileIcon = {
  props: { name: String },
  template: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" v-html="PROFILE_ICONS[name] || ''"></svg>`,
  created() {
    this.PROFILE_ICONS = PROFILE_ICONS;
  },
};

const creatorProfileView = {
  components: { "profile-icon": ProfileIcon },
  template: `

        
        <div class="min-h-screen flex flex-col bg-[#F8FAFC]">

            <p>{{infoloader}}<!--NEEDED TO BE LOADED--></p>
            <p>{{auctionsLoader}}<!--NEEDED TO BE LOADED--></p>
            <p>{{sessionCheck}}<!--NEEDED TO BE LOADED--></p>
            <!--<p>{{creatorInfo.first_name}}</p>-->

            <!-- ============ TOP NAV ============ -->
            <header class="bg-[#0F2245] text-white sticky top-0 z-40">
                <div class="w-full px-4 sm:px-6 lg:px-8">
                    <div class="h-14 sm:h-16 flex items-center justify-between gap-4">

                        <div class="flex items-center gap-8 min-w-0">
                            <router-link to="/creator/dashboard" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

                            <nav class="hidden md:flex items-center gap-6">
                                <router-link to="/creator/dashboard" class="text-sm text-white/70 hover:text-white transition-colors">My Auctions</router-link>
                                <span class="text-sm text-white/30 cursor-not-allowed">Orders</span>
                                <span class="text-sm text-white/30 cursor-not-allowed">Deposit Tracker</span>
                            </nav>
                        </div>

                        <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                            <button type="button" @click="$router.push('/creator/new-auction')"
                                class="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-white text-[#0F2245] text-sm font-medium hover:bg-white/90 transition-colors">
                                <profile-icon name="plus" class="w-4 h-4" />
                                New Auction
                            </button>

                            <button type="button" @click="mobileMenu = !mobileMenu"
                                class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
                                {{ initials }}
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Avatar dropdown -->
                <div v-show="mobileMenu" class="border-t border-white/10 bg-[#0F2245]">
                    <div class="px-4 py-3 space-y-1">
                        <router-link to="/creator/dashboard" @click="mobileMenu = false" class="block px-3 py-2.5 rounded-lg text-sm text-white/70 hover:bg-white/5">My Auctions</router-link>
                        <span class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">Orders</span>
                        <span class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">Deposit Tracker</span>
                        <button type="button" @click="logOut" class="w-full text-left px-3 py-2.5 rounded-lg text-sm text-red-300 hover:bg-white/5">Log Out</button>
                    </div>
                </div>
            </header>

            <!-- ============ MAIN ============ -->
            <main class="flex-1 w-full max-w-5xl px-4 sm:px-6 lg:px-8 py-6 sm:py-8 mx-auto">

                <!-- Profile header card -->
                <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                    <div class="relative h-20 sm:h-24 bg-[#0F2245]"
                        style="background-image: repeating-linear-gradient(135deg, rgba(255,255,255,0.04) 0 2px, transparent 2px 14px);">
                        <span class="absolute top-3 right-3 text-[10px] font-semibold uppercase tracking-wider bg-white/15 text-white rounded-full px-2.5 py-1">
                            Creator Account
                        </span>
                    </div>

                    <div class="px-5 sm:px-6 pt-4 pb-5 sm:pb-6">
                        <h1 class="text-lg sm:text-xl font-semibold">{{ creator.firstName }} {{ creator.lastName }}</h1>
                        <p class="mt-0.5 text-sm text-[#64748B]">{{ creator.email }} &middot; {{ creator.mobile }}</p>

                        <div class="mt-3 flex flex-wrap items-center gap-2">
                            <span class="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-[#10B981]/10 text-[#10B981]">
                                <profile-icon name="checkCircle" class="w-3.5 h-3.5" />
                                Verified Creator
                            </span>
                            <span v-if="creator.payout" class="text-xs font-medium px-2.5 py-1 rounded-full bg-[#F59E0B]/10 text-[#F59E0B]">
                                {{ creator.payout.provider }} Connected
                            </span>
                        </div>
                    </div>
                </div>

                <!-- ============ CONTENT GRID ============ -->
                <div class="mt-4 sm:mt-5 grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5">

                    <!-- Right column on desktop, shown first on mobile -->
                    <div class="order-1 lg:order-2 lg:col-span-2 space-y-4 sm:space-y-5">

                        <!-- Stat cards -->
                        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                            <div v-for="stat in stats" :key="stat.label" class="bg-white rounded-xl border border-[#DEE2E8] px-4 py-4">
                                <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B] truncate">{{ stat.label }}</p>
                                <p class="mt-1.5 font-serif text-xl sm:text-2xl font-bold leading-none" :class="stat.accent">{{ stat.value }}</p>
                            </div>
                        </div>

                        <!-- My Auctions -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                            <div class="px-5 py-4 border-b border-[#DEE2E8] flex items-center justify-between">
                                <h2 class="text-sm font-semibold">My Auctions</h2>
                                <button type="button" @click="$router.push('/creator/new-auction')"
                                    class="inline-flex items-center gap-1 h-8 px-3 rounded-lg bg-[#1A56DB] hover:bg-[#1A56DB]/90 text-white text-xs font-medium transition-colors">
                                    <profile-icon name="plus" class="w-3.5 h-3.5" />
                                    New
                                </button>
                            </div>
                            <ul class="divide-y divide-[#DEE2E8]">
                                <li v-for="a in auctions" :key="a.id" @click="$router.push('/creator/auctions/' + a.id)"
                                    class="flex items-center gap-3 px-5 py-3 cursor-pointer hover:bg-[#F8FAFC] transition-colors">
                                    <img :src="a.image" :alt="a.title" class="w-10 h-10 rounded-lg object-cover shrink-0">
                                    <p class="flex-1 min-w-0 text-sm font-medium truncate">{{ a.title }}</p>
                                    <span class="text-sm font-semibold text-[#10B981] shrink-0">&#8369;{{ formatMoney(a.topBid) }}</span>
                                    <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full shrink-0" :class="statusClass(a.status)">{{ a.status }}</span>
                                </li>
                            </ul>
                        </div>

                        <!-- Pending payout -->
                        <div v-if="pendingPayout" class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                            <div class="px-5 py-4 border-b border-[#DEE2E8]">
                                <h2 class="text-sm font-semibold">Pending Payout</h2>
                            </div>
                            <div class="mx-5 my-5 rounded-lg bg-[#F59E0B]/10 px-4 py-3.5 flex items-center justify-between gap-3 flex-wrap">
                                <div class="min-w-0">
                                    <p class="text-sm font-medium truncate">{{ pendingPayout.title }} &mdash; Winner Confirmed</p>
                                    <p class="text-xs text-[#64748B] mt-0.5">{{ pendingPayout.note }}</p>
                                </div>
                                <span class="font-serif text-lg font-bold text-[#F59E0B] shrink-0">&#8369;{{ formatMoney(pendingPayout.amount) }}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Left column on desktop, shown second on mobile -->
                    <div class="order-2 lg:order-1 space-y-4 sm:space-y-5">

                        <!-- Personal info -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Personal Info</p>
                            <dl class="mt-3 space-y-3">
                                <div v-for="field in personalFields" :key="field.label">
                                    <dt class="text-[11px] font-semibold tracking-[0.06em] uppercase text-[#94A3B8]">{{ field.label }}</dt>
                                    <dd class="text-sm mt-0.5">{{ field.value }}</dd>
                                </div>
                            </dl>
                        </div>

                        <!-- Payout method -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Payout Method</p>

                            <div v-if="creator.payout" class="mt-3 flex items-center gap-3 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] px-3.5 py-3">
                                <span class="w-9 h-9 rounded-full bg-[#1A56DB]/10 text-[#1A56DB] flex items-center justify-center shrink-0">
                                    <profile-icon name="wallet" class="w-4 h-4" />
                                </span>
                                <div class="min-w-0 flex-1">
                                    <p class="text-sm font-medium">{{ creator.payout.provider }}</p>
                                    <p class="text-xs text-[#64748B] truncate">{{ creator.payout.masked }}</p>
                                </div>
                                <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[#10B981]/10 text-[#10B981] shrink-0">Active</span>
                            </div>

                            <button type="button" @click="addPayoutMethod" class="mt-3 text-sm font-medium text-[#1A56DB] hover:underline">
                                + Add payout method
                            </button>
                        </div>

                        <!-- Security -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Security</p>
                            <div class="mt-2 divide-y divide-[#DEE2E8]">
                                <button type="button" @click="changePassword" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                    Change Password
                                    <profile-icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                </button>
                                <button type="button" @click="manageTwoFactor" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                    Two-Factor Auth
                                    <profile-icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                </button>
                            </div>
                        </div>

                        <button type="button" @click="logOut"
                            class="w-full h-11 rounded-lg border border-[#EF4444]/30 text-[#EF4444] text-sm font-medium hover:bg-[#EF4444]/5 transition-colors flex items-center justify-center gap-2">
                            <profile-icon name="logOut" class="w-4 h-4" />
                            Log Out
                        </button>
                    </div>
                </div>
            </main>
        </div>
    `,
  data() {
    return {

      mobileMenu: false,
      // Front-end only — mock data, swap for the real creator-profile endpoint once it exists.
      creator: {
        firstName: "",
        lastName: "",
        email: "",
        mobile: "",
        payout: {
          provider: "GCash",
          masked: "+63 917 ••• *678",
        },
      },
      metrics: {
        auctionsRun: 12,
        artworksSold: 9,
        totalEarned: 62800,
      },
      auctions: [
        {
          id: 1,
          title: "Sunset in Dasma",
          status: "Closed",
          topBid: 5000,
          image:
            "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=100&q=70",
        },
        {
          id: 2,
          title: "Blue Hour Manila",
          status: "Live",
          topBid: 3200,
          image:
            "https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=100&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          status: "Ending",
          topBid: 8750,
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=100&q=70",
        },
      ],
      pendingPayout: {
        title: "Roots & Branches",
        amount: 8750,
        note: "Processing \u00B7 1\u20132 business days to GCash",
      },

      creatorInfo: [],

    };
  },
  computed: {
    initials() {
      const fn = this.creatorInfo?.first_name?.[0] || '';
      const ln = this.creatorInfo?.last_name?.[0] || '';
      return (fn + ln).toUpperCase();
    },
    personalFields() {
      return [
        { label: "First Name", value: this.creator.firstName },
        { label: "Last Name", value: this.creator.lastName },
        { label: "Mobile", value: this.creator.mobile },
        { label: "Email", value: this.creator.email },
      ];
    },
    stats() {
      return [
        {
          label: "Auctions Run",
          value: this.metrics.auctionsRun,
          accent: "text-[#1A56DB]",
        },
        {
          label: "Artworks Sold",
          value: this.metrics.artworksSold,
          accent: "text-[#10B981]",
        },
        {
          label: "Total Earned",
          value: "\u20B1" + this.formatMoney(this.metrics.totalEarned),
          accent: "text-[#0F172A]",
        },
        {
          label: "Pending Payout",
          value: this.pendingPayout
            ? "\u20B1" + this.formatMoney(this.pendingPayout.amount)
            : "\u20B10",
          accent: "text-[#F59E0B]",
        },
      ];
    },

    

  },
  mounted() {
    this.sessionCheck();
    this.infoloader();
    this.auctionsLoader();
  },
  methods: {
    //Session Checker
    sessionCheck(){
      fetch('creator/controller_fetcher.php?action=session_checker')
      .then(response => response.json())
      .then(data => {
        if(data=="Inactive"){
          this.$router.push("/")
        }        
      });
    },

    //Creator Info From Database Loader
    infoloader(){
      fetch('creator/controller_fetcher.php?action=get_creator_info')
      .then(response => response.json())
      .then(data => {
          //Assigns creator information
          this.creatorInfo = data;
          this.creator.firstName = data.first_name;
          this.creator.lastName = data.last_name;
          this.creator.mobile = data.mobile;
          this.creator.email = data.email;
      });
    },

    auctionsLoader(){
      fetch('creator/controller_fetcher.php?action=get_creator_auctions')
      .then(response => response.json())
      .then(data => {
          data.forEach(emp => {
              this.auctions.push({
                  id: emp.id,
                  title: emp.title,
                  status: emp.status,
                  topBid: 0,
                  image: ("creator/"+emp.image_path)
              });
          });
      });
    },

    formatMoney(value) {
      return Number(value).toLocaleString("en-PH");
    },
    statusClass(status) {
      const map = {
        Live: "bg-[#10B981]/10 text-[#10B981]",
        Ending: "bg-[#EF4444]/10 text-[#EF4444]",
        Scheduled: "bg-[#F59E0B]/10 text-[#F59E0B]",
        Closed: "bg-[#94A3B8]/15 text-[#94A3B8]",
      };
      return map[status] || map.Closed;
    },
    addPayoutMethod() {
      Swal.fire({
        title: "Add Payout Method",
        text: "Payout linking isn't wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    changePassword() {
      Swal.fire({
        title: "Change Password",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    manageTwoFactor() {
      Swal.fire({
        title: "Two-Factor Auth",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    logOut() {
      Swal.fire({
        icon: "question",
        title: "Log out?",
        showCancelButton: true,
        confirmButtonText: "Log Out",
        confirmButtonColor: "#EF4444",
        iconColor: "#FF5733",
      }).then((result) => {
        if (result.isConfirmed) this.$router.push("/");
      });
    },
  },
};
