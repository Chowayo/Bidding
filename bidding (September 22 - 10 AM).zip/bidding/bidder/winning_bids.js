const WINNING_BID_ICONS = {
  wallet:
    '<path d="M3 7a2 2 0 012-2h13a1 1 0 011 1v3"/><path d="M3 7v11a2 2 0 002 2h15a1 1 0 001-1v-7a1 1 0 00-1-1h-5a2 2 0 000 4h5.5"/>',
  alertTriangle:
    '<path d="M12 3.5l9 15.5a1 1 0 01-.87 1.5H3.87A1 1 0 013 19l9-15.5z" stroke-linejoin="round"/><path d="M12 10v4" stroke-linecap="round"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/>',
  check: '<path d="M20 6L9 17l-5-5"/>',
};

const WinningBidIcon = {
  props: { name: String },
  template: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" v-html="WINNING_BID_ICONS[name] || ''"></svg>`,
  created() {
    this.WINNING_BID_ICONS = WINNING_BID_ICONS;
  },
};

const winningBidsView = {
  components: { "site-header": siteHeader, icon: WinningBidIcon },
  data() {
    return {
      user: { firstName: "Maria", lastName: "Santos" },
      // Front-end only — mock data, swap for the real winning-bids endpoint once it exists.
      // deadlineSeconds counts down for the "Pay within" timer; urgent flags the red styling.
      wins: [
        {
          id: 1,
          title: "Sunset in Dasma",
          creator: "Maria Santos",
          amount: 5000,
          status: "pending",
          deadlineSeconds: 23 * 3600 + 59 * 60,
          urgent: false,
          image:
            "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 2,
          title: "Roots & Branches",
          creator: "Marco Villanueva",
          amount: 8750,
          status: "pending",
          deadlineSeconds: 1 * 3600 + 12 * 60,
          urgent: true,
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Blue Hour Manila",
          creator: "Lena Buenaventura",
          amount: 3200,
          status: "paid",
          image:
            "https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=200&q=70",
        },
      ],
      timerHandle: null,
    };
  },
  computed: {
    pending() {
      return this.wins.filter((w) => w.status === "pending");
    },
    completed() {
      return this.wins.filter((w) => w.status === "paid");
    },
    urgentWin() {
      return this.pending.find((w) => w.urgent) || null;
    },
  },
  created() {
    this.timerHandle = setInterval(() => {
      this.wins.forEach((w) => {
        if (w.status === "pending" && w.deadlineSeconds > 0)
          w.deadlineSeconds--;
      });
    }, 1000);
  },
  beforeUnmount() {
    if (this.timerHandle) clearInterval(this.timerHandle);
  },
  methods: {
    formatMoney(value) {
      return Number(value).toLocaleString("en-PH");
    },
    formatCountdown(seconds) {
      const h = Math.floor(seconds / 3600);
      const m = Math.floor((seconds % 3600) / 60);
      if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
      const s = seconds % 60;
      return `${m}m ${String(s).padStart(2, "0")}s`;
    },
    async payNow(win) {
      const result = await Swal.fire({
        icon: "question",
        title: "Pay for this win?",
        text: `\u20B1${this.formatMoney(win.amount)} will be held as a deposit for "${win.title}" until you confirm delivery.`,
        showCancelButton: true,
        confirmButtonText: "Pay \u20B1" + this.formatMoney(win.amount),
        confirmButtonColor: "#0F2245",
        cancelButtonColor: "#94A3B8",
      });
      if (!result.isConfirmed) return;

      win.status = "paid";
      await Swal.fire({
        icon: "success",
        title: "Payment secured",
        text: "Your deposit is held until you confirm the artwork's delivery.",
        confirmButtonColor: "#0F2245",
      });
    },
  },
  template: `
        <div class="min-h-screen flex flex-col bg-[#F8FAFC]">
            <site-header :user="user"
                :nav-items="[{ label: 'Discover', to: '/discover' }, { label: 'Winning Bids', to: '/bidder/winning-bids' }]"
                active-label="Winning Bids" profile-to="/bidder/profile" />

            <main class="flex-1 w-[full max-w-2xl] px-4 sm:px-6 py-6 sm:py-8 mx-auto">

                <h1 class="text-xl sm:text-2xl font-bold text-[#0F172A] flex items-center gap-2">
                    <span>\u{1F3C6}</span> Winning Bids
                </h1>
                <p class="mt-1 text-sm text-[#64748B]">
                    {{ pending.length }} pending payment &middot; {{ completed.length }} completed
                </p>

                <div v-if="urgentWin" class="mt-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3.5 flex items-center gap-2.5">
                    <icon name="alertTriangle" class="w-4 h-4 text-red-600 shrink-0" />
                    <p class="text-sm font-medium text-red-700">
                        1 bid is expiring soon &mdash; pay now to secure your artwork.
                    </p>
                </div>

                <template v-if="pending.length">
                    <p class="mt-6 text-[11px] font-semibold tracking-[0.08em] uppercase text-[#94A3B8]">Pending Payment</p>

                    <div class="mt-2 space-y-3">
                        <div v-for="w in pending" :key="w.id" class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                            <div class="flex gap-4 p-4">
                                <div class="relative w-20 h-20 sm:w-24 sm:h-24 shrink-0">
                                    <img :src="w.image" :alt="w.title" class="w-full h-full object-cover rounded-lg">
                                    <span v-if="w.urgent" class="absolute top-1 left-1 text-[9px] font-bold uppercase tracking-wide bg-red-600 text-white rounded px-1.5 py-0.5">
                                        Urgent
                                    </span>
                                </div>

                                <div class="flex-1 min-w-0 flex flex-col justify-between">
                                    <div class="flex items-start justify-between gap-3">
                                        <div class="min-w-0">
                                            <p class="text-[15px] font-semibold text-[#0F172A] truncate">{{ w.title }}</p>
                                            <p class="text-xs text-[#94A3B8] mt-0.5 truncate">by {{ w.creator }}</p>
                                        </div>
                                        <div class="text-right shrink-0">
                                            <p class="text-[10px] font-semibold uppercase tracking-wide text-[#94A3B8]">Pay within</p>
                                            <p class="text-sm font-semibold mt-0.5" :class="w.urgent ? 'text-red-600' : 'text-[#0F172A]'">
                                                {{ formatCountdown(w.deadlineSeconds) }}
                                            </p>
                                        </div>
                                    </div>

                                    <div class="mt-1.5">
                                        <p class="text-[10px] font-semibold uppercase tracking-wide text-[#94A3B8]">Winning Bid</p>
                                        <p class="text-lg font-bold text-[#10B981] leading-tight">&#8369;{{ formatMoney(w.amount) }}</p>
                                    </div>
                                </div>
                            </div>

                            <button type="button" @click="payNow(w)"
                                class="w-full h-10 bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-medium transition-colors flex items-center justify-center gap-2">
                                <icon name="wallet" class="w-4 h-4" />
                                Pay &#8369;{{ formatMoney(w.amount) }}
                            </button>
                        </div>
                    </div>
                </template>

                <template v-if="completed.length">
                    <p class="mt-6 text-[11px] font-semibold tracking-[0.08em] uppercase text-[#94A3B8]">Completed</p>

                    <div class="mt-2 space-y-3">
                        <div v-for="w in completed" :key="w.id" class="bg-white rounded-xl border border-[#DEE2E8] flex gap-4 p-4">
                            <img :src="w.image" :alt="w.title" class="w-20 h-20 sm:w-24 sm:h-24 shrink-0 object-cover rounded-lg">

                            <div class="flex-1 min-w-0 flex flex-col justify-between">
                                <div class="flex items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <p class="text-[15px] font-semibold text-[#0F172A] truncate">{{ w.title }}</p>
                                        <p class="text-xs text-[#94A3B8] mt-0.5 truncate">by {{ w.creator }}</p>
                                    </div>
                                    <span class="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-[#10B981]/10 text-[#10B981] shrink-0">
                                        <icon name="check" class="w-3.5 h-3.5" />
                                        Paid
                                    </span>
                                </div>

                                <div class="mt-1.5">
                                    <p class="text-[10px] font-semibold uppercase tracking-wide text-[#94A3B8]">Winning Bid</p>
                                    <p class="text-lg font-bold text-[#10B981] leading-tight">&#8369;{{ formatMoney(w.amount) }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>

                <div v-if="!wins.length" class="mt-6 bg-white rounded-xl border border-dashed border-[#DEE2E8] px-6 py-16 text-center">
                    <p class="font-medium">No winning bids yet</p>
                    <p class="mt-1 text-sm text-[#64748B]">Auctions you win will show up here.</p>
                </div>

                <div class="mt-6 bg-white rounded-xl border border-[#DEE2E8] p-4">
                    <p class="text-sm font-semibold text-[#0F172A]">How deposits work</p>
                    <p class="mt-1 text-sm text-[#64748B] leading-relaxed">
                        Each payment is held securely as a deposit and only released to the creator after you confirm receipt of that artwork.
                    </p>
                </div>
            </main>
        </div>
    `,
};
