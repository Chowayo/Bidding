<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Auctions · CanvasBid</title>
    <script src="../js/vue.global.js"></script>
    <script src="../js/vue-router.global.js"></script>
    <script src="../js/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        serif: ['Georgia', 'Cambria', 'Times New Roman', 'Times', 'serif'],
                        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    },
                    colors: {
                        canvas: {
                            ink: '#0B1526',
                            navy: '#0F2245',
                            navyhover: '#0A1A36',
                            moss: '#3E8F6B',
                            paper: '#F6F7F9',
                            line: '#DEE2E8',
                            ink2: '#101828',
                            muted: '#6B7280',
                        },
                    },
                    boxShadow: {
                        field: '0 1px 2px rgba(16, 24, 40, 0.04)',
                        card: '0 1px 3px rgba(16, 24, 40, 0.06), 0 1px 2px rgba(16, 24, 40, 0.04)',
                    },
                },
            },
        };
    </script>
    <style>
        [v-cloak] {
            display: none;
        }

        @media (prefers-reduced-motion: reduce) {
            * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body class="bg-[#F6F7F9] font-sans text-[#101828] antialiased">

    <div id="app" v-cloak class="min-h-screen flex flex-col">

        <!-- ============ TOP NAV ============ -->
        <header class="bg-[#0F2245] text-white sticky top-0 z-40">
            <div class="w-full px-4 sm:px-6 lg:px-8">
                <div class="h-14 sm:h-16 flex items-center justify-between gap-4">

                    <!-- Left: logo + desktop nav -->
                    <div class="flex items-center gap-8 min-w-0">
                        <a href="#" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</a>

                        <nav class="hidden md:flex items-center gap-6">
                            <a v-for="item in navItems" :key="item.label"
                                :href="item.href"
                                @click.prevent="activeNav = item.label"
                                class="text-sm transition-colors"
                                :class="activeNav === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                                {{ item.label }}
                            </a>
                        </nav>
                    </div>

                    <!-- Right: CTA + avatar + mobile toggle -->
                    <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                        <button type="button" @click="newAuction"
                            class="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-white text-[#0F2245] text-sm font-medium hover:bg-white/90 transition-colors">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                                <path d="M12 5v14M5 12h14" />
                            </svg>
                            New Auction
                        </button>

                        <button type="button"
                            class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
                            {{ initials }}
                        </button>

                        <!-- Mobile menu toggle -->
                        <button type="button" @click="mobileMenu = !mobileMenu"
                            class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors"
                            aria-label="Toggle navigation">
                            <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                                <path d="M3 6h18M3 12h18M3 18h18" />
                            </svg>
                            <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                                <path d="M18 6L6 18M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Mobile nav drawer -->
            <nav v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
                <div class="px-4 py-3 space-y-1">
                    <a v-for="item in navItems" :key="item.label"
                        :href="item.href"
                        @click.prevent="activeNav = item.label; mobileMenu = false"
                        class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
                        :class="activeNav === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
                        {{ item.label }}
                    </a>
                </div>
            </nav>
        </header>

        <!-- ============ MAIN ============ -->
        <main class="flex-1 w-[80%] px-4 sm:px-6 lg:px-8 py-6 sm:py-10 mx-auto">

            <!-- Page heading -->
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h1 class="font-serif text-2xl sm:text-[2rem] font-bold tracking-tight">My Auctions</h1>
                    <p class="mt-1 text-sm text-[#6B7280]">{{ activeCount }} active auctions running</p>
                </div>

                <button type="button" @click="newAuction"
                    class="hidden sm:inline-flex items-center gap-1.5 h-11 px-5 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-medium transition-colors shrink-0">
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <path d="M12 5v14M5 12h14" />
                    </svg>
                    New Auction
                </button>
            </div>

            <!-- Stat cards -->
            <div class="mt-5 sm:mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                <div v-for="stat in stats" :key="stat.label"
                    class="bg-white rounded-xl border border-[#DEE2E8] shadow-card px-4 sm:px-5 py-4 sm:py-5">
                    <p class="text-[11px] font-semibold tracking-[0.1em] uppercase text-[#94A3B8]">{{ stat.label }}</p>
                    <p class="mt-1.5 sm:mt-2 font-serif text-2xl sm:text-[2rem] font-bold leading-none"
                        :class="stat.accent">
                        {{ stat.value }}
                    </p>
                </div>
            </div>

            <!-- Auction list -->
            <div class="mt-5 sm:mt-6 space-y-3 sm:space-y-4">
                <article v-for="auction in auctions" :key="auction.id"
                    class="bg-white rounded-xl border border-[#DEE2E8] shadow-card overflow-hidden flex flex-col sm:flex-row sm:items-center">

                    <!-- Thumbnail -->
                    <div class="sm:w-24 lg:w-28 h-40 sm:h-24 lg:h-28 shrink-0 bg-[#0B1526]">
                        <img :src="auction.image" :alt="auction.title" class="w-full h-full object-cover">
                    </div>

                    <!-- Details -->
                    <div class="flex-1 min-w-0 px-4 sm:px-5 py-4">
                        <div class="flex flex-wrap items-center gap-2">
                            <h3 class="font-semibold text-[15px] truncate">{{ auction.title }}</h3>
                            <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full shrink-0"
                                :class="statusClass(auction.status)">
                                {{ auction.status }}
                            </span>
                        </div>

                        <p class="mt-1 text-sm text-[#6B7280] flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
                            <span>Top bid:</span>
                            <span class="font-semibold text-[#3E8F6B]">&#8369; {{ formatMoney(auction.topBid) }}</span>
                            <span class="text-[#DEE2E8]">·</span>
                            <span>{{ auction.bids }} bids</span>
                            <span class="text-[#DEE2E8]">·</span>
                            <span :class="auction.status === 'Ending' ? 'text-red-500 font-medium' : ''">
                                {{ auction.timeLeft }}
                            </span>
                        </p>
                    </div>

                    <!-- Action -->
                    <div class="px-4 sm:px-5 pb-4 sm:pb-0 sm:pl-0">
                        <button type="button" @click="manage(auction)"
                            class="w-full sm:w-auto h-10 px-5 rounded-lg border border-[#DEE2E8] hover:border-[#0F2245] hover:bg-[#0F2245]/5 text-sm font-medium transition-colors">
                            Manage
                        </button>
                    </div>
                </article>
            </div>

            <!-- Empty state -->
            <div v-if="!auctions.length"
                class="mt-6 bg-white rounded-xl border border-dashed border-[#DEE2E8] px-6 py-12 text-center">
                <p class="font-medium">No auctions yet</p>
                <p class="mt-1 text-sm text-[#6B7280]">Create your first auction to start receiving bids.</p>
            </div>
        </main>

        <!-- Mobile floating CTA -->
        <button type="button" @click="newAuction"
            class="sm:hidden fixed bottom-5 right-5 h-12 px-5 rounded-full bg-[#0F2245] text-white text-sm font-medium shadow-lg flex items-center gap-1.5 active:scale-95 transition-transform">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <path d="M12 5v14M5 12h14" />
            </svg>
            New Auction
        </button>
    </div>

    <script>
        const {
            createApp
        } = Vue;

        createApp({
            data() {
                return {
                    activeNav: 'My Auctions',
                    mobileMenu: false,
                    user: {
                        firstName: 'Maria',
                        lastName: 'Santos',
                    },
                    navItems: [{
                            label: 'My Auctions',
                            href: 'creator_dashboard.php'
                        },
                        {
                            label: 'Orders',
                            href: 'creator_orders.php'
                        },
                        {
                            label: 'Deposit Tracker',
                            href: 'creator_deposits.php'
                        },
                    ],
                    auctions: [{
                            id: 1,
                            title: 'Sunset in Dasma',
                            status: 'Live',
                            topBid: 5000,
                            bids: 14,
                            timeLeft: '02h 15m',
                            image: 'https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=400&q=70',
                        },
                        {
                            id: 2,
                            title: 'Blue Hour Manila',
                            status: 'Live',
                            topBid: 3200,
                            bids: 8,
                            timeLeft: '05h 40m',
                            image: 'https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=400&q=70',
                        },
                        {
                            id: 3,
                            title: 'Roots & Branches',
                            status: 'Ending',
                            topBid: 8750,
                            bids: 22,
                            timeLeft: '00h 08m',
                            image: 'https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=400&q=70',
                        },
                    ],
                };
            },
            computed: {
                initials() {
                    return (this.user.firstName[0] + this.user.lastName[0]).toUpperCase();
                },
                activeCount() {
                    return this.auctions.filter(a => a.status === 'Live' || a.status === 'Ending').length;
                },
                totalBids() {
                    return this.auctions.reduce((sum, a) => sum + a.bids, 0);
                },
                highestBid() {
                    return this.auctions.reduce((max, a) => Math.max(max, a.topBid), 0);
                },
                stats() {
                    return [{
                            label: 'Active Auctions',
                            value: this.activeCount,
                            accent: 'text-[#3E8F6B]',
                        },
                        {
                            label: 'Total Bids Today',
                            value: this.totalBids,
                            accent: 'text-[#101828]',
                        },
                        {
                            label: 'Highest Bid',
                            value: '\u20B1 ' + this.formatMoney(this.highestBid),
                            accent: 'text-[#0F2245]',
                        },
                    ];
                },
            },
            methods: {
                formatMoney(value) {
                    return Number(value).toLocaleString('en-PH');
                },
                statusClass(status) {
                    const map = {
                        Live: 'bg-[#3E8F6B]/10 text-[#3E8F6B]',
                        Ending: 'bg-red-50 text-red-500',
                        Scheduled: 'bg-amber-50 text-amber-600',
                        Closed: 'bg-slate-100 text-slate-500',
                    };
                    return map[status] || map.Closed;
                },
                newAuction() {
                    // Front-end only: route to the create-auction page.
                    console.log('New auction');
                },
                manage(auction) {
                    console.log('Manage auction:', auction.id);
                },
            },
        }).mount('#app');
    </script>
</body>

</html>