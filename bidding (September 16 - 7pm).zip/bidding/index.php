<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In · CanvasBid</title>
    <script src="js/vue.global.js"></script>
    <script src="js/vue-router.global.js"></script>
    <script src="js/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        serif: ['Georgia', 'Cambria', 'Times New Roman', 'Times', 'serif'],
                        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    },
                    colors: {
                        canvas: {
                            ink: '#0B1526', // near-black navy, hero background
                            navy: '#0F2245', // deep navy panel / button
                            navyhover: '#0A1A36',
                            moss: '#3E8F6B', // muted green accent (auctions / live)
                            paper: '#F6F7F9', // right-panel background
                            line: '#DEE2E8', // borders
                            ink2: '#101828', // body text
                            muted: '#6B7280', // secondary text
                        },
                    },
                    boxShadow: {
                        field: '0 1px 2px rgba(16, 24, 40, 0.04)',
                    },
                },
            },
        };
    </script>
    <style>
        [v-cloak] {
            display: none;
        }

        .bg-canvas-art {
            background-image: url('images/sunflower.jpg');
            background-size: cover;
            background-position: center;
            background-color: #0B1526;
        }

        .art-vignette {
            background:
                linear-gradient(180deg, rgba(6, 10, 20, 0.35) 0%, rgba(6, 10, 20, 0.25) 35%, rgba(6, 10, 20, 0.55) 65%, rgba(6, 10, 20, 0.82) 100%),
                rgba(6, 10, 20, 0.28);
        }

        .field-input {
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .field-input:focus {
            outline: none;
            border-color: #0F2245;
            box-shadow: 0 0 0 3px rgba(15, 34, 69, 0.12);
        }

        @media (prefers-reduced-motion: reduce) {
            * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body class="bg-[#F6F7F9] font-sans text-[#101828] antialiased">

    <div id="app" v-cloak>
        <div class="min-h-screen flex flex-col lg:flex-row lg:h-screen">

            <!-- Hero / brand panel -->
            <section class="relative bg-canvas-art overflow-hidden shrink-0 h-[34vh] min-h-[220px] lg:h-auto lg:min-h-screen lg:w-1/2">
                <div class="absolute inset-0 art-vignette"></div>

                <div class="relative h-full flex flex-col justify-between px-6 py-6 sm:px-10 sm:py-8 lg:px-14 lg:py-12">
                    <!-- Logo -->
                    <div class="flex items-center gap-2.5">
                        <span class="flex items-center justify-center w-8 h-8 rounded-md bg-white/10 border border-white/15 text-white font-serif font-semibold text-sm">C</span>
                        <span class="text-white font-medium tracking-wide">CanvasBid</span>
                    </div>

                    <!-- Copy -->
                    <div class="max-w-md">
                        <div class="flex items-center gap-2 mb-3">
                            <span class="w-6 h-px bg-[#3E8F6B]"></span>
                            <span class="text-[#3E8F6B] text-xs font-medium tracking-[0.16em] uppercase">Live auctions · Philippines</span>
                        </div>
                        <h1 class="font-serif text-white text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.08] font-semibold">
                            Own a piece<br class="hidden sm:block" />
                            of Filipino art.
                        </h1>
                        <p class="hidden sm:block mt-4 text-white/60 text-[15px] leading-relaxed max-w-sm">
                            A transparent auction platform connecting collectors with Filipino creators — secured by deposit protection.
                        </p>
                    </div>

                    <!-- Footer -->
                    <p class="hidden lg:block text-white/35 text-xs">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>

            <!-- Form panel -->
            <section class="flex-1 flex items-start lg:items-center justify-center px-6 py-10 sm:px-10 lg:px-16">
                <div class="w-full max-w-sm">

                    <h2 class="font-serif text-2xl sm:text-[1.75rem] font-semibold text-[#101828]">Welcome back</h2>
                    <p class="mt-1.5 text-sm text-[#6B7280]">Sign in to your CanvasBid account.</p>

                    <form class="mt-7 space-y-5" @submit.prevent="handleSubmit" novalidate>

                        <!-- Email -->
                        <div>
                            <label for="email" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Email address
                            </label>
                            <input
                                id="email"
                                type="email"
                                v-model.trim="form.email"
                                placeholder="you@example.com"
                                autocomplete="email"
                                class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                :class="errors.email ? 'border-red-400' : 'border-[#DEE2E8]'">
                            <p v-if="errors.email" class="mt-1.5 text-xs text-red-500">{{ errors.email }}</p>
                        </div>

                        <!-- Password -->
                        <div>
                            <label for="password" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Password
                            </label>
                            <div class="relative">
                                <input
                                    id="password"
                                    :type="showPassword ? 'text' : 'password'"
                                    v-model="form.password"
                                    placeholder="••••••••"
                                    autocomplete="current-password"
                                    class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                    :class="errors.password ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <button
                                    type="button"
                                    @click="showPassword = !showPassword"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                    :aria-label="showPassword ? 'Hide password' : 'Show password'">
                                    <svg v-if="!showPassword" class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
                                        <circle cx="12" cy="12" r="3" />
                                    </svg>
                                    <svg v-else class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                                        <line x1="1" y1="1" x2="23" y2="23" />
                                    </svg>
                                </button>
                            </div>
                            <p v-if="errors.password" class="mt-1.5 text-xs text-red-500">{{ errors.password }}</p>
                        </div>

                        <!-- Remember / forgot -->
                        <div class="flex items-center justify-between pt-1">
                            <label class="flex items-center gap-2 text-sm text-[#101828] select-none">
                                <input type="checkbox" v-model="form.remember" class="w-4 h-4 rounded border-[#DEE2E8] text-[#0F2245] focus:ring-[#0F2245]/30">
                                Remember me
                            </label>
                            <a href="#" class="text-sm text-[#0F2245] hover:underline">Forgot password?</a>
                        </div>

                        <!-- Submit -->
                        <button
                            type="submit"
                            :disabled="submitting"
                            class="w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] disabled:opacity-70 text-white text-[15px] font-medium transition-colors flex items-center justify-center gap-2">
                            <svg v-if="submitting" class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                            </svg>
                            {{ submitting ? 'Signing in…' : 'Sign In' }}
                        </button>
                    </form>

                    <!-- Divider -->
                    <div class="flex items-center gap-3 my-7">
                        <span class="h-px flex-1 bg-[#DEE2E8]"></span>
                        <span class="text-xs text-[#6B7280]">or</span>
                        <span class="h-px flex-1 bg-[#DEE2E8]"></span>
                    </div>

                    <!-- Role selection -->
                    <p class="text-center text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-3">
                        Create an account as
                    </p>
                    <div class="grid grid-cols-2 gap-3">
                        <a
                            href="bidder/bidder_register.php"
                            class="h-11 rounded-lg border border-[#DEE2E8] hover:border-[#0F2245] hover:bg-[#0F2245]/5 flex items-center justify-center gap-2 text-sm font-medium text-[#101828] transition-colors">
                            <svg class="w-4 h-4 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                <circle cx="12" cy="12" r="9" />
                                <path d="M9 12h6M12 9v6" stroke-linecap="round" />
                            </svg>
                            Bidder
                        </a>
                        <a
                            href="creator/creator_register.php"
                            class="h-11 rounded-lg border border-[#DEE2E8] hover:border-[#0F2245] hover:bg-[#0F2245]/5 flex items-center justify-center gap-2 text-sm font-medium text-[#101828] transition-colors">
                            <svg class="w-4 h-4 text-[#0F2245]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 19l7-7 3 3-7 7-3-3z" />
                                <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
                                <path d="M2 2l7.586 7.586" />
                                <circle cx="11" cy="11" r="2" />
                            </svg>
                            Creator
                        </a>
                    </div>

                    <p class="lg:hidden mt-10 text-center text-xs text-[#6B7280]">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>
        </div>

    </div>

    <script>
        const {
            createApp
        } = Vue;

        createApp({
            data() {
                return {
                    form: {
                        email: '',
                        password: '',
                        remember: false,
                    },
                    showPassword: false,
                    submitting: false,
                    errors: {},
                };
            },
            methods: {
                validate() {
                    const errors = {};
                    if (!this.form.email) {
                        errors.email = 'Enter your email address.';
                    } else if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
                        errors.email = 'Enter a valid email address.';
                    }
                    if (!this.form.password) {
                        errors.password = 'Enter your password.';
                    }
                    this.errors = errors;
                    return Object.keys(errors).length === 0;
                },
                handleSubmit() {
                    if (!this.validate() || this.submitting) return;
                    this.submitting = true;
                    setTimeout(() => {
                        this.submitting = false;
                    }, 900);
                },
                selectRole(role) {
                    console.log('Create account as:', role);
                },
            },
        }).mount('#app');
    </script>
</body>

</html>