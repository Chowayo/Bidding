<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bidder Registration · CanvasBid</title>
    <script src="../js/vue.global.js"></script>
    <script src="../js/vue-router.global.js"></script>
    <script src="../js/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        serif: ['Georgia', 'Cambria', 'Times New Roman', 'Times', 'serif'],
                        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    },
                    colors: {
                        canvas: {
                            ink: '#0B1526', // near-black navy, hero background
                            navy: '#0F2245', // deep navy panel / button
                            navyhover: '#0A1A36',
                            moss: '#3E8F6B', // muted green accent (auctions / live)
                            paper: '#F6F7F9', // right-panel background
                            line: '#DEE2E8', // borders
                            ink2: '#101828', // body text
                            muted: '#6B7280', // secondary text
                        },
                    },
                    boxShadow: {
                        field: '0 1px 2px rgba(16, 24, 40, 0.04)',
                    },
                },
            },
        };
    </script>
    <style>
        [v-cloak] {
            display: none;
        }

        .bg-canvas-art {
            background-image: url('../images/collage.png');
            background-size: cover;
            background-position: center;
            background-color: #0B1526;
        }

        .art-vignette {
            background:
                linear-gradient(180deg, rgba(6, 10, 20, 0.35) 0%, rgba(6, 10, 20, 0.25) 35%, rgba(6, 10, 20, 0.55) 65%, rgba(6, 10, 20, 0.82) 100%),
                rgba(6, 10, 20, 0.28);
        }

        .field-input {
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .field-input:focus {
            outline: none;
            border-color: #0F2245;
            box-shadow: 0 0 0 3px rgba(15, 34, 69, 0.12);
        }

        @media (prefers-reduced-motion: reduce) {
            * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body class="bg-[#F6F7F9] font-sans text-[#101828] antialiased">

    <div id="app" v-cloak>
        <div class="min-h-screen flex flex-col lg:flex-row lg:h-screen">

            <!-- Hero / brand panel -->
            <section class="relative bg-canvas-art overflow-hidden shrink-0 h-[34vh] min-h-[220px] lg:h-auto lg:min-h-screen lg:w-1/2">
                <div class="absolute inset-0 art-vignette"></div>

                <div class="relative h-full flex flex-col justify-between px-6 py-6 sm:px-10 sm:py-8 lg:px-14 lg:py-12">
                    <!-- Logo -->
                    <div class="flex items-center gap-2.5">
                        <span class="flex items-center justify-center w-8 h-8 rounded-md bg-white/10 border border-white/15 text-white font-serif font-semibold text-sm">C</span>
                        <span class="text-white font-medium tracking-wide">CanvasBid</span>
                    </div>

                    <!-- Copy -->
                    <div class="max-w-md">
                        <div class="flex items-center gap-2 mb-3">
                            <span class="w-6 h-px bg-[#3E8F6B]"></span>
                            <span class="text-[#3E8F6B] text-xs font-medium tracking-[0.16em] uppercase">Bidder account</span>
                        </div>
                        <h1 class="font-serif text-white text-3xl sm:text-4xl lg:text-[2.75rem] leading-[1.08] font-semibold">
                            Start bidding on<br class="hidden sm:block" />
                            art you love.
                        </h1>
                        <p class="hidden sm:block mt-4 text-white/60 text-[15px] leading-relaxed max-w-sm">
                            Discover exclusive pieces from Filipino creators and bid through our secure deposit system.
                        </p>

                        <div class="hidden sm:flex flex-wrap gap-2 mt-5">
                            <span class="text-xs font-medium bg-white/10 text-white px-3 py-1.5 rounded-full">14 live auctions</span>
                            <span class="text-xs font-medium bg-white/10 text-white px-3 py-1.5 rounded-full">3 artists</span>
                            <span class="text-xs font-medium bg-white/10 text-white px-3 py-1.5 rounded-full">Secure deposit</span>
                        </div>
                    </div>

                    <!-- Footer -->
                    <p class="hidden lg:block text-white/35 text-xs">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>

            <!-- Form panel -->
            <section class="flex-1 flex items-start lg:items-center justify-center px-6 py-10 sm:px-10 lg:px-16">
                <div class="w-full max-w-md">

                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-6 h-px bg-[#3E8F6B]"></span>
                        <span class="text-[#3E8F6B] text-xs font-medium tracking-[0.16em] uppercase">Bidder registration</span>
                    </div>
                    <h2 class="font-serif text-2xl sm:text-[1.75rem] font-bold text-[#101828]">Create your account</h2>
                    <p class="mt-1.5 text-sm text-[#6B7280]">Fill in your details to start bidding on original artworks.</p>

                    <form class="mt-7 space-y-5" @submit.prevent="handleSubmit" novalidate>

                        <!-- Name -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="firstName" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                    First name
                                </label>
                                <input
                                    id="firstName"
                                    type="text"
                                    v-model.trim="form.firstName"
                                    placeholder="Maria"
                                    autocomplete="given-name"
                                    class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                    :class="errors.firstName ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <p v-if="errors.firstName" class="mt-1.5 text-xs text-red-500">{{ errors.firstName }}</p>
                            </div>
                            <div>
                                <label for="lastName" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                    Last name
                                </label>
                                <input
                                    id="lastName"
                                    type="text"
                                    v-model.trim="form.lastName"
                                    placeholder="Santos"
                                    autocomplete="family-name"
                                    class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                    :class="errors.lastName ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <p v-if="errors.lastName" class="mt-1.5 text-xs text-red-500">{{ errors.lastName }}</p>
                            </div>
                        </div>

                        <!-- Mobile number -->
                        <div>
                            <label for="mobile" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Mobile number
                            </label>
                            <input
                                id="mobile"
                                type="tel"
                                v-model.trim="form.mobile"
                                placeholder="+63 9XX XXX XXXX"
                                autocomplete="tel"
                                class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                :class="errors.mobile ? 'border-red-400' : 'border-[#DEE2E8]'">
                            <p v-if="errors.mobile" class="mt-1.5 text-xs text-red-500">{{ errors.mobile }}</p>
                        </div>

                        <!-- Email -->
                        <div>
                            <label for="email" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Email address
                            </label>
                            <input
                                id="email"
                                type="email"
                                v-model.trim="form.email"
                                placeholder="you@example.com"
                                autocomplete="email"
                                class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                :class="errors.email ? 'border-red-400' : 'border-[#DEE2E8]'">
                            <p v-if="errors.email" class="mt-1.5 text-xs text-red-500">{{ errors.email }}</p>
                        </div>

                        <!-- Password -->
                        <div>
                            <label for="password" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Password
                            </label>
                            <div class="relative">
                                <input
                                    id="password"
                                    :type="showPassword ? 'text' : 'password'"
                                    v-model="form.password"
                                    placeholder="Min. 8 characters"
                                    autocomplete="new-password"
                                    class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                    :class="errors.password ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <button
                                    type="button"
                                    @click="showPassword = !showPassword"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                    :aria-label="showPassword ? 'Hide password' : 'Show password'">
                                    <svg v-if="!showPassword" class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
                                        <circle cx="12" cy="12" r="3" />
                                    </svg>
                                    <svg v-else class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                                        <line x1="1" y1="1" x2="23" y2="23" />
                                    </svg>
                                </button>
                            </div>
                            <p v-if="errors.password" class="mt-1.5 text-xs text-red-500">{{ errors.password }}</p>
                        </div>

                        <!-- Confirm password -->
                        <div>
                            <label for="confirmPassword" class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">
                                Confirm password
                            </label>
                            <div class="relative">
                                <input
                                    id="confirmPassword"
                                    :type="showConfirmPassword ? 'text' : 'password'"
                                    v-model="form.confirmPassword"
                                    placeholder="Repeat password"
                                    autocomplete="new-password"
                                    class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400 shadow-field"
                                    :class="errors.confirmPassword ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <button
                                    type="button"
                                    @click="showConfirmPassword = !showConfirmPassword"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                    :aria-label="showConfirmPassword ? 'Hide password' : 'Show password'">
                                    <svg v-if="!showConfirmPassword" class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
                                        <circle cx="12" cy="12" r="3" />
                                    </svg>
                                    <svg v-else class="w-4.5 h-4.5" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                                        <line x1="1" y1="1" x2="23" y2="23" />
                                    </svg>
                                </button>
                            </div>
                            <p v-if="errors.confirmPassword" class="mt-1.5 text-xs text-red-500">{{ errors.confirmPassword }}</p>
                        </div>

                        <!-- Terms -->
                        <div>
                            <label class="flex items-start gap-2 text-sm text-[#101828] select-none">
                                <input type="checkbox" v-model="form.agree" class="mt-0.5 w-4 h-4 rounded border-[#DEE2E8] text-[#0F2245] focus:ring-[#0F2245]/30">
                                <span>
                                    I agree to the
                                    <a href="#" class="text-[#0F2245] font-medium hover:underline">Terms of Service</a>
                                    and
                                    <a href="#" class="text-[#0F2245] font-medium hover:underline">Privacy Policy</a>
                                </span>
                            </label>
                            <p v-if="errors.agree" class="mt-1.5 text-xs text-red-500">{{ errors.agree }}</p>
                        </div>

                        <!-- Submit -->
                        <button
                            type="submit"
                            :disabled="submitting"
                            class="w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] disabled:opacity-70 text-white text-[15px] font-medium transition-colors flex items-center justify-center gap-2">
                            <svg v-if="submitting" class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                            </svg>
                            {{ submitting ? 'Creating account…' : 'Create Account' }}
                        </button>
                    </form>

                    <p class="mt-6 text-center text-sm text-[#6B7280]">
                        Already have an account?
                        <a href="../index.php" class="text-[#0F2245] font-medium hover:underline">Sign in</a>
                    </p>

                    <p class="lg:hidden mt-10 text-center text-xs text-[#6B7280]">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>
        </div>
    </div>

    <script>
        const {
            createApp
        } = Vue;

        createApp({
            data() {
                return {
                    form: {
                        firstName: '',
                        lastName: '',
                        mobile: '',
                        email: '',
                        password: '',
                        confirmPassword: '',
                        agree: false,
                    },
                    showPassword: false,
                    showConfirmPassword: false,
                    submitting: false,
                    errors: {},
                };
            },
            methods: {
                validate() {
                    const errors = {};
                    if (!this.form.firstName) errors.firstName = 'Enter your first name.';
                    if (!this.form.lastName) errors.lastName = 'Enter your last name.';

                    if (!this.form.mobile) {
                        errors.mobile = 'Enter your mobile number.';
                    } else if (!/^\+?[\d\s]{7,15}$/.test(this.form.mobile)) {
                        errors.mobile = 'Enter a valid mobile number.';
                    }

                    if (!this.form.email) {
                        errors.email = 'Enter your email address.';
                    } else if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
                        errors.email = 'Enter a valid email address.';
                    }

                    if (!this.form.password) {
                        errors.password = 'Enter a password.';
                    } else if (this.form.password.length < 8) {
                        errors.password = 'Password must be at least 8 characters.';
                    }

                    if (!this.form.confirmPassword) {
                        errors.confirmPassword = 'Confirm your password.';
                    } else if (this.form.confirmPassword !== this.form.password) {
                        errors.confirmPassword = 'Passwords do not match.';
                    }

                    if (!this.form.agree) errors.agree = 'You must agree to continue.';

                    this.errors = errors;
                    return Object.keys(errors).length === 0;
                },
                handleSubmit() {
                    if (!this.validate() || this.submitting) return;
                    this.submitting = true;
                    // Front-end only: wire this up to the real registration endpoint.
                    setTimeout(() => {
                        this.submitting = false;
                    }, 900);
                },
            },
        }).mount('#app');
    </script>
</body>

</html>