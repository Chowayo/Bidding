<?php

/**
 * SMTP configuration for Gmail.
 *
 * IMPORTANT: Gmail no longer accepts your normal account password for
 * SMTP login. You must generate a 16-character "App Password" instead:
 *
 *   1. Turn on 2-Step Verification on the Google account you're sending
 *      from: https://myaccount.google.com/security
 *   2. Go to https://myaccount.google.com/apppasswords
 *   3. Create an app password (name it e.g. "Eco Hydrate Hub") and copy
 *      the 16-character code it gives you.
 *   4. Paste that code below as MAIL_PASSWORD (remove the spaces).
 *
 * Do NOT commit this file with real credentials to a public repo.
 * Add it to .gitignore, or better, load these from environment
 * variables instead of hardcoding them.
 */

// Gmail address you're sending FROM
define('MAIL_USERNAME', 'chowxinnlu@gmail.com');

// 16-character Gmail App Password (NOT your normal Gmail password)
define('MAIL_PASSWORD', 'dunmkmhlqiblvxwn');

// SMTP connection settings — these are fixed for Gmail, no need to change
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);          // 587 = TLS (recommended), 465 = SSL
define('MAIL_ENCRYPTION', 'tls');  // 'tls' for port 587, 'ssl' for port 465

// Default "From" identity used when a page doesn't specify one
define('MAIL_FROM_ADDRESS', MAIL_USERNAME);
define('MAIL_FROM_NAME', 'Eco Hydrate Hub');
