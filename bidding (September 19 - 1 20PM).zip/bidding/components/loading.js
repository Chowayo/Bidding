// Reusable "Please wait..." loading spinner.
// Works with the plain <script src="js/vue.global.js"> setup already used across
// the app — no build step, no SFCs.
//
// IMPORTANT: the actual spin animation (the `.canvasbid-spin` class and its
// @keyframes) is NOT defined here — embedding a <style> tag inside a Vue
// string template is unreliable. Instead, this block must live in the
// <style> section of the <head> of every page that uses this component:
//
//     @keyframes canvasbid-spin { to { transform: rotate(360deg); } }
//     .canvasbid-spin { animation: canvasbid-spin 0.8s linear infinite; transform-origin: center; }
//
// And make sure your prefers-reduced-motion rule excludes it, e.g.:
//
//     @media (prefers-reduced-motion: reduce) {
//         *:not(.canvasbid-spin) { animation: none !important; transition: none !important; }
//     }
//
// Usage in any page's createApp():
//
//     const app = Vue.createApp({ ... });
//     app.component('loading-spinner', LoadingSpinner);
//     app.mount('#app');
//
// Then, inside a small modal card (not full-screen):
//
//     <div v-if="loading" class="fixed inset-0 z-50 bg-black/40 flex items-center justify-center px-4">
//         <div class="bg-white rounded-2xl shadow-lg px-8 py-8 flex flex-col items-center gap-2 max-w-xs w-full">
//             <loading-spinner message="Creating your account…" />
//         </div>
//     </div>

const LoadingSpinner = {
    props: {
        message: {
            type: String,
            default: 'Please wait...',
        },
        size: {
            type: Number,
            default: 64,
        },
    },
    template: `
        <div class="flex flex-col items-center justify-center gap-4">
            <svg
                class="canvasbid-spin"
                :width="size"
                :height="size"
                viewBox="0 0 64 64"
                fill="none"
            >
                <circle cx="32" cy="32" r="27" stroke="#DEE2E8" stroke-width="6" />
                <circle
                    cx="32" cy="32" r="27"
                    stroke="#0F2245"
                    stroke-width="6"
                    stroke-linecap="round"
                    stroke-dasharray="127 170"
                />
            </svg>
            <p class="text-[#0F2245] font-semibold text-base">{{ message }}</p>
        </div>
    `,
};