<?php
session_start();

require_once __DIR__ . '/dbconn.php';
require_once __DIR__ . '/mailer/includes/send_mail.php';

$action = $_GET['action'] ?? '';

if ($action === 'verify_otp' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    if (empty($_SESSION['pending_verification'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Nothing to verify. Please register or log in again.']);
        exit;
    }

    $pending = $_SESSION['pending_verification'];
    $input   = json_decode(file_get_contents('php://input'), true) ?? [];
    $code    = trim($input['code'] ?? '');

    if ($code === '' || !preg_match('/^\d{6}$/', $code)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Enter the 6-digit code.']);
        exit;
    }

    $stmt = $conn->prepare('SELECT otp_code_hash, otp_expires_at FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $pending['user_id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || strtotime($row['otp_expires_at']) < time() || !password_verify($code, $row['otp_code_hash'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'That code is incorrect or has expired.']);
        exit;
    }

    $stmt = $conn->prepare('UPDATE users SET is_verified = 1, otp_code_hash = NULL, otp_expires_at = NULL WHERE id = ?');
    $stmt->bind_param('i', $pending['user_id']);
    $stmt->execute();
    $stmt->close();

    // Verified — log them straight in rather than making them sign in again.
    $_SESSION['user_id']    = $pending['user_id'];
    $_SESSION['user_role']  = $pending['role'];
    $_SESSION['user_email'] = $pending['email'];
    unset($_SESSION['pending_verification']);

    echo json_encode([
        'success'  => true,
        'redirect' => $pending['role'] === 'creator' ? 'creator/creator_dashboard.php' : 'bidder/bidder_dashboard.php',
    ]);
    exit;
}

if ($action === 'resend_otp' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    if (empty($_SESSION['pending_verification'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Nothing to resend. Please register or log in again.']);
        exit;
    }

    $pending = $_SESSION['pending_verification'];

    $stmt = $conn->prepare('SELECT first_name FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $pending['user_id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $otp        = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $otpHash    = password_hash($otp, PASSWORD_DEFAULT);
    $otpExpires = date('Y-m-d H:i:s', time() + 10 * 60);

    $upd = $conn->prepare('UPDATE users SET otp_code_hash = ?, otp_expires_at = ? WHERE id = ?');
    $upd->bind_param('ssi', $otpHash, $otpExpires, $pending['user_id']);
    $upd->execute();
    $upd->close();

    send_email(
        $pending['email'],
        'Your CanvasBid verification code',
        "<p>Hi {$row['first_name']},</p><p>Your CanvasBid verification code is:</p><h2>{$otp}</h2><p>This code expires in 10 minutes.</p>"
    );

    echo json_encode(['success' => true]);
    exit;
}

// Normal page load — must have a pending verification to be here.
if (empty($_SESSION['pending_verification'])) {
    header('Location: index.php');
    exit;
}

$pending = $_SESSION['pending_verification'];
$maskedEmail = preg_replace('/^(.{2}).*(@.*)$/', '$1•••$2', $pending['email']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Verification · CanvasBid</title>
    <script src="js/vue.global.js"></script>
    <script src="js/tailwind.js"></script>
    <style>
        [v-cloak] { display: none; }

        .field-input {
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .field-input:focus {
            outline: none;
            border-color: #0F2245;
            box-shadow: 0 0 0 3px rgba(15, 34, 69, 0.12);
        }
    </style>
</head>

<body class="bg-[#F6F7F9] font-sans text-[#101828] antialiased min-h-screen flex items-center justify-center px-4 py-10">

    <div id="app" v-cloak class="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-[#DEE2E8] p-7 sm:p-8">

        <div class="w-11 h-11 rounded-xl bg-[#EEF2FF] flex items-center justify-center mb-5">
            <svg class="w-5 h-5 text-amber-400" viewBox="0 0 24 24" fill="currentColor"><path d="M6 10V8a6 6 0 1 1 12 0v2h.5A1.5 1.5 0 0 1 20 11.5v8A1.5 1.5 0 0 1 18.5 21h-13A1.5 1.5 0 0 1 4 19.5v-8A1.5 1.5 0 0 1 5.5 10H6Zm2 0h8V8a4 4 0 1 0-8 0v2Z"/></svg>
        </div>

        <h1 class="text-xl font-bold text-[#101828]">Account Verification</h1>
        <p class="mt-1.5 text-sm text-[#6B7280]">Enter the 6-digit code sent to your email address.</p>

        <p v-if="serverError" class="mt-5 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm px-3.5 py-2.5">
            {{ serverError }}
        </p>

        <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mt-6 mb-2">
            Email OTP code
        </label>

        <div class="flex gap-2">
            <input
                v-for="(d, i) in digits"
                :key="i"
                :ref="el => setDigitRef(el, i)"
                type="text"
                inputmode="numeric"
                maxlength="1"
                v-model="digits[i]"
                @input="onDigitInput(i, $event)"
                @keydown="onKeydown(i, $event)"
                @paste="i === 0 ? onPaste($event) : null"
                class="field-input w-full h-14 text-center text-lg font-semibold rounded-lg border border-[#DEE2E8]">
        </div>

        <div class="flex items-center justify-between mt-3">
            <p class="text-sm text-[#6B7280]">Sent to <?php echo htmlspecialchars($maskedEmail); ?></p>
            <button type="button" @click="resend" :disabled="resending" class="text-sm font-medium text-[#0F2245] hover:underline disabled:opacity-50">
                {{ resending ? 'Sending…' : 'Resend' }}
            </button>
        </div>

        <p v-if="resendMessage" class="mt-2 text-xs text-[#3E8F6B]">{{ resendMessage }}</p>

        <button
            type="button"
            @click="handleSubmit"
            :disabled="!canSubmit || submitting"
            class="w-full h-12 mt-6 rounded-lg text-[15px] font-medium transition-colors flex items-center justify-center gap-2"
            :class="canSubmit ? 'bg-[#0F2245] hover:bg-[#0A1A36] text-white' : 'bg-[#F1F3F5] text-[#94A3B8] cursor-not-allowed'">
            <svg v-if="submitting" class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
            </svg>
            {{ submitting ? 'Verifying…' : 'Enter the code to continue' }}
        </button>
    </div>

    <script>
        const { createApp } = Vue;

        createApp({
            data() {
                return {
                    digits: ['', '', '', '', '', ''],
                    digitRefs: [],
                    submitting: false,
                    resending: false,
                    resendMessage: '',
                    serverError: '',
                };
            },
            computed: {
                canSubmit() {
                    return this.digits.every(d => d !== '');
                },
            },
            methods: {
                setDigitRef(el, i) {
                    if (el) this.digitRefs[i] = el;
                },
                onDigitInput(i, e) {
                    const val = e.target.value.replace(/\D/g, '').slice(-1);
                    this.digits[i] = val;
                    if (val && i < 5) {
                        this.digitRefs[i + 1]?.focus();
                    }
                },
                onKeydown(i, e) {
                    if (e.key === 'Backspace' && !this.digits[i] && i > 0) {
                        this.digitRefs[i - 1]?.focus();
                    }
                },
                onPaste(e) {
                    const text = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
                    if (!text) return;
                    e.preventDefault();
                    for (let i = 0; i < 6; i++) {
                        this.digits[i] = text[i] || '';
                    }
                    this.digitRefs[Math.min(text.length, 6) - 1]?.focus();
                },
                async handleSubmit() {
                    if (!this.canSubmit || this.submitting) return;
                    this.submitting = true;
                    this.serverError = '';

                    try {
                        const res = await fetch('verify.php?action=verify_otp', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ code: this.digits.join('') }),
                        });
                        const data = await res.json();

                        if (data.success) {
                            window.location.href = data.redirect;
                        } else {
                            this.serverError = data.message || 'Something went wrong. Please try again.';
                        }
                    } catch (e) {
                        this.serverError = 'Network error. Please try again.';
                    } finally {
                        this.submitting = false;
                    }
                },
                async resend() {
                    if (this.resending) return;
                    this.resending = true;
                    this.resendMessage = '';
                    this.serverError = '';

                    try {
                        const res = await fetch('verify.php?action=resend_otp', { method: 'POST' });
                        const data = await res.json();

                        if (data.success) {
                            this.resendMessage = 'A new code has been sent.';
                        } else {
                            this.serverError = data.message || 'Could not resend the code.';
                        }
                    } catch (e) {
                        this.serverError = 'Network error. Please try again.';
                    } finally {
                        this.resending = false;
                    }
                },
            },
        }).mount('#app');
    </script>
</body>

</html>