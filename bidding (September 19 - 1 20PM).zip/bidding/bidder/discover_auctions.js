const AUCTION_TYPE_META = {
  english: {
    label: "English",
    bg: "#DBEAFE",
    text: "#1D4ED8",
    icon: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h5" stroke-linecap="round"/>',
  },
  dutch: {
    label: "Dutch",
    bg: "#FFEDD5",
    text: "#C2410C",
    icon: '<path d="M6 6l6 12 6-12" stroke-linecap="round" stroke-linejoin="round"/>',
  },
  blind: {
    label: "Blind",
    bg: "#EDE9FE",
    text: "#6D28D9",
    icon: '<path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z" stroke-linecap="round" stroke-linejoin="round"/><line x1="3" y1="20" x2="21" y2="4" stroke-linecap="round"/>',
  },
  proxy: {
    label: "Proxy",
    bg: "#E2E8F0",
    text: "#475569",
    icon: '<rect x="7" y="7" width="10" height="10" rx="1"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.5 5.5l2 2M16.5 16.5l2 2M5.5 18.5l2-2M16.5 7.5l2-2" stroke-linecap="round"/>',
  },
  buynow: {
    label: "Buy Now",
    bg: "#FEE2E2",
    text: "#DC2626",
    icon: '<path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" stroke-linecap="round" stroke-linejoin="round"/>',
  },
};

const AUCTION_STATUS_META = {
  live: { label: "Live", bg: "#D1FAE5", text: "#047857" },
  ending: { label: "Ending Soon", bg: "#FEE2E2", text: "#B91C1C" },
  ended: { label: "Ended", bg: "#E2E8F0", text: "#475569" },
};

const FILTER_OPTIONS = [
  {
    value: "all",
    label: "All Types",
    icon: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  },
  { value: "english", label: "English", icon: AUCTION_TYPE_META.english.icon },
  { value: "dutch", label: "Dutch", icon: AUCTION_TYPE_META.dutch.icon },
  { value: "blind", label: "Blind", icon: AUCTION_TYPE_META.blind.icon },
  { value: "proxy", label: "Proxy", icon: AUCTION_TYPE_META.proxy.icon },
  { value: "buynow", label: "Buy Now", icon: AUCTION_TYPE_META.buynow.icon },
];

// Front-end placeholder data — swap for a real endpoint later.
const DISCOVER_AUCTIONS = [
  {
    id: 1,
    title: "Sunset in Dasma",
    creator: "Maria Santos",
    image: "",
    status: "live",
    type: "english",
    priceLabel: "Current Bid",
    price: 5000,
    hidden: false,
    bids: 14,
    timeLeft: "2h 15m",
  },
  {
    id: 2,
    title: "Blue Hour Manila",
    creator: "Lena Buenaventura",
    image:
      "https://images.unsplash.com/photo-1518818419377-a0a4b8d1f0e8?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "dutch",
    priceLabel: "Current Bid",
    price: 4800,
    hidden: false,
    bids: 9,
    timeLeft: "6h 40m",
  },
  {
    id: 3,
    title: "Roots & Branches",
    creator: "Marco Villanueva",
    image:
      "https://images.unsplash.com/photo-1577720580479-7d839d829c73?auto=format&fit=crop&w=500&q=70",
    status: "ending",
    type: "proxy",
    priceLabel: "Current Bid",
    price: 8750,
    hidden: false,
    bids: 22,
    timeLeft: "8m",
  },
  {
    id: 4,
    title: "Halo-Halo Series #3",
    creator: "Paolo Reyes",
    image:
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "blind",
    priceLabel: "Min Bid",
    price: null,
    hidden: true,
    bids: 9,
    timeLeft: "1d 2h",
  },
  {
    id: 5,
    title: "Mayon at Dawn",
    creator: "Aisha Dela Torre",
    image:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "buynow",
    priceLabel: "Fixed Price",
    price: 12000,
    hidden: false,
    bids: null,
    timeLeft: null,
  },
  {
    id: 6,
    title: "Taal Reflection",
    creator: "Juan dela Cruz",
    image:
      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "english",
    priceLabel: "Current Bid",
    price: 3600,
    hidden: false,
    bids: 7,
    timeLeft: "3h 20m",
  },
  {
    id: 7,
    title: "Jeepney Dreams",
    creator: "Sofia Lim",
    image:
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=500&q=70",
    status: "ending",
    type: "dutch",
    priceLabel: "Current Bid",
    price: 2200,
    hidden: false,
    bids: 5,
    timeLeft: "12m",
  },
  {
    id: 8,
    title: "Bangka at Sunrise",
    creator: "Rico Navarro",
    image:
      "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "proxy",
    priceLabel: "Current Bid",
    price: 6100,
    hidden: false,
    bids: 11,
    timeLeft: "4h 50m",
  },
  {
    id: 9,
    title: "Pasig River Study",
    creator: "Chloe Tan",
    image:
      "https://images.unsplash.com/photo-1518987048-93e29699e79a?auto=format&fit=crop&w=500&q=70",
    status: "ended",
    type: "blind",
    priceLabel: "Min Bid",
    price: 4400,
    hidden: false,
    bids: 17,
    timeLeft: null,
  },
  {
    id: 10,
    title: "Ifugao Terraces",
    creator: "Ben Cruz",
    image:
      "https://images.unsplash.com/photo-1518623489648-a173ef7824f3?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "english",
    priceLabel: "Current Bid",
    price: 7200,
    hidden: false,
    bids: 13,
    timeLeft: "9h 05m",
  },
  {
    id: 11,
    title: "Manila Bay Gold",
    creator: "Nico Reyes",
    image:
      "https://images.unsplash.com/photo-1495344517868-8ebaf0a2044a?auto=format&fit=crop&w=500&q=70",
    status: "live",
    type: "buynow",
    priceLabel: "Fixed Price",
    price: 9500,
    hidden: false,
    bids: null,
    timeLeft: null,
  },
  {
    id: 12,
    title: "Baguio Pines",
    creator: "Andrea Reyes",
    image:
      "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=500&q=70",
    status: "ending",
    type: "dutch",
    priceLabel: "Current Bid",
    price: 3100,
    hidden: false,
    bids: 6,
    timeLeft: "45m",
  },
];

const auctionCard = {
  props: {
    auction: { type: Object, required: true },
  },
  emits: ["place-bid"],
  computed: {
    statusMeta() {
      return (
        AUCTION_STATUS_META[this.auction.status] || AUCTION_STATUS_META.ended
      );
    },
    typeMeta() {
      return AUCTION_TYPE_META[this.auction.type] || AUCTION_TYPE_META.english;
    },
    priceDisplay() {
      if (this.auction.hidden) return "Hidden";
      if (this.auction.price == null) return "\u2014";
      return `\u20B1 ${Number(this.auction.price).toLocaleString("en-PH")}`;
    },
    isClosed() {
      return this.auction.status === "ended";
    },
  },
  template: `
        <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden flex flex-col">
            <div class="relative aspect-[4/3] bg-[#0B1526]">
                <img :src="auction.image" :alt="auction.title" class="w-full h-full object-cover">

                <div class="absolute top-3 left-3 flex items-center gap-1.5 flex-wrap max-w-[calc(100%-1.5rem)]">
                    <span class="inline-flex text-[11px] font-semibold px-2.5 py-1 rounded-full"
                        :style="{ background: statusMeta.bg, color: statusMeta.text }">
                        {{ statusMeta.label }}
                    </span>
                    <span class="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full"
                        :style="{ background: typeMeta.bg, color: typeMeta.text }">
                        <svg class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" v-html="typeMeta.icon"></svg>
                        {{ typeMeta.label }}
                    </span>
                </div>

                <span v-if="auction.timeLeft" class="absolute bottom-3 right-3 inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-full bg-black/60 text-white backdrop-blur-sm">
                    <svg class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
                    {{ auction.timeLeft }}
                </span>
            </div>

            <div class="p-4 flex flex-col flex-1">
                <h3 class="font-medium text-[#0F172A] truncate">{{ auction.title }}</h3>
                <p class="text-sm text-[#94A3B8] truncate">by {{ auction.creator }}</p>

                <div class="mt-3 flex items-end justify-between gap-3">
                    <div class="min-w-0">
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">{{ auction.priceLabel }}</p>
                        <p class="text-lg font-bold" :class="isClosed ? 'text-[#94A3B8]' : 'text-[#10B981]'">{{ priceDisplay }}</p>
                        <p class="text-xs text-[#94A3B8] mt-0.5">
                            <span v-if="isClosed">Closed</span>
                            <span v-else-if="auction.bids != null">{{ auction.bids }} bids</span>
                        </p>
                    </div>

                    <button v-if="!isClosed" type="button" @click="$emit('place-bid', auction)"
                        class="shrink-0 h-9 px-4 rounded-lg text-sm font-medium text-white transition-colors"
                        :class="auction.type === 'buynow' ? 'bg-[#EF4444] hover:bg-red-600' : 'bg-[#0F2245] hover:bg-[#0A1A36]'">
                        {{ auction.type === 'buynow' ? 'Buy Now' : 'Place Bid' }}
                    </button>
                </div>
            </div>
        </div>
    `,
};

const discoverAuctionsView = {
  components: { "site-header": siteHeader, "auction-card": auctionCard },
  data() {
    return {
      user: { firstName: "Maria", lastName: "Santos" },
      searchQuery: "",
      activeType: "all",
      pageSize: 9,
      currentPage: 1,
      filterOptions: FILTER_OPTIONS,
      auctions: DISCOVER_AUCTIONS,
    };
  },
  computed: {
    filteredAuctions() {
      const q = this.searchQuery.trim().toLowerCase();
      return this.auctions.filter((a) => {
        const matchesType =
          this.activeType === "all" || a.type === this.activeType;
        const matchesQuery =
          !q ||
          a.title.toLowerCase().includes(q) ||
          a.creator.toLowerCase().includes(q);
        return matchesType && matchesQuery;
      });
    },
    totalPages() {
      return Math.max(
        1,
        Math.ceil(this.filteredAuctions.length / this.pageSize),
      );
    },
    pagedAuctions() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.filteredAuctions.slice(start, start + this.pageSize);
    },
    pageNumbers() {
      return Array.from({ length: this.totalPages }, (_, i) => i + 1);
    },
    rangeStart() {
      return this.filteredAuctions.length === 0
        ? 0
        : (this.currentPage - 1) * this.pageSize + 1;
    },
    rangeEnd() {
      return Math.min(
        this.currentPage * this.pageSize,
        this.filteredAuctions.length,
      );
    },
  },
  watch: {
    searchQuery() {
      this.currentPage = 1;
    },
    activeType() {
      this.currentPage = 1;
    },
  },
  methods: {
    goToPage(p) {
      this.currentPage = Math.min(Math.max(1, p), this.totalPages);
    },
    setType(value) {
      this.activeType = value;
    },
    placeBid(auction) {
      // Front-end only: no request sent yet.
      this.$router.push(`/bid/${auction.id}`);
    },
  },
  template: `
        <div class="min-h-screen flex flex-col bg-[#F8FAFC]">
            <site-header :user="user"
                :nav-items="[{ label: 'Discover', to: '/discover' }, { label: 'Winning Bids', to: '/bidder/winning-bids' }]"
                active-label="Discover" profile-to="/bidder/profile" />

            <main class="flex-1 w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-6 sm:py-10 mx-auto">

                <div class="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2">
                    <div>
                        <h1 class="font-serif text-2xl sm:text-[2rem] font-bold tracking-tight">Discover Auctions</h1>
                        <p class="mt-1 text-sm text-[#64748B]">Browse and bid on original Philippine art from independent creators.</p>
                    </div>
                    <p class="text-sm text-[#94A3B8] shrink-0">{{ filteredAuctions.length }} results</p>
                </div>

                <div class="mt-5 bg-white rounded-xl border border-[#DEE2E8] p-4">
                    <div class="relative">
                        <svg class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
                        <input v-model="searchQuery" type="text" placeholder="Search auctions or creators..."
                            class="w-full h-11 pl-10 pr-4 rounded-lg border border-[#DEE2E8] text-[15px] placeholder:text-gray-400 focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15">
                    </div>

                    <div class="mt-3 flex items-center gap-2 overflow-x-auto pb-1 -mx-1 px-1">
                        <button v-for="opt in filterOptions" :key="opt.value" type="button" @click="setType(opt.value)"
                            class="shrink-0 inline-flex items-center gap-1.5 h-9 px-3.5 rounded-full text-sm font-medium border transition-colors whitespace-nowrap"
                            :class="activeType === opt.value ? 'bg-[#0F2245] border-[#0F2245] text-white' : 'border-[#DEE2E8] text-[#374151] hover:border-[#0F2245]'">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" v-html="opt.icon"></svg>
                            {{ opt.label }}
                        </button>
                    </div>
                </div>

                <div v-if="pagedAuctions.length" class="mt-5 sm:mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                    <auction-card v-for="a in pagedAuctions" :key="a.id" :auction="a" @place-bid="placeBid" />
                </div>

                <div v-else class="mt-6 bg-white rounded-xl border border-dashed border-[#DEE2E8] px-6 py-16 text-center">
                    <p class="font-medium">No auctions match your search</p>
                    <p class="mt-1 text-sm text-[#64748B]">Try a different keyword or clear the type filter.</p>
                </div>

                <div v-if="filteredAuctions.length" class="mt-5 sm:mt-6 bg-white rounded-xl border border-[#DEE2E8] flex items-center justify-between gap-3 px-5 py-4 flex-wrap">
                    <p class="text-sm text-[#94A3B8]">Showing {{ rangeStart }}\u2013{{ rangeEnd }} of {{ filteredAuctions.length }}</p>
                    <div v-if="totalPages > 1" class="flex items-center gap-1.5">
                        <button type="button" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
                            class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                        </button>
                        <button v-for="p in pageNumbers" :key="p" type="button" @click="goToPage(p)"
                            class="min-w-[32px] h-8 px-2 rounded-lg text-sm font-medium transition-colors"
                            :class="p === currentPage ? 'bg-[#0F2245] text-white' : 'border border-[#DEE2E8] text-[#64748B] hover:border-[#0F2245]'">
                            {{ p }}
                        </button>
                        <button type="button" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
                            class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
                        </button>
                    </div>
                </div>
            </main>

            <button type="button" aria-label="Help"
                class="fixed bottom-5 right-5 w-11 h-11 rounded-full bg-white border border-[#DEE2E8] shadow-lg flex items-center justify-center text-[#0F2245] hover:bg-[#F8FAFC] transition-colors z-30">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 015 .4c0 1.6-2.5 2-2.5 3.6"/><circle cx="12" cy="17" r="0.6" fill="currentColor" stroke="none"/></svg>
            </button>
        </div>
    `,
};
