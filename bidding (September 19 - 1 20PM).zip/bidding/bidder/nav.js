// Shared top nav bar. Every creator view (creator_dashboard.js, manage_auction.js,
// deposit_tracker.js, orders.js...) currently hand-rolls this same header —
// this component is meant to eventually replace all of those with one
// definition. New views (like the bidder pages) should use this from the start.
//
// Usage:
//   components: { "site-header": siteHeader },
//   template: `
//     <site-header :nav-items="navItems" active-label="My Auctions" :user="user" profile-to="/creator/profile">
//       <template #actions>
//         <button ...>New Auction</button>
//       </template>
//     </site-header>
//   `
//
// navItems: [{ label: "My Auctions", to: "/creator/dashboard" }, { label: "Locked", to: null }]
// A null `to` renders the label as disabled/greyed — same convention used everywhere else in the app.
//
// A notifications bell renders automatically whenever `user` is passed (no
// extra markup needed). It shows an unread dot by default — pass
// :has-notifications="false" to hide it — and listen for @notifications-click
// if a page wants to react beyond the built-in "not wired up yet" toast.
const siteHeader = {
  props: {
    brandTo: { type: String, default: "/" },
    navItems: { type: Array, default: () => [] },
    activeLabel: { type: String, default: null },
    user: { type: Object, default: null }, // { firstName, lastName }
    profileTo: { type: String, default: null },
    hasNotifications: { type: Boolean, default: true },
  },
  data() {
    return { mobileMenu: false };
  },
  computed: {
    initials() {
      if (!this.user) return "";
      const first = this.user.firstName ? this.user.firstName[0] : "";
      const last = this.user.lastName ? this.user.lastName[0] : "";
      return `${first}${last}`.toUpperCase();
    },
  },
  methods: {
    goToProfile() {
      if (this.profileTo) this.$router.push(this.profileTo);
    },
    showNotifications() {
      // Front-end only: no notifications endpoint yet. Also emitted so a
      // page can listen for @notifications-click and do something smarter.
      this.$emit("notifications-click");
      Swal.fire({
        title: "Notifications",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
  },
  template: `
        <header class="bg-[#0F2245] text-white sticky top-0 z-40">
            <div class="w-full px-4 sm:px-6 lg:px-8">
                <div class="h-14 sm:h-16 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-8 min-w-0">
                        <router-link :to="brandTo" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

                        <nav v-if="navItems.length" class="hidden md:flex items-center gap-6">
                            <template v-for="item in navItems" :key="item.label">
                                <router-link v-if="item.to" :to="item.to"
                                    class="text-sm transition-colors"
                                    :class="activeLabel === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                                    {{ item.label }}
                                </router-link>
                                <span v-else class="text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                            </template>
                        </nav>
                    </div>

                    <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                        <slot name="actions"></slot>

                        <button v-if="user" type="button" @click="showNotifications" aria-label="Notifications"
                            class="relative w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                            <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                        </button>

                        <button v-if="user" type="button" @click="goToProfile" aria-label="View profile"
                            class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors shrink-0">
                            {{ initials }}
                        </button>

                        <button v-if="navItems.length" type="button" @click="mobileMenu = !mobileMenu"
                            class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors shrink-0"
                            aria-label="Toggle navigation">
                            <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                            <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>
                </div>
            </div>

            <nav v-if="navItems.length" v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
                <div class="px-4 py-3 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="mobileMenu = false"
                            class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="activeLabel === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
                            {{ item.label }}
                        </router-link>
                        <span v-else class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                    </template>
                    <div v-if="$slots['mobile-actions'] || $slots.actions" class="pt-2 mt-2 border-t border-white/10 space-y-1">
                        <slot name="mobile-actions"><slot name="actions"></slot></slot>
                    </div>
                </div>
            </nav>
        </header>
    `,
};
