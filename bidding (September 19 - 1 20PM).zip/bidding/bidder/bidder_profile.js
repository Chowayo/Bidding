// Icons sourced from Lucide (lucide.dev, ISC licensed) — plain inline SVG,
// same convention as creator_profile.js. Named distinctly (BIDDER_ICONS /
// BidderIcon) since every view's script shares one global scope in index.php.
const BIDDER_ICONS = {
  chevronRight: '<path d="M9 18l6-6-6-6"/>',
  checkCircle:
    '<circle cx="12" cy="12" r="9"/><path d="M8.5 12.2l2.4 2.4 4.6-5.2"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  logOut:
    '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
};

const BidderIcon = {
  props: { name: String },
  template: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" v-html="BIDDER_ICONS[name] || ''"></svg>`,
  created() {
    this.BIDDER_ICONS = BIDDER_ICONS;
  },
};

const bidderProfileView = {
  components: { "site-header": siteHeader, icon: BidderIcon },
  data() {
    return {
      // Front-end only — mock data, swap for the real bidder-profile endpoint once it exists.
      bidder: {
        firstName: "Maria",
        lastName: "Santos",
        email: "maria@email.com",
        mobile: "+63 912 345 6789",
      },
      metrics: {
        auctionsWon: 4,
        activeBids: 2,
        totalSpent: 18450,
      },
      bidHistory: [
        {
          id: 1,
          title: "Sunset in Dasma",
          amount: 5000,
          status: "Won",
          image:
            "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=100&q=70",
        },
        {
          id: 2,
          title: "Blue Hour Manila",
          amount: 3200,
          status: "Outbid",
          image:
            "https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=100&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          amount: 8750,
          status: "Active",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=100&q=70",
        },
      ],
      activeDeposit: {
        title: "Sunset in Dasma",
        amount: 5000,
        image:
          "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=100&q=70",
      },
    };
  },
  computed: {
    // site-header only needs firstName/lastName for initials + display.
    user() {
      return {
        firstName: this.bidder.firstName,
        lastName: this.bidder.lastName,
      };
    },
    personalFields() {
      return [
        { label: "First Name", value: this.bidder.firstName },
        { label: "Last Name", value: this.bidder.lastName },
        { label: "Mobile", value: this.bidder.mobile },
        { label: "Email", value: this.bidder.email },
      ];
    },
    stats() {
      return [
        {
          label: "Auctions Won",
          value: this.metrics.auctionsWon,
          accent: "text-[#10B981]",
        },
        {
          label: "Active Bids",
          value: this.metrics.activeBids,
          accent: "text-[#1A56DB]",
        },
        {
          label: "Total Spent",
          value: "\u20B1" + this.formatMoney(this.metrics.totalSpent),
          accent: "text-[#0F172A]",
        },
        {
          label: "Deposit Held",
          value: this.activeDeposit
            ? "\u20B1" + this.formatMoney(this.activeDeposit.amount)
            : "\u20B10",
          accent: "text-[#F59E0B]",
        },
      ];
    },
  },
  methods: {
    formatMoney(value) {
      return Number(value).toLocaleString("en-PH");
    },
    bidStatusClass(status) {
      const map = {
        Won: "bg-[#10B981]/10 text-[#10B981]",
        Outbid: "bg-[#F59E0B]/10 text-[#F59E0B]",
        Active: "bg-[#1A56DB]/10 text-[#1A56DB]",
        Lost: "bg-[#94A3B8]/15 text-[#94A3B8]",
      };
      return map[status] || map.Lost;
    },
    confirmReceipt() {
      Swal.fire({
        icon: "question",
        title: "Confirm receipt?",
        text: `Confirming releases the \u20B1${this.formatMoney(this.activeDeposit.amount)} deposit for "${this.activeDeposit.title}" to the creator.`,
        showCancelButton: true,
        confirmButtonText: "Confirm Receipt",
        confirmButtonColor: "#1A56DB",
      }).then((result) => {
        if (!result.isConfirmed) return;
        this.activeDeposit = null;
        Swal.fire({
          icon: "success",
          title: "Receipt confirmed",
          timer: 1400,
          showConfirmButton: false,
        });
      });
    },
    changePassword() {
      Swal.fire({
        title: "Change Password",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    manageTwoFactor() {
      Swal.fire({
        title: "Two-Factor Auth",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    notificationSettings() {
      Swal.fire({
        title: "Notification Settings",
        text: "Not wired up yet.",
        confirmButtonColor: "#1A56DB",
      });
    },
    logOut() {
      Swal.fire({
        icon: "question",
        title: "Log out?",
        showCancelButton: true,
        confirmButtonText: "Log Out",
        confirmButtonColor: "#EF4444",
      }).then((result) => {
        if (result.isConfirmed) this.$router.push("/");
      });
    },
  },
  template: `
        <div class="min-h-screen flex flex-col bg-[#F8FAFC]">
            <site-header :user="user"
                :nav-items="[{ label: 'Discover', to: '/discover' }, { label: 'Winning Bids', to: '/bidder/winning-bids' }]"
                profile-to="/bidder/profile" />

            <main class="flex-1 w-full max-w-5xl px-4 sm:px-6 lg:px-8 py-6 sm:py-8 mx-auto">

                <!-- Profile header card -->
                <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                    <div class="relative h-20 sm:h-24 bg-[#0F2245]"
                        style="background-image: repeating-linear-gradient(135deg, rgba(255,255,255,0.04) 0 2px, transparent 2px 14px);">
                        <span class="absolute top-3 right-3 text-[10px] font-semibold uppercase tracking-wider bg-white/15 text-white rounded-full px-2.5 py-1">
                            Bidder Account
                        </span>
                    </div>

                    <div class="px-5 sm:px-6 pt-4 pb-5 sm:pb-6">
                        <h1 class="text-lg sm:text-xl font-semibold">{{ bidder.firstName }} {{ bidder.lastName }}</h1>
                        <p class="mt-0.5 text-sm text-[#64748B]">{{ bidder.email }} &middot; {{ bidder.mobile }}</p>

                        <div class="mt-3 flex flex-wrap items-center gap-2">
                            <span class="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-[#10B981]/10 text-[#10B981]">
                                <icon name="checkCircle" class="w-3.5 h-3.5" />
                                Verified Bidder
                            </span>
                        </div>
                    </div>
                </div>

                <!-- ============ CONTENT GRID ============ -->
                <div class="mt-4 sm:mt-5 grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5">

                    <!-- Right column on desktop, shown first on mobile -->
                    <div class="order-1 lg:order-2 lg:col-span-2 space-y-4 sm:space-y-5">

                        <!-- Stat cards -->
                        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                            <div v-for="stat in stats" :key="stat.label" class="bg-white rounded-xl border border-[#DEE2E8] px-4 py-4">
                                <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B] truncate">{{ stat.label }}</p>
                                <p class="mt-1.5 font-serif text-xl sm:text-2xl font-bold leading-none" :class="stat.accent">{{ stat.value }}</p>
                            </div>
                        </div>

                        <!-- Bid history -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                            <div class="px-5 py-4 border-b border-[#DEE2E8] flex items-center justify-between">
                                <h2 class="text-sm font-semibold">Bid History</h2>
                                <span class="text-xs text-[#64748B]">{{ bidHistory.length }} bids</span>
                            </div>
                            <ul class="divide-y divide-[#DEE2E8]">
                                <li v-for="b in bidHistory" :key="b.id" class="flex items-center gap-3 px-5 py-3">
                                    <img :src="b.image" :alt="b.title" class="w-10 h-10 rounded-lg object-cover shrink-0">
                                    <p class="flex-1 min-w-0 text-sm font-medium truncate">{{ b.title }}</p>
                                    <span class="text-sm font-semibold text-[#10B981] shrink-0">&#8369;{{ formatMoney(b.amount) }}</span>
                                    <span class="text-[11px] font-semibold px-2 py-0.5 rounded-full shrink-0" :class="bidStatusClass(b.status)">{{ b.status }}</span>
                                </li>
                            </ul>
                        </div>

                        <!-- Active deposit -->
                        <div v-if="activeDeposit" class="bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                            <div class="px-5 py-4 border-b border-[#DEE2E8]">
                                <h2 class="text-sm font-semibold">Active Deposit</h2>
                            </div>
                            <div class="px-5 py-4 flex items-start gap-3">
                                <img :src="activeDeposit.image" :alt="activeDeposit.title" class="w-12 h-12 rounded-lg object-cover shrink-0">
                                <div class="min-w-0 flex-1">
                                    <p class="text-sm font-medium truncate">{{ activeDeposit.title }}</p>
                                    <p class="text-xs text-[#64748B] mt-0.5">Deposit held &middot; Awaiting delivery confirmation</p>
                                    <button type="button" @click="confirmReceipt"
                                        class="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-[#1A56DB] hover:underline">
                                        Confirm Receipt
                                        <icon name="arrowRight" class="w-3.5 h-3.5" />
                                    </button>
                                </div>
                                <span class="font-serif text-lg font-bold text-[#F59E0B] shrink-0">&#8369;{{ formatMoney(activeDeposit.amount) }}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Left column on desktop, shown second on mobile -->
                    <div class="order-2 lg:order-1 space-y-4 sm:space-y-5">

                        <!-- Personal info -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Personal Info</p>
                            <dl class="mt-3 space-y-3">
                                <div v-for="field in personalFields" :key="field.label">
                                    <dt class="text-[11px] font-semibold tracking-[0.06em] uppercase text-[#94A3B8]">{{ field.label }}</dt>
                                    <dd class="text-sm mt-0.5">{{ field.value }}</dd>
                                </div>
                            </dl>
                        </div>

                        <!-- Security -->
                        <div class="bg-white rounded-xl border border-[#DEE2E8] p-5">
                            <p class="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#64748B]">Security</p>
                            <div class="mt-2 divide-y divide-[#DEE2E8]">
                                <button type="button" @click="changePassword" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                    Change Password
                                    <icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                </button>
                                <button type="button" @click="manageTwoFactor" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                    Two-Factor Auth
                                    <icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                </button>
                                <button type="button" @click="notificationSettings" class="w-full flex items-center justify-between py-3 text-sm text-left hover:text-[#1A56DB] transition-colors">
                                    Notification Settings
                                    <icon name="chevronRight" class="w-4 h-4 text-[#94A3B8]" />
                                </button>
                            </div>
                        </div>

                        <button type="button" @click="logOut"
                            class="w-full h-11 rounded-lg border border-[#EF4444]/30 text-[#EF4444] text-sm font-medium hover:bg-[#EF4444]/5 transition-colors flex items-center justify-center gap-2">
                            <icon name="logOut" class="w-4 h-4" />
                            Log Out
                        </button>
                    </div>
                </div>
            </main>
        </div>
    `,
};
