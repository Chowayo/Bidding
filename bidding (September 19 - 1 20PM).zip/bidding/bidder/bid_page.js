// Per-type presentation: badge copy/icon + the descriptive line under the title.
// The colored info box and form below are type-specific and live directly in
// the template (they differ too much in shape to squeeze into one lookup).
const BID_TYPE_META = {
  english: {
    badge: "English Auction",
    subtitle: "Ascending \u00B7 Highest bid wins",
    icon: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h5" stroke-linecap="round"/>',
  },
  dutch: {
    badge: "Dutch Auction",
    subtitle: "Descending \u00B7 First to accept wins",
    icon: '<path d="M6 6l6 12 6-12" stroke-linecap="round" stroke-linejoin="round"/>',
  },
  blind: {
    badge: "Blind Bidding",
    subtitle: "Secret offers \u00B7 Revealed at close",
    icon: '<path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z" stroke-linecap="round" stroke-linejoin="round"/><line x1="3" y1="20" x2="21" y2="4" stroke-linecap="round"/>',
  },
  proxy: {
    badge: "Proxy / Auto Bidding",
    subtitle: "Automatic \u00B7 System bids for you",
    icon: '<rect x="7" y="7" width="10" height="10" rx="1"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.5 5.5l2 2M16.5 16.5l2 2M5.5 18.5l2-2M16.5 7.5l2-2" stroke-linecap="round"/>',
  },
  buynow: {
    badge: "Buy-It-Now",
    subtitle: "Instant purchase \u00B7 Fixed price",
    icon: '<path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" stroke-linecap="round" stroke-linejoin="round"/>',
  },
};

// Front-end placeholder data, keyed by id — swap for a real endpoint later.
// Extends what discover_auctions.js shows with the extra fields each bid
// type's form needs (increment, drop schedule, floor, min offer...).
const BID_PAGE_DATA = {
  1: {
    title: "Sunset in Dasma",
    creator: "@mariasantos_art",
    image: "",
    status: "live",
    type: "english",
    bids: 14,
    timeLeftSeconds: 2 * 3600 + 15 * 60 + 30,
    currentBid: 5000,
    increment: 200,
  },
  2: {
    title: "Blue Hour Manila",
    creator: "@lenab_art",
    image:
      "https://images.unsplash.com/photo-1518818419377-a0a4b8d1f0e8?auto=format&fit=crop&w=1200&q=75",
    status: "live",
    type: "dutch",
    bids: 9,
    timeLeftSeconds: 6 * 3600 + 40 * 60,
    dropPrice: 4800,
    dropAmount: 200,
    dropIntervalMinutes: 10,
    floorPrice: 2000,
  },
  4: {
    title: "Halo-Halo Series #3",
    creator: "@paoloreyes",
    image:
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=75",
    status: "live",
    type: "blind",
    bids: 9,
    timeLeftSeconds: 26 * 3600,
    minOffer: 1000,
  },
  3: {
    title: "Roots & Branches",
    creator: "@marcov_art",
    image:
      "https://images.unsplash.com/photo-1577720580479-7d839d829c73?auto=format&fit=crop&w=1200&q=75",
    status: "ending",
    type: "proxy",
    bids: 22,
    timeLeftSeconds: 8 * 60,
    currentBid: 5000,
    increment: 100,
  },
  5: {
    title: "Mayon at Dawn",
    creator: "@aishadt",
    image:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=75",
    status: "live",
    type: "buynow",
    bids: null,
    timeLeftSeconds: null,
    fixedPrice: 12000,
  },
};

const STATUS_LABEL = {
  live: "Live Auction",
  ending: "Ending Soon",
  ended: "Auction Ended",
};

const bidPageView = {
  data() {
    return {
      auction: null,
      secondsLeft: null,
      timerHandle: null,
      englishAmount: "",
      blindAmount: "",
      submitting: false,
    };
  },
  computed: {
    typeMeta() {
      return this.auction ? BID_TYPE_META[this.auction.type] : null;
    },
    statusLabel() {
      return this.auction
        ? STATUS_LABEL[this.auction.status] || "Live Auction"
        : "";
    },
    formattedTimeLeft() {
      if (this.secondsLeft == null) return null;
      const s = Math.max(0, this.secondsLeft);
      const h = Math.floor(s / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = s % 60;
      const pad = (n) => String(n).padStart(2, "0");
      return `${pad(h)}:${pad(m)}:${pad(sec)}`;
    },
    minNextBid() {
      return this.auction
        ? this.auction.currentBid + this.auction.increment
        : 0;
    },
  },
  created() {
    const data = BID_PAGE_DATA[this.$route.params.id];
    this.auction = data ? { ...data } : null;
    if (this.auction && this.auction.timeLeftSeconds != null) {
      this.secondsLeft = this.auction.timeLeftSeconds;
      this.timerHandle = setInterval(() => {
        if (this.secondsLeft > 0) this.secondsLeft--;
        else clearInterval(this.timerHandle);
      }, 1000);
    }
  },
  beforeUnmount() {
    if (this.timerHandle) clearInterval(this.timerHandle);
  },
  methods: {
    fmt(n) {
      return `\u20B1 ${Number(n).toLocaleString("en-PH")}`;
    },
    async submitEnglishBid() {
      const amount = Number(this.englishAmount);
      if (!amount || amount < this.minNextBid) {
        Swal.fire({
          icon: "error",
          title: "Bid too low",
          text: `Your bid must be at least ${this.fmt(this.minNextBid)}.`,
          confirmButtonColor: "#0F2245",
        });
        return;
      }
      const result = await Swal.fire({
        icon: "question",
        title: "Place this bid?",
        text: `You're about to bid ${this.fmt(amount)} on "${this.auction.title}".`,
        showCancelButton: true,
        confirmButtonText: "Place Bid",
        confirmButtonColor: "#0F2245",
        cancelButtonColor: "#94A3B8",
      });
      if (!result.isConfirmed) return;

      this.auction.currentBid = amount;
      this.auction.bids++;
      this.englishAmount = "";
      await Swal.fire({
        icon: "success",
        title: "Bid placed!",
        text: `You're now the highest bidder at ${this.fmt(amount)}.`,
        confirmButtonColor: "#0F2245",
      });
    },
    async acceptDutchPrice() {
      const result = await Swal.fire({
        icon: "warning",
        title: "Accept this price?",
        text: `You'll win "${this.auction.title}" immediately at ${this.fmt(this.auction.dropPrice)}. This can't be undone.`,
        showCancelButton: true,
        confirmButtonText: "Accept & Win",
        confirmButtonColor: "#92400E",
        cancelButtonColor: "#94A3B8",
      });
      if (result.isConfirmed) {
        Swal.fire({
          icon: "success",
          title: "Sold!",
          text: `The artwork is yours at ${this.fmt(this.auction.dropPrice)}.`,
          confirmButtonColor: "#0F2245",
        });
      }
    },
    async submitBlindBid() {
      const amount = Number(this.blindAmount);
      if (!amount || amount < this.auction.minOffer) {
        Swal.fire({
          icon: "error",
          title: "Offer too low",
          text: `Your secret offer must be at least ${this.fmt(this.auction.minOffer)}.`,
          confirmButtonColor: "#0F2245",
        });
        return;
      }
      const result = await Swal.fire({
        icon: "question",
        title: "Submit this secret bid?",
        text: `Your offer of ${this.fmt(amount)} will be sealed until the auction closes.`,
        showCancelButton: true,
        confirmButtonText: "Submit Bid",
        confirmButtonColor: "#6D28D9",
        cancelButtonColor: "#94A3B8",
      });
      if (!result.isConfirmed) return;

      this.blindAmount = "";
      await Swal.fire({
        icon: "success",
        title: "Secret bid submitted",
        text: "Results are revealed once the auction closes.",
        confirmButtonColor: "#6D28D9",
      });
    },
    async submitProxyBid() {
      const amount = this.minNextBid;
      const result = await Swal.fire({
        icon: "question",
        title: "Place this bid?",
        text: `The system will place ${this.fmt(amount)} on your behalf for "${this.auction.title}".`,
        showCancelButton: true,
        confirmButtonText: "Bid Now",
        confirmButtonColor: "#0F2245",
        cancelButtonColor: "#94A3B8",
      });
      if (!result.isConfirmed) return;

      this.auction.currentBid = amount;
      this.auction.bids++;
      await Swal.fire({
        icon: "success",
        title: "Bid placed!",
        text: `The system placed ${this.fmt(amount)} on your behalf \u2014 you're now in the lead.`,
        confirmButtonColor: "#0F2245",
      });
    },
    async buyNow() {
      const result = await Swal.fire({
        icon: "warning",
        title: "Buy this now?",
        text: `This closes the auction immediately at ${this.fmt(this.auction.fixedPrice)} and takes you to checkout.`,
        showCancelButton: true,
        confirmButtonText: "Buy Now",
        confirmButtonColor: "#DC2626",
        cancelButtonColor: "#94A3B8",
      });
      if (result.isConfirmed) {
        // Front-end only: no request sent / PayMongo integration yet.
        console.log("Redirect to checkout for auction", this.auction);
      }
    },
  },
  template: `
        <div v-if="!auction" class="min-h-screen flex items-center justify-center bg-[#F8FAFC] px-4">
            <div class="text-center">
                <p class="font-medium">Auction not found</p>
                <router-link to="/discover" class="mt-2 inline-block text-sm text-[#0F2245] hover:underline">Back to Discover</router-link>
            </div>
        </div>

        <div v-else class="min-h-screen grid grid-cols-1 lg:grid-cols-[3fr_2fr]">

            <!-- ============ IMAGE / TIMER ============ -->
            <div class="relative h-64 sm:h-80 lg:h-auto bg-[#0B1526]">
                <img :src="auction.image" :alt="auction.title" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent"></div>

                <router-link to="/discover" aria-label="Back to Discover"
                    class="absolute top-4 left-4 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-sm flex items-center justify-center text-white transition-colors">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                </router-link>

                <div class="absolute bottom-0 left-0 right-0 p-5 sm:p-6">
                    <span class="inline-block text-xs font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full bg-white/15 text-white backdrop-blur-sm">
                        {{ statusLabel }}
                    </span>
                    <h1 class="mt-2 font-serif text-2xl sm:text-3xl font-bold text-white">{{ auction.title }}</h1>
                    <p class="text-sm text-white/70 mt-0.5">
                        by {{ auction.creator }}
                        <template v-if="auction.bids != null"> \u00B7 {{ auction.bids }} bids</template>
                    </p>

                    <div v-if="formattedTimeLeft" class="mt-3">
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-white/60">Time Left</p>
                        <p class="font-mono text-2xl sm:text-3xl font-bold text-white tabular-nums">{{ formattedTimeLeft }}</p>
                    </div>
                </div>
            </div>

            <!-- ============ BID PANEL ============ -->
            <div class="flex flex-col justify-center px-5 sm:px-10 lg:px-16 py-8 sm:py-10 bg-white">
                <div class="w-full max-w-md mx-auto">

                    <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-[#0F2245] text-white">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" v-html="typeMeta.icon"></svg>
                        {{ typeMeta.badge.toUpperCase() }}
                    </span>

                    <h2 class="mt-3 text-xl font-semibold text-[#0F172A]">{{ auction.title }}</h2>
                    <p class="text-sm text-[#94A3B8] italic">{{ typeMeta.subtitle }}</p>

                    <!-- ---------- ENGLISH ---------- -->
                    <template v-if="auction.type === 'english'">
                        <div class="mt-5 bg-[#F1F5F9] rounded-xl p-4">
                            <p class="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">Current Highest Bid</p>
                            <p class="text-2xl font-bold text-[#10B981] mt-1">{{ fmt(auction.currentBid) }}</p>
                            <p class="text-xs text-[#64748B] mt-1">Minimum next bid: {{ fmt(minNextBid) }}</p>
                        </div>

                        <label class="block mt-5 text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">Your Bid Amount (\u20B1)</label>
                        <input v-model="englishAmount" type="number" :placeholder="'e.g. ' + minNextBid.toLocaleString('en-PH')"
                            class="mt-1.5 w-full h-11 px-3.5 rounded-lg border border-[#DEE2E8] text-[15px] placeholder:text-gray-400 focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15">

                        <button type="button" @click="submitEnglishBid"
                            class="mt-4 w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-semibold tracking-wide transition-colors">
                            SUBMIT BID
                        </button>
                    </template>

                    <!-- ---------- DUTCH ---------- -->
                    <template v-else-if="auction.type === 'dutch'">
                        <div class="mt-5 bg-[#FEF9C3] border border-[#FDE68A] rounded-xl p-4">
                            <p class="text-[11px] font-semibold uppercase tracking-wider text-[#92400E]">Current Dropping Price</p>
                            <p class="text-2xl font-bold text-[#92400E] mt-1">{{ fmt(auction.dropPrice) }}</p>
                            <p class="text-xs text-[#92400E]/80 mt-1">Drops {{ fmt(auction.dropAmount) }} every {{ auction.dropIntervalMinutes }} minutes \u00B7 Floor: {{ fmt(auction.floorPrice) }}</p>
                        </div>

                        <div class="mt-4 bg-[#F1F5F9] rounded-lg p-3.5 text-sm text-[#475569]">
                            The first bidder to accept the current price wins. Once you click "Accept", the auction closes immediately and the artwork is yours at this price.
                        </div>

                        <button type="button" @click="acceptDutchPrice"
                            class="mt-4 w-full h-12 rounded-lg bg-[#92400E] hover:bg-[#78350F] text-white text-sm font-semibold tracking-wide transition-colors">
                            ACCEPT {{ fmt(auction.dropPrice) }}
                        </button>
                    </template>

                    <!-- ---------- BLIND ---------- -->
                    <template v-else-if="auction.type === 'blind'">
                        <div class="mt-5 bg-[#F5F3FF] border border-[#DDD6FE] rounded-xl p-4 flex items-start gap-3">
                            <span class="w-8 h-8 rounded-full bg-[#EDE9FE] flex items-center justify-center shrink-0 text-[#6D28D9]">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z"/><line x1="3" y1="20" x2="21" y2="4"/></svg>
                            </span>
                            <div class="min-w-0">
                                <p class="text-sm font-semibold text-[#6D28D9]">Blind Bidding \u2014 Bids Are Secret</p>
                                <p class="text-sm text-[#7C3AED]/90 mt-0.5">Your bid amount is hidden from all other bidders. The highest bid at close wins. Results revealed after the auction ends.</p>
                            </div>
                        </div>

                        <label class="block mt-5 text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">Your Secret Bid (\u20B1)</label>
                        <input v-model="blindAmount" type="number" placeholder="Enter your offer"
                            class="mt-1.5 w-full h-11 px-3.5 rounded-lg border border-[#DEE2E8] text-[15px] placeholder:text-gray-400 focus:outline-none focus:border-[#6D28D9] focus:ring-2 focus:ring-[#6D28D9]/15">
                        <p class="mt-1.5 text-xs text-[#94A3B8]">Minimum offer: {{ fmt(auction.minOffer) }}</p>

                        <button type="button" @click="submitBlindBid"
                            class="mt-4 w-full h-12 rounded-lg bg-[#6D28D9] hover:bg-[#5B21B6] text-white text-sm font-semibold tracking-wide transition-colors">
                            SUBMIT SECRET BID
                        </button>
                    </template>

                    <!-- ---------- PROXY ---------- -->
                    <template v-else-if="auction.type === 'proxy'">
                        <div class="mt-5 bg-[#F1F5F9] rounded-xl p-4">
                            <p class="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">Current Highest Bid</p>
                            <p class="text-2xl font-bold text-[#10B981] mt-1">{{ fmt(auction.currentBid) }}</p>
                            <p class="text-xs text-[#64748B] mt-1">Next bid: {{ fmt(minNextBid) }} (+{{ fmt(auction.increment) }} increment)</p>
                        </div>

                        <div class="mt-4 bg-[#EFF6FF] border border-[#BFDBFE] rounded-xl p-4 flex items-start gap-3">
                            <span class="w-8 h-8 rounded-full bg-[#DBEAFE] flex items-center justify-center shrink-0 text-[#1D4ED8]">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="7" width="10" height="10" rx="1"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/></svg>
                            </span>
                            <p class="text-sm text-[#1D4ED8] leading-relaxed">
                                Clicking Bid Now will automatically place {{ fmt(minNextBid) }} on your behalf \u2014 the minimum needed to take the lead.
                            </p>
                        </div>

                        <button type="button" @click="submitProxyBid"
                            class="mt-4 w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-semibold tracking-wide transition-colors">
                            BID NOW \u2014 {{ fmt(minNextBid) }}
                        </button>
                    </template>

                    <!-- ---------- BUY NOW ---------- -->
                    <template v-else-if="auction.type === 'buynow'">
                        <div class="mt-5 bg-[#FEF2F2] border border-[#FECACA] rounded-xl p-4">
                            <p class="text-[11px] font-semibold uppercase tracking-wider text-[#DC2626]">Fixed Purchase Price</p>
                            <p class="text-2xl font-bold text-[#DC2626] mt-1">{{ fmt(auction.fixedPrice) }}</p>
                            <p class="text-xs text-[#DC2626]/80 mt-1">Buy instantly \u2014 no bidding, no waiting</p>
                        </div>

                        <div class="mt-4 bg-[#F1F5F9] rounded-lg p-3.5 text-sm text-[#475569]">
                            Clicking "Buy Now" immediately closes the auction. You will be redirected to checkout to complete payment via PayMongo.
                        </div>

                        <button type="button" @click="buyNow"
                            class="mt-4 w-full h-12 rounded-lg bg-[#DC2626] hover:bg-red-700 text-white text-sm font-semibold tracking-wide transition-colors inline-flex items-center justify-center gap-2">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg>
                            BUY NOW \u2014 {{ fmt(auction.fixedPrice) }}
                        </button>
                    </template>
                </div>
            </div>

            <button type="button" aria-label="Help"
                class="fixed bottom-5 right-5 w-11 h-11 rounded-full bg-white border border-[#DEE2E8] shadow-lg flex items-center justify-center text-[#0F2245] hover:bg-[#F8FAFC] transition-colors z-30">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 015 .4c0 1.6-2.5 2-2.5 3.6"/><circle cx="12" cy="17" r="0.6" fill="currentColor" stroke="none"/></svg>
            </button>
        </div>
    `,
};
