const DEPOSIT_STATUS_META = {
  pending: { label: "Pending 24hr Timer", bg: "#FEF3C7", text: "#B45309" },
  secured: { label: "Funds Secured", bg: "#D1FAE5", text: "#0F766E" },
  released: { label: "Released to Creator", bg: "#E2E8F0", text: "#475569" },
};

const depositTable = {
  props: {
    deposits: { type: Array, required: true },
  },
  data() {
    return {
      // If js/tabulator.min.js isn't on disk yet, Tabulator is undefined here.
      // Fall back to a plain table instead of throwing and taking the page down.
      tabulatorAvailable: typeof Tabulator !== "undefined",
      pageSize: 4,
      currentPage: 1,
    };
  },
  computed: {
    totalPages() {
      return Math.max(1, Math.ceil(this.deposits.length / this.pageSize));
    },
    pagedDeposits() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.deposits.slice(start, start + this.pageSize);
    },
    pageNumbers() {
      return Array.from({ length: this.totalPages }, (_, i) => i + 1);
    },
    rangeStart() {
      return this.deposits.length === 0
        ? 0
        : (this.currentPage - 1) * this.pageSize + 1;
    },
    rangeEnd() {
      return Math.min(this.currentPage * this.pageSize, this.deposits.length);
    },
  },
  template: `
        <div>
            <!-- Mobile: every field shown directly, no expand/collapse needed -->
            <ul class="sm:hidden divide-y divide-[#DEE2E8]">
                <li v-for="d in pagedDeposits" :key="d.id" class="p-5">
                    <div class="flex items-center gap-3">
                        <img :src="d.image" :alt="d.title" class="w-11 h-11 rounded-md object-cover shrink-0 bg-[#0B1526]">
                        <span class="font-medium text-[#0F172A] text-base truncate">{{ d.title }}</span>
                    </div>
                    <dl class="mt-3 space-y-2 text-sm">
                        <div class="flex items-center justify-between gap-3">
                            <dt class="text-[#94A3B8]">Final Price</dt>
                            <dd class="font-semibold text-[#10B981]">&#8369; {{ Number(d.finalPrice).toLocaleString('en-PH') }}</dd>
                        </div>
                        <div class="flex items-center justify-between gap-3">
                            <dt class="text-[#94A3B8]">Deposit Status</dt>
                            <dd>
                                <span class="inline-block text-xs font-semibold px-2.5 py-1 rounded-full"
                                    :style="{ background: statusMeta(d.status).bg, color: statusMeta(d.status).text }">
                                    {{ statusMeta(d.status).label }}
                                </span>
                            </dd>
                        </div>
                        <div class="flex items-center justify-between gap-3">
                            <dt class="text-[#94A3B8]">Winner</dt>
                            <dd class="text-[#0F172A] truncate">{{ d.winner }}</dd>
                        </div>
                    </dl>
                </li>
            </ul>

            <!-- Mobile pagination — mirrors the desktop table's page, driven from the same Vue state -->
            <div v-if="deposits.length" class="sm:hidden flex items-center justify-between gap-3 px-5 py-4 border-t border-[#DEE2E8] flex-wrap">
                <p class="text-sm text-[#94A3B8]">Showing {{ rangeStart }}–{{ rangeEnd }} of {{ deposits.length }}</p>
                <div v-if="totalPages > 1" class="flex items-center gap-1.5">
                    <button type="button" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
                        class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                    <button v-for="p in pageNumbers" :key="p" type="button" @click="goToPage(p)"
                        class="min-w-[32px] h-8 px-2 rounded-lg text-sm font-medium transition-colors"
                        :class="p === currentPage ? 'bg-[#0F2245] text-white' : 'border border-[#DEE2E8] text-[#64748B] hover:border-[#0F2245]'">
                        {{ p }}
                    </button>
                    <button type="button" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
                        class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                </div>
            </div>

            <!-- Desktop: Tabulator (or its fallback), all columns visible, no collapsing -->
            <div v-if="tabulatorAvailable" ref="tableEl" class="hidden sm:block"></div>

            <template v-else>
                <div class="hidden sm:block overflow-x-auto">
                    <table class="w-full text-base min-w-[640px]">
                        <thead>
                            <tr class="text-left text-xs font-semibold uppercase tracking-wider text-[#94A3B8] border-b border-[#DEE2E8]">
                                <th class="py-4 px-5 font-semibold">Artwork</th>
                                <th class="py-4 px-5 font-semibold">Winner</th>
                                <th class="py-4 px-5 font-semibold">Final Price</th>
                                <th class="py-4 px-5 font-semibold">Deposit Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="d in pagedDeposits" :key="d.id" class="border-b border-[#DEE2E8] last:border-0">
                                <td class="py-5 px-5">
                                    <div class="flex items-center gap-3">
                                        <img :src="d.image" :alt="d.title" class="w-11 h-11 rounded-md object-cover shrink-0 bg-[#0B1526]">
                                        <span class="font-medium text-[#0F172A]">{{ d.title }}</span>
                                    </div>
                                </td>
                                <td class="py-5 px-5">{{ d.winner }}</td>
                                <td class="py-5 px-5 font-semibold text-[#10B981]">&#8369; {{ Number(d.finalPrice).toLocaleString('en-PH') }}</td>
                                <td class="py-5 px-5">
                                    <span class="inline-block text-xs font-semibold px-3 py-1.5 rounded-full"
                                        :style="{ background: statusMeta(d.status).bg, color: statusMeta(d.status).text }">
                                        {{ statusMeta(d.status).label }}
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination (desktop fallback only — Tabulator renders its own when active) -->
                <div v-if="totalPages > 1" class="hidden sm:flex items-center justify-between gap-3 px-5 py-4 border-t border-[#DEE2E8]">
                    <p class="text-sm text-[#64748B]">Page {{ currentPage }} of {{ totalPages }}</p>
                    <div class="flex items-center gap-2">
                        <button type="button" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
                            class="h-9 px-3.5 rounded-lg border border-[#DEE2E8] text-sm font-medium text-[#374151] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            Prev
                        </button>
                        <button type="button" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
                            class="h-9 px-3.5 rounded-lg border border-[#DEE2E8] text-sm font-medium text-[#374151] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            Next
                        </button>
                    </div>
                </div>
            </template>
        </div>
    `,
  methods: {
    statusMeta(status) {
      return (
        DEPOSIT_STATUS_META[status] || {
          label: status,
          bg: "#E2E8F0",
          text: "#475569",
        }
      );
    },
    goToPage(p) {
      this.currentPage = Math.min(Math.max(1, p), this.totalPages);
    },
  },
  mounted() {
    if (!this.tabulatorAvailable) {
      console.warn(
        "[CanvasBid] Tabulator isn't loaded (add js/tabulator.min.js + css/tabulator.min.css) — showing a plain table for now.",
      );
      return;
    }
    // Bumps font size, padding, and row height for a more comfortable, larger
    // read than Tabulator's compact default. Injected once and scoped to
    // .canvasbid-deposit-table so multiple tables on a page don't duplicate it.
    if (!document.getElementById("canvasbid-deposit-table-style")) {
      const style = document.createElement("style");
      style.id = "canvasbid-deposit-table-style";
      style.textContent = `
        .canvasbid-deposit-table .tabulator-header .tabulator-col-content { padding: 16px 18px; }
        .canvasbid-deposit-table .tabulator-header .tabulator-col-title { font-size: 13px; letter-spacing: 0.04em; }
        .canvasbid-deposit-table .tabulator-row .tabulator-cell { font-size: 16px; padding: 20px 18px; }
        .canvasbid-deposit-table .tabulator-row { min-height: 76px; }
        .canvasbid-deposit-table .tabulator-footer { background: #fff !important; border-top: 1px solid #DEE2E8 !important; padding: 10px 14px; display: flex !important; align-items: center !important; justify-content: flex-end !important; flex-wrap: wrap; gap: 12px; }
        .canvasbid-deposit-table .tabulator-footer-contents { display: flex !important; align-items: center !important; justify-content: flex-end !important; width: 100% !important; flex-wrap: wrap; gap: 12px; }
        .canvasbid-deposit-table .tabulator-page-counter { color: #94A3B8; font-size: 0.8rem; margin-right: auto !important; order: 1; }
        .canvasbid-deposit-table .tabulator-paginator { display: flex !important; align-items: center; gap: 4px; order: 2; margin-left: 0 !important; float: none !important; }
        .canvasbid-deposit-table .tabulator-page { border-radius: 8px !important; border: 1px solid #DEE2E8 !important; background: #fff !important; color: #64748B !important; min-width: 30px; padding: 4px 8px !important; font-size: 0.8rem !important; }
        .canvasbid-deposit-table .tabulator-page.active { background: #0F2245 !important; border-color: #0F2245 !important; color: #fff !important; }
        .canvasbid-deposit-table .tabulator-page:disabled { opacity: 0.4; }
      `;
      document.head.appendChild(style);
    }
    this.$refs.tableEl.classList.add("canvasbid-deposit-table");
    this.table = new Tabulator(this.$refs.tableEl, {
      data: this.deposits,
      layout: "fitColumns",
      headerVisible: true,
      renderVertical: "basic",
      rowHeight: 76,
      pagination: true,
      paginationSize: 8,
      paginationCounter: "rows",
      columns: [
        {
          title: "Artwork",
          field: "title",
          minWidth: 220,
          headerSort: false,
          formatter: (cell) => {
            const d = cell.getRow().getData();
            return `<div style="display:flex;align-items:center;gap:12px">
                            <img src="${d.image}" alt="" style="width:44px;height:44px;border-radius:8px;object-fit:cover;background:#0B1526">
                            <span style="font-weight:500;color:#0F172A;font-size:16px">${d.title}</span>
                        </div>`;
          },
        },
        {
          title: "Winner",
          field: "winner",
          minWidth: 150,
          headerSort: false,
          formatter: (cell) =>
            `<span style="font-size:16px">${cell.getValue()}</span>`,
        },
        {
          title: "Final Price",
          field: "finalPrice",
          width: 160,
          minWidth: 130,
          headerSort: false,
          formatter: (cell) =>
            `<span style="color:#10B981;font-weight:600;font-size:16px">\u20B1 ${Number(cell.getValue()).toLocaleString("en-PH")}</span>`,
        },
        {
          title: "Deposit Status",
          field: "status",
          width: 210,
          minWidth: 170,
          headerSort: false,
          formatter: (cell) => {
            const meta = this.statusMeta(cell.getValue());
            return `<span style="display:inline-block;font-size:13px;font-weight:600;padding:6px 14px;border-radius:9999px;background:${meta.bg};color:${meta.text}">${meta.label}</span>`;
          },
        },
      ],
    });
  },
  watch: {
    deposits: {
      deep: true,
      handler(val) {
        if (this.table) this.table.setData(val);
        if (this.currentPage > this.totalPages)
          this.currentPage = this.totalPages;
      },
    },
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
};

const depositTrackerView = {
  components: { "deposit-table": depositTable },
  template: `
        <div class="min-h-screen flex flex-col">

            <!-- ============ TOP NAV ============ -->
            <header class="bg-[#0F2245] text-white sticky top-0 z-40">
                <div class="w-full px-4 sm:px-6 lg:px-8">
                    <div class="h-14 sm:h-16 flex items-center justify-between gap-4">
                        <div class="flex items-center gap-8 min-w-0">
                            <router-link to="/creator/dashboard" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

                            <nav class="hidden md:flex items-center gap-6">
                                <template v-for="item in navItems" :key="item.label">
                                    <router-link v-if="item.to" :to="item.to"
                                        class="text-sm transition-colors"
                                        :class="activeNav === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                                        {{ item.label }}
                                    </router-link>
                                    <span v-else class="text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                                </template>
                            </nav>
                        </div>

                        <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                            <button type="button" @click="$router.push('/creator/new-auction')"
                                class="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-white text-[#0F2245] text-sm font-medium hover:bg-white/90 transition-colors">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
                                New Auction
                            </button>
                            <button type="button" @click="$router.push('/creator/profile')" aria-label="View profile"
                                class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
                                {{ initials }}
                            </button>
                            <button type="button" @click="mobileMenu = !mobileMenu"
                                class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors"
                                aria-label="Toggle navigation">
                                <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                                <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                            </button>
                        </div>
                    </div>
                </div>

                <nav v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
                    <div class="px-4 py-3 space-y-1">
                        <template v-for="item in navItems" :key="item.label">
                            <router-link v-if="item.to" :to="item.to" @click="mobileMenu = false"
                                class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
                                :class="activeNav === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
                                {{ item.label }}
                            </router-link>
                            <span v-else class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                        </template>
                    </div>
                </nav>
            </header>

            <!-- ============ MAIN ============ -->
            <main class="flex-1 w-[80%] px-4 sm:px-6 lg:px-8 py-6 sm:py-10 mx-auto">

                <h1 class="font-serif text-2xl sm:text-[2rem] font-bold tracking-tight">Deposit Tracker</h1>
                <p class="mt-1 text-sm text-[#6B7280]">Monitor payment status for completed auctions.</p>

                <div class="mt-5 sm:mt-6 bg-white rounded-xl border border-[#DEE2E8] shadow-card overflow-hidden">
                    <deposit-table :deposits="deposits" @add-tracking="addTracking" />
                </div>

                <div v-if="!deposits.length" class="mt-6 bg-white rounded-xl border border-dashed border-[#DEE2E8] px-6 py-12 text-center">
                    <p class="font-medium">No completed auctions yet</p>
                    <p class="mt-1 text-sm text-[#6B7280]">Deposits will show up here once an auction closes.</p>
                </div>
            </main>
        </div>
    `,
  data() {
    return {
      activeNav: "Deposit Tracker",
      mobileMenu: false,
      user: { firstName: "Maria", lastName: "Santos" },
      navItems: [
        { label: "My Auctions", to: "/creator/dashboard" },
        { label: "Orders", to: "/creator/orders" },
        { label: "Deposit Tracker", to: "/creator/deposit-tracker" },
      ],
      deposits: [
        {
          id: 1,
          title: "Sunset in Dasma",
          winner: "Maria Santos",
          finalPrice: 5000,
          status: "pending",
          image:
            "https://images.unsplash.com/photo-1700213396527-646178b09ccf?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 2,
          title: "Blue Hour Manila",
          winner: "Nico Reyes",
          finalPrice: 3200,
          status: "secured",
          image:
            "https://images.unsplash.com/photo-1565902603597-a1fb3767bdd0?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
        {
          id: 3,
          title: "Roots & Branches",
          winner: "Chloe Tan",
          finalPrice: 8750,
          status: "released",
          image:
            "https://images.unsplash.com/photo-1632127257222-e6590216e408?auto=format&fit=crop&w=200&q=70",
        },
      ],
    };
  },
  computed: {
    initials() {
      return (this.user.firstName[0] + this.user.lastName[0]).toUpperCase();
    },
  },
  methods: {
    addTracking(deposit) {
      // Front-end only: no request sent yet.
      console.log("Add tracking # for:", deposit.title);
    },
  },
};
