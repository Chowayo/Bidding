<?php
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

require_once __DIR__ . '/../dbconn.php';
require_once __DIR__ . '/../mailer/includes/send_mail.php';

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$firstName = trim($input['firstName'] ?? '');
$lastName  = trim($input['lastName'] ?? '');
$mobile    = trim($input['mobile'] ?? '');
$email     = trim($input['email'] ?? '');
$password  = (string) ($input['password'] ?? '');
$confirm   = (string) ($input['confirmPassword'] ?? '');
$agree     = (bool) ($input['agree'] ?? false);

$errors = [];

if ($firstName === '') $errors['firstName'] = 'Enter your first name.';
if ($lastName === '')  $errors['lastName']  = 'Enter your last name.';

if ($mobile === '') {
    $errors['mobile'] = 'Enter your mobile number.';
} elseif (!preg_match('/^\+?[\d\s]{7,15}$/', $mobile)) {
    $errors['mobile'] = 'Enter a valid mobile number.';
}

if ($email === '') {
    $errors['email'] = 'Enter your email address.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Enter a valid email address.';
}

if ($password === '') {
    $errors['password'] = 'Enter a password.';
} elseif (strlen($password) < 8) {
    $errors['password'] = 'Password must be at least 8 characters.';
} else {
    $present = [];
    $missing = [];
    foreach (
        [
            'uppercase letter' => '/[A-Z]/',
            'lowercase letter' => '/[a-z]/',
            'number'           => '/[0-9]/',
            'symbol'           => '/[^A-Za-z0-9]/',
        ] as $label => $pattern
    ) {
        if (preg_match($pattern, $password)) {
            $present[] = $label;
        } else {
            $missing[] = $label;
        }
    }

    if (!in_array('uppercase letter', $present, true)) {
        $errors['password'] = 'Password must include an uppercase letter (currently has: ' . (count($present) ? implode(', ', $present) : 'none') . ').';
    } elseif (!empty($missing)) {
        $errors['password'] = 'Password is missing: ' . implode(', ', $missing) . '.';
    }
}

if ($confirm === '') {
    $errors['confirmPassword'] = 'Confirm your password.';
} elseif ($confirm !== $password) {
    $errors['confirmPassword'] = 'Passwords do not match.';
}

if (!$agree) $errors['agree'] = 'You must agree to continue.';

if (empty($errors)) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND role = 'creator' LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors['email'] = 'A creator account with this email already exists.';
    }
    $stmt->close();
}

if (empty($errors)) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE mobile = ? AND role = 'creator' LIMIT 1");
    $stmt->bind_param('s', $mobile);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors['mobile'] = 'A creator account with this mobile number already exists.';
    }
    $stmt->close();
}

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$otp        = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$otpHash    = password_hash($otp, PASSWORD_DEFAULT);
$otpExpires = date('Y-m-d H:i:s', time() + 10 * 60);

$stmt = $conn->prepare(
    "INSERT INTO users (role, first_name, last_name, mobile, email, password_hash, otp_code_hash, otp_expires_at, created_at)
     VALUES ('creator', ?, ?, ?, ?, ?, ?, ?, NOW())"
);
$stmt->bind_param('sssssss', $firstName, $lastName, $mobile, $email, $passwordHash, $otpHash, $otpExpires);
$stmt->execute();
$id = $stmt->insert_id;
$stmt->close();

send_email(
    $email,
    'Verify your CanvasBid account',
    "<p>Hi {$firstName},</p><p>Your CanvasBid verification code is:</p><h2>{$otp}</h2><p>This code expires in 10 minutes.</p>"
);

$_SESSION['pending_verification'] = [
    'user_id' => $id,
    'email'   => $email,
    'role'    => 'creator',
];

echo json_encode(['success' => true, 'id' => $id, 'redirect' => 'verify.php']);
