const creatorOrdersView = {
  template: `
        <div class="min-h-screen flex flex-col bg-[#F8FAFC]">

            <!-- ============ TOP NAV ============ -->
            <header class="bg-[#0F2245] text-white sticky top-0 z-40">
                <div class="w-full px-4 sm:px-6 lg:px-8">
                    <div class="h-14 sm:h-16 flex items-center justify-between gap-4">

                        <div class="flex items-center gap-8 min-w-0">
                            <router-link to="/creator/dashboard" class="font-serif font-bold text-lg sm:text-xl tracking-tight shrink-0">CanvasBid</router-link>

                            <nav class="hidden md:flex items-center gap-6">
                                <template v-for="item in navItems" :key="item.label">
                                    <router-link v-if="item.to" :to="item.to"
                                        class="text-sm transition-colors"
                                        :class="activeNav === item.label ? 'text-white font-medium' : 'text-white/70 hover:text-white'">
                                        {{ item.label }}
                                    </router-link>
                                    <span v-else class="text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                                </template>
                            </nav>
                        </div>

                        <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                            <button type="button" @click="$router.push('/creator/new-auction')"
                                class="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-white text-[#0F2245] text-sm font-medium hover:bg-white/90 transition-colors">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
                                New Auction
                            </button>
                            <button type="button" @click="$router.push('/creator/profile')" aria-label="View profile"
                                class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide hover:bg-white/25 transition-colors">
                                {{ initials }}
                            </button>
                            <button type="button" @click="mobileMenu = !mobileMenu"
                                class="md:hidden w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:bg-white/10 transition-colors"
                                aria-label="Toggle navigation">
                                <svg v-if="!mobileMenu" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                                <svg v-else class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                            </button>
                        </div>
                    </div>
                </div>

                <nav v-show="mobileMenu" class="md:hidden border-t border-white/10 bg-[#0F2245]">
                    <div class="px-4 py-3 space-y-1">
                        <template v-for="item in navItems" :key="item.label">
                            <router-link v-if="item.to" :to="item.to" @click="mobileMenu = false"
                                class="block px-3 py-2.5 rounded-lg text-sm transition-colors"
                                :class="activeNav === item.label ? 'bg-white/10 text-white font-medium' : 'text-white/70 hover:bg-white/5'">
                                {{ item.label }}
                            </router-link>
                            <span v-else class="block px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">{{ item.label }}</span>
                        </template>
                    </div>
                </nav>
            </header>

            <!-- ============ MAIN ============ -->
            <main class="flex-1 w-[80%] px-4 sm:px-6 lg:px-8 py-6 sm:py-10 mx-auto">

                <h1 class="font-serif text-2xl sm:text-[2rem] font-bold tracking-tight">Orders</h1>
                <p class="mt-1 text-sm text-[#6B7280]">Manage shipping and delivery for completed auctions.</p>

                <!-- Stat cards -->
                <div class="mt-5 sm:mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                    <div class="bg-white rounded-xl border border-[#DEE2E8] shadow-card px-4 sm:px-5 py-4 sm:py-5">
                        <p class="text-[11px] font-semibold tracking-[0.1em] uppercase text-[#94A3B8]">Total Orders</p>
                        <p class="mt-1.5 sm:mt-2 font-serif text-2xl sm:text-[2rem] font-bold leading-none text-[#101828]">{{ orders.length }}</p>
                    </div>
                    <div class="bg-white rounded-xl border border-[#DEE2E8] shadow-card px-4 sm:px-5 py-4 sm:py-5">
                        <p class="text-[11px] font-semibold tracking-[0.1em] uppercase text-[#94A3B8]">Pending</p>
                        <p class="mt-1.5 sm:mt-2 font-serif text-2xl sm:text-[2rem] font-bold leading-none text-amber-500">{{ pendingCount }}</p>
                    </div>
                    <div class="bg-white rounded-xl border border-[#DEE2E8] shadow-card px-4 sm:px-5 py-4 sm:py-5">
                        <p class="text-[11px] font-semibold tracking-[0.1em] uppercase text-[#94A3B8]">To Ship</p>
                        <p class="mt-1.5 sm:mt-2 font-serif text-2xl sm:text-[2rem] font-bold leading-none text-[#0F2245]">{{ toShipCount }}</p>
                    </div>
                    <div class="bg-white rounded-xl border border-[#DEE2E8] shadow-card px-4 sm:px-5 py-4 sm:py-5">
                        <p class="text-[11px] font-semibold tracking-[0.1em] uppercase text-[#94A3B8]">Delivered</p>
                        <p class="mt-1.5 sm:mt-2 font-serif text-2xl sm:text-[2rem] font-bold leading-none text-[#3E8F6B]">{{ deliveredCount }}</p>
                    </div>
                </div>

                <!-- Order list -->
                <div class="mt-5 sm:mt-6 space-y-3 sm:space-y-4">
                    <div v-for="order in pagedOrders" :key="order.id" class="bg-white rounded-xl border border-[#DEE2E8] shadow-card overflow-hidden">

                        <div class="flex flex-col sm:flex-row sm:items-center gap-4 px-5 py-4">
                            <div class="flex items-center gap-4 min-w-0">
                                <div class="w-12 h-12 rounded-lg shrink-0" :style="{ background: order.thumbGradient }"></div>

                                <div class="min-w-0">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <p class="font-medium text-[#101828] truncate">{{ order.title }}</p>
                                        <span class="text-xs font-medium px-2 py-0.5 rounded-full whitespace-nowrap" :class="statusBadgeClass(order.status)">
                                            {{ statusLabel(order.status) }}
                                        </span>
                                    </div>
                                    <p class="text-sm text-[#6B7280] mt-0.5">{{ order.buyerName }} · {{ order.buyerEmail }}</p>
                                    <p class="text-sm mt-0.5">
                                        <span class="text-[#101828] font-medium">₱{{ order.price.toLocaleString() }}</span>
                                        <span class="text-[#6B7280]"> · </span>
                                        <span :class="order.depositReceived ? 'text-[#3E8F6B]' : 'text-amber-600'">
                                            {{ order.depositReceived ? '✓ Deposit Received' : '⏳ Awaiting Deposit' }}
                                        </span>
                                    </p>
                                </div>
                            </div>

                            <div class="sm:ml-auto shrink-0 sm:text-right">
                                <button
                                    v-if="order.status === 'ready_to_ship' && !order.showTrackingInput"
                                    type="button"
                                    @click="order.showTrackingInput = true"
                                    class="w-full sm:w-auto h-9 px-4 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-sm font-medium transition-colors">
                                    Mark Shipped
                                </button>

                                <div v-else-if="order.status === 'shipped'">
                                    <p class="text-xs text-[#94A3B8]">Tracking</p>
                                    <p class="text-sm font-medium text-[#101828]">{{ order.trackingNumber }}</p>
                                </div>

                                <p v-else-if="order.status === 'awaiting_payment'" class="text-sm font-medium text-amber-600">
                                    Waiting for buyer
                                </p>
                            </div>
                        </div>

                        <!-- Only appears once "Mark Shipped" has been clicked for this order -->
                        <div v-if="order.showTrackingInput" class="border-t border-[#DEE2E8] bg-[#F8FAFC] px-5 py-4">
                            <label class="block text-xs font-medium tracking-[0.06em] uppercase text-[#6B7280] mb-1.5">
                                Tracking number
                            </label>
                            <div class="flex flex-col sm:flex-row gap-2">
                                <input
                                    type="text"
                                    v-model.trim="order.trackingNumberInput"
                                    placeholder="e.g. JRS-20240901-4821"
                                    class="field-input flex-1 h-10 px-3.5 rounded-lg border border-[#DEE2E8] bg-white text-sm placeholder:text-gray-400">
                                <div class="flex gap-2">
                                    <button type="button" @click="confirmShipped(order)" :disabled="!order.trackingNumberInput"
                                        class="flex-1 sm:flex-initial h-10 px-4 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors whitespace-nowrap">
                                        Confirm Shipped
                                    </button>
                                    <button type="button" @click="cancelShipping(order)"
                                        class="flex-1 sm:flex-initial h-10 px-4 rounded-lg border border-[#DEE2E8] hover:bg-white text-sm font-medium text-[#101828] transition-colors whitespace-nowrap">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pagination -->
                <div v-if="orders.length" class="mt-5 sm:mt-6 flex items-center justify-between gap-3 px-1 flex-wrap">
                    <p class="text-sm text-[#94A3B8]">Showing {{ rangeStart }}–{{ rangeEnd }} of {{ orders.length }}</p>
                    <div v-if="totalPages > 1" class="flex items-center gap-1.5">
                        <button type="button" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1"
                            class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                        </button>
                        <button v-for="p in pageNumbers" :key="p" type="button" @click="goToPage(p)"
                            class="min-w-[32px] h-8 px-2 rounded-lg text-sm font-medium transition-colors"
                            :class="p === currentPage ? 'bg-[#0F2245] text-white' : 'border border-[#DEE2E8] text-[#64748B] hover:border-[#0F2245]'">
                            {{ p }}
                        </button>
                        <button type="button" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages"
                            class="w-8 h-8 rounded-lg border border-[#DEE2E8] flex items-center justify-center text-[#64748B] hover:border-[#0F2245] disabled:opacity-40 disabled:hover:border-[#DEE2E8] transition-colors">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
                        </button>
                    </div>
                </div>
            </main>
        </div>
    `,
  data() {
    return {
      activeNav: "Orders",
      mobileMenu: false,
      pageSize: 5,
      currentPage: 1,
      user: {
        firstName: "Maria",
        lastName: "Santos",
      },
      navItems: [
        { label: "My Auctions", to: "/creator/dashboard" },
        { label: "Orders", to: "/creator/orders" },
        { label: "Deposit Tracker", to: "/creator/deposit-tracker" },
      ],
      // TODO: replace with a real fetch to the orders API once it exists.
      orders: [
        {
          id: 1,
          title: "Sunset in Dasma",
          thumbGradient: "linear-gradient(135deg,#7c2d12,#c2410c)",
          buyerName: "Maria Santos",
          buyerEmail: "maria@email.com",
          price: 5000,
          depositReceived: true,
          status: "ready_to_ship",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 2,
          title: "Blue Hour Manila",
          thumbGradient: "linear-gradient(135deg,#0369a1,#7c3aed)",
          buyerName: "Nico Reyes",
          buyerEmail: "nico@email.com",
          price: 3200,
          depositReceived: true,
          status: "shipped",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "JRS-20240901-4821",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
        {
          id: 3,
          title: "Roots & Branches",
          thumbGradient: "linear-gradient(135deg,#94a3b8,#e2e8f0)",
          buyerName: "Chloe Tan",
          buyerEmail: "chloe@email.com",
          price: 8750,
          depositReceived: false,
          status: "awaiting_payment",
          showTrackingInput: false,
          trackingNumberInput: "",
          trackingNumber: "",
        },
      ],
    };
  },
  computed: {
    initials() {
      return (this.user.firstName[0] + this.user.lastName[0]).toUpperCase();
    },
    totalPages() {
      return Math.max(1, Math.ceil(this.orders.length / this.pageSize));
    },
    pagedOrders() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.orders.slice(start, start + this.pageSize);
    },
    pageNumbers() {
      return Array.from({ length: this.totalPages }, (_, i) => i + 1);
    },
    rangeStart() {
      return this.orders.length === 0
        ? 0
        : (this.currentPage - 1) * this.pageSize + 1;
    },
    rangeEnd() {
      return Math.min(this.currentPage * this.pageSize, this.orders.length);
    },
    pendingCount() {
      return this.orders.filter((o) => o.status === "awaiting_payment").length;
    },
    toShipCount() {
      return this.orders.filter((o) => o.status === "ready_to_ship").length;
    },
    deliveredCount() {
      return this.orders.filter((o) => o.status === "delivered").length;
    },
  },
  methods: {
    goToPage(p) {
      this.currentPage = Math.min(Math.max(1, p), this.totalPages);
    },
    statusLabel(status) {
      return (
        {
          ready_to_ship: "Paid — Ready to Ship",
          shipped: "Shipped",
          awaiting_payment: "Awaiting Payment",
          delivered: "Delivered",
        }[status] || status
      );
    },
    statusBadgeClass(status) {
      return (
        {
          ready_to_ship: "bg-blue-50 text-blue-700",
          shipped: "bg-[#3E8F6B]/10 text-[#3E8F6B]",
          awaiting_payment: "bg-amber-50 text-amber-700",
          delivered: "bg-emerald-50 text-emerald-700",
        }[status] || "bg-gray-100 text-gray-600"
      );
    },
    cancelShipping(order) {
      order.showTrackingInput = false;
      order.trackingNumberInput = "";
    },
    confirmShipped(order) {
      if (!order.trackingNumberInput) return;
      // TODO: POST { orderId: order.id, trackingNumber } to the real backend here.
      order.trackingNumber = order.trackingNumberInput;
      order.status = "shipped";
      order.showTrackingInput = false;
    },
  },
};
