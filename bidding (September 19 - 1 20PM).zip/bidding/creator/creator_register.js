const creatorRegisterView = {
  template: `
        <div class="min-h-screen flex flex-col lg:flex-row lg:h-screen">

            <!-- Brand panel -->
            <section class="relative bg-[#0F2245] shrink-0 lg:w-1/2 lg:min-h-screen">
                <div class="flex flex-col h-full lg:justify-between px-6 py-6 sm:px-10 sm:py-8 lg:px-14 lg:py-12">

                    <div class="flex items-center gap-2.5">
                        <span class="flex items-center justify-center w-8 h-8 rounded-md bg-white/10 border border-white/15 text-white font-serif font-semibold text-sm">C</span>
                        <span class="text-white font-medium tracking-wide">CanvasBid</span>
                    </div>

                    <div class="mt-10 lg:mt-0 max-w-md">
                        <span class="inline-block px-3 py-1 rounded-full bg-amber-400 text-[#101828] text-xs font-semibold tracking-wide mb-4">
                            Creator account
                        </span>
                        <h1 class="font-serif text-white text-3xl sm:text-4xl lg:text-[2.5rem] leading-[1.1] font-bold">
                            Sell your art.<br>
                            Your rules.
                        </h1>
                        <p class="mt-4 text-white/70 text-[15px] leading-relaxed max-w-sm">
                            Run live auctions, manage bids, handle secure deposits, and ship artwork — all from one dashboard.
                        </p>

                        <ul class="hidden lg:block mt-9 space-y-5">
                            <li class="flex items-start gap-3">
                                <span class="flex items-center justify-center w-9 h-9 rounded-lg bg-white/10 shrink-0">
                                    <svg class="w-[18px] h-[18px] text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4l6 6M9 9l6 6M5 19l4-1 8-8-3-3-8 8-1 4z"/></svg>
                                </span>
                                <div>
                                    <p class="text-white text-sm font-medium">Launch auctions in minutes</p>
                                    <p class="text-white/55 text-sm mt-0.5">Upload your artwork and go live instantly</p>
                                </div>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="flex items-center justify-center w-9 h-9 rounded-lg bg-white/10 shrink-0">
                                    <svg class="w-[18px] h-[18px] text-amber-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
                                </span>
                                <div>
                                    <p class="text-white text-sm font-medium">Secure deposit payments</p>
                                    <p class="text-white/55 text-sm mt-0.5">Get paid via GCash, Maya, or card</p>
                                </div>
                            </li>
                            <li class="flex items-start gap-3">
                                <span class="flex items-center justify-center w-9 h-9 rounded-lg bg-white/10 shrink-0">
                                    <svg class="w-[18px] h-[18px] text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>
                                </span>
                                <div>
                                    <p class="text-white text-sm font-medium">Manage orders &amp; delivery</p>
                                    <p class="text-white/55 text-sm mt-0.5">Track shipments and release funds on delivery</p>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <p class="hidden lg:block text-white/35 text-xs">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>

            <!-- Form panel -->
            <section class="flex-1 flex items-start lg:items-center justify-center px-6 py-10 sm:px-10 lg:px-16">
                <div class="w-full max-w-md">

                    <div class="flex items-center gap-2 mb-3">
                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                        <span class="text-amber-600 text-xs font-semibold tracking-[0.12em] uppercase">Creator registration</span>
                    </div>
                    <h2 class="font-serif text-2xl sm:text-[1.75rem] font-bold text-[#101828]">Create your account</h2>
                    <p class="mt-1.5 text-sm text-[#6B7280]">Fill in your details to start selling your artwork.</p>

                    <p v-if="serverError" class="mt-5 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm px-3.5 py-2.5">
                        {{ serverError }}
                    </p>

                    <form class="mt-7 space-y-5" @submit.prevent="handleSubmit" novalidate>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">First name</label>
                                <input type="text" v-model.trim="form.firstName" placeholder="Maria" autocomplete="given-name"
                                    class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                    :class="errors.firstName ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <p v-if="errors.firstName" class="mt-1.5 text-xs text-red-500">{{ errors.firstName }}</p>
                            </div>
                            <div>
                                <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Last name</label>
                                <input type="text" v-model.trim="form.lastName" placeholder="Santos" autocomplete="family-name"
                                    class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                    :class="errors.lastName ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <p v-if="errors.lastName" class="mt-1.5 text-xs text-red-500">{{ errors.lastName }}</p>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Mobile number</label>
                            <input type="tel" v-model.trim="form.mobile" placeholder="+63 9XX XXX XXXX" autocomplete="tel"
                                class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                :class="errors.mobile ? 'border-red-400' : 'border-[#DEE2E8]'">
                            <p v-if="errors.mobile" class="mt-1.5 text-xs text-red-500">{{ errors.mobile }}</p>
                        </div>

                        <div>
                            <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Email address</label>
                            <input type="email" v-model.trim="form.email" placeholder="you@example.com" autocomplete="email"
                                class="field-input w-full h-11 px-3.5 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                :class="errors.email ? 'border-red-400' : 'border-[#DEE2E8]'">
                            <p v-if="errors.email" class="mt-1.5 text-xs text-red-500">{{ errors.email }}</p>
                        </div>

                        <div>
                            <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Password</label>
                            <div class="relative">
                                <input :type="showPassword ? 'text' : 'password'" v-model="form.password" placeholder="Min. 8 characters" autocomplete="new-password"
                                    class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                    :class="errors.password ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <button type="button" @click="showPassword = !showPassword"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                    :aria-label="showPassword ? 'Hide password' : 'Show password'">
                                    <svg v-if="!showPassword" class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <svg v-else class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                                </button>
                            </div>
                            <p v-if="errors.password" class="mt-1.5 text-xs text-red-500">{{ errors.password }}</p>
                            <p v-else class="mt-1.5 text-xs text-[#6B7280]">8+ characters, must include an uppercase letter, a lowercase letter, a number, and a symbol.</p>
                        </div>

                        <div>
                            <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#6B7280] mb-1.5">Confirm password</label>
                            <div class="relative">
                                <input :type="showConfirmPassword ? 'text' : 'password'" v-model="form.confirmPassword" placeholder="Repeat password" autocomplete="new-password"
                                    class="field-input w-full h-11 pl-3.5 pr-11 rounded-lg border bg-white text-[15px] placeholder:text-gray-400"
                                    :class="errors.confirmPassword ? 'border-red-400' : 'border-[#DEE2E8]'">
                                <button type="button" @click="showConfirmPassword = !showConfirmPassword"
                                    class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#6B7280]"
                                    :aria-label="showConfirmPassword ? 'Hide password' : 'Show password'">
                                    <svg v-if="!showConfirmPassword" class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <svg v-else class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                                </button>
                            </div>
                            <p v-if="errors.confirmPassword" class="mt-1.5 text-xs text-red-500">{{ errors.confirmPassword }}</p>
                        </div>

                        <div>
                            <label class="flex items-start gap-2 text-sm text-[#101828] select-none">
                                <input type="checkbox" v-model="form.agree" class="mt-0.5 w-4 h-4 rounded border-[#DEE2E8] text-[#0F2245] focus:ring-[#0F2245]/30">
                                <span>
                                    I agree to the
                                    <a href="#" class="text-[#0F2245] font-medium hover:underline">Terms of Service</a>
                                    and
                                    <a href="#" class="text-[#0F2245] font-medium hover:underline">Privacy Policy</a>
                                </span>
                            </label>
                            <p v-if="errors.agree" class="mt-1.5 text-xs text-red-500">{{ errors.agree }}</p>
                        </div>

                        <button type="submit" :disabled="submitting"
                            class="w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] disabled:opacity-70 text-white text-[15px] font-medium transition-colors flex items-center justify-center gap-2">
                            <svg v-if="submitting" class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                            </svg>
                            {{ submitting ? 'Creating account…' : 'Create Account' }}
                        </button>
                    </form>

                    <p class="mt-6 text-center text-sm text-[#6B7280]">
                        Already have an account?
                        <router-link to="/" class="text-[#0F2245] font-medium hover:underline">Sign in</router-link>
                    </p>

                    <p class="lg:hidden mt-10 text-center text-xs text-[#6B7280]">© 2026 CanvasBid. All rights reserved.</p>
                </div>
            </section>
        </div>

        <div v-if="submitting" class="fixed inset-0 z-50 bg-black/40 flex items-center justify-center px-4">
            <div class="bg-white rounded-2xl shadow-lg px-8 py-8 flex flex-col items-center gap-2 max-w-xs w-full">
                <loading-spinner message="Creating your account…" />
            </div>
        </div>
    `,
  data() {
    return {
      form: {
        firstName: "",
        lastName: "",
        mobile: "",
        email: "",
        password: "",
        confirmPassword: "",
        agree: false,
      },
      showPassword: false,
      showConfirmPassword: false,
      submitting: false,
      errors: {},
      serverError: "",
    };
  },
  methods: {
    validate() {
      const errors = {};
      if (!this.form.firstName) errors.firstName = "Enter your first name.";
      if (!this.form.lastName) errors.lastName = "Enter your last name.";

      if (!this.form.mobile) {
        errors.mobile = "Enter your mobile number.";
      } else if (!/^\+?[\d\s]{7,15}$/.test(this.form.mobile)) {
        errors.mobile = "Enter a valid mobile number.";
      }

      if (!this.form.email) {
        errors.email = "Enter your email address.";
      } else if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
        errors.email = "Enter a valid email address.";
      }

      if (!this.form.password) {
        errors.password = "Enter a password.";
      } else if (this.form.password.length < 8) {
        errors.password = "Password must be at least 8 characters.";
      } else {
        const pwd = this.form.password;
        const checks = {
          "uppercase letter": /[A-Z]/.test(pwd),
          "lowercase letter": /[a-z]/.test(pwd),
          number: /[0-9]/.test(pwd),
          symbol: /[^A-Za-z0-9]/.test(pwd),
        };
        const present = Object.keys(checks).filter((k) => checks[k]);
        const missing = Object.keys(checks).filter((k) => !checks[k]);
        if (!checks["uppercase letter"]) {
          errors.password = `Password must include an uppercase letter (currently has: ${present.length ? present.join(", ") : "none"}).`;
        } else if (missing.length > 0) {
          errors.password = `Password is missing: ${missing.join(", ")}.`;
        }
      }

      if (!this.form.confirmPassword) {
        errors.confirmPassword = "Confirm your password.";
      } else if (this.form.confirmPassword !== this.form.password) {
        errors.confirmPassword = "Passwords do not match.";
      }

      if (!this.form.agree) errors.agree = "You must agree to continue.";

      this.errors = errors;
      return Object.keys(errors).length === 0;
    },
    async handleSubmit() {
      if (!this.validate() || this.submitting) return;
      this.submitting = true;
      this.serverError = "";

      try {
        const res = await fetch("creator/register_api.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(this.form),
        });
        const data = await res.json();

        if (data.success) {
          window.location.href = data.redirect || "index.php";
        } else if (data.errors) {
          this.errors = data.errors;
        } else {
          this.serverError =
            data.message || "Something went wrong. Please try again.";
        }
      } catch (e) {
        this.serverError = "Network error. Please try again.";
      } finally {
        this.submitting = false;
      }
    },
  },
};
