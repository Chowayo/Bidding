// Front-end only: everything here operates on the mock array below. Swap
// AUCTION_QUEUE_DATA for a fetch() to the real endpoint once it exists, and
// point approveAuction()/rejectAuction() at the real API calls (they already
// isolate that logic to one spot each).

// Reuses the shared nav model declared in admin_dashboard.js (loaded first —
// see index.php's <head>), so every admin page stays in sync on one array.
const BID_TYPE_STYLES = {
  English: { badge: "bg-blue-50 text-blue-600", dot: "#1A56DB" },
  Dutch: { badge: "bg-amber-50 text-amber-600", dot: "#F59E0B" },
  Blind: { badge: "bg-purple-50 text-purple-600", dot: "#7C3AED" },
  Proxy: { badge: "bg-emerald-50 text-emerald-600", dot: "#10B981" },
  "Buy Now": { badge: "bg-red-50 text-red-600", dot: "#EF4444" },
};

// Deterministic placeholder "artwork" swatch (no image assets needed for the
// mock) — real data will carry an actual image_url to drop into an <img>.
function thumbGradient(id) {
  const hue = (id * 47) % 360;
  return `linear-gradient(135deg, hsl(${hue} 65% 55%), hsl(${(hue + 40) % 360} 70% 40%))`;
}

const AUCTION_QUEUE_DATA = [
  {
    id: 1,
    title: "Sunset in Dasma",
    bidType: "English",
    creatorName: "Lena Buenaventura",
    creatorEmail: "lena@gmail.com",
    startingPrice: 500,
    submitted: "2026-09-17T09:12:00",
    description:
      "An oil on canvas piece capturing the golden hour over the Dasmariñas landscape. 18×24 inches, framed.",
    timeFrame: "24 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "7 days",
  },
  {
    id: 2,
    title: "Blue Hour Manila",
    bidType: "Dutch",
    creatorName: "Marco Villanueva",
    creatorEmail: "marco@gmail.com",
    startingPrice: 8000,
    submitted: "2026-09-17T11:45:00",
    description:
      "A moody acrylic study of Roxas Boulevard just after sunset, layered with palette-knife texture. 24×36 inches.",
    timeFrame: "12 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "10 days",
  },
  {
    id: 3,
    title: "Roots & Branches",
    bidType: "Blind",
    creatorName: "Aisha Dela Torre",
    creatorEmail: "aisha@gmail.com",
    startingPrice: 1200,
    submitted: "2026-09-17T14:03:00",
    description:
      "Mixed-media piece on reclaimed wood exploring ancestry and migration through interwoven root motifs.",
    timeFrame: "48 hrs",
    paymentPeriod: "72 hrs",
    startPeriod: "Sep 20, 2026",
    delivery: "14 days",
  },
  {
    id: 4,
    title: "Morning Mist Bataan",
    bidType: "Proxy",
    creatorName: "Paolo Reyes",
    creatorEmail: "paolo@gmail.com",
    startingPrice: 750,
    submitted: "2026-09-17T15:30:00",
    description:
      "Watercolor landscape of the Bataan mountain range at first light, painted en plein air.",
    timeFrame: "24 hrs",
    paymentPeriod: "24 hrs",
    startPeriod: "Immediately",
    delivery: "5 days",
  },
  {
    id: 5,
    title: "Halo-Halo Series #3",
    bidType: "Buy Now",
    creatorName: "Chloe Tan",
    creatorEmail: "chloe@gmail.com",
    startingPrice: 3500,
    submitted: "2026-09-17T16:55:00",
    description:
      "Bright pop-art still life from Chloe's ongoing Filipino-dessert series, gouache on illustration board.",
    timeFrame: "—",
    paymentPeriod: "24 hrs",
    startPeriod: "Immediately",
    delivery: "3 days",
  },
  {
    id: 6,
    title: "Baybayin Study No. 2",
    bidType: "English",
    creatorName: "Renz Katigbak",
    creatorEmail: "renz@gmail.com",
    startingPrice: 900,
    submitted: "2026-09-16T10:20:00",
    description:
      "Ink and gold leaf composition weaving baybayin script into a modern abstract frame.",
    timeFrame: "24 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "7 days",
  },
  {
    id: 7,
    title: "Jeepney Rush Hour",
    bidType: "Dutch",
    creatorName: "Bea Fernandez",
    creatorEmail: "bea@gmail.com",
    startingPrice: 2200,
    submitted: "2026-09-16T13:47:00",
    description:
      "Vibrant street-scene oil painting of EDSA traffic at 6pm, thick impasto strokes throughout.",
    timeFrame: "12 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Sep 19, 2026",
    delivery: "10 days",
  },
  {
    id: 8,
    title: "Ifugao Terraces",
    bidType: "English",
    creatorName: "Noel Bautista",
    creatorEmail: "noel@gmail.com",
    startingPrice: 1600,
    submitted: "2026-09-16T17:05:00",
    description:
      "Panoramic acrylic rendering of the Banaue rice terraces at harvest season, 20×40 inches.",
    timeFrame: "36 hrs",
    paymentPeriod: "72 hrs",
    startPeriod: "Immediately",
    delivery: "14 days",
  },
  {
    id: 9,
    title: "Manila Bay at Dusk",
    bidType: "Blind",
    creatorName: "Sofia Ramos",
    creatorEmail: "sofia@gmail.com",
    startingPrice: 4000,
    submitted: "2026-09-15T09:58:00",
    description:
      "A minimalist study of the bay's famous sunset silhouettes, oil on linen.",
    timeFrame: "48 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "10 days",
  },
  {
    id: 10,
    title: "Sampaguita Vendor",
    bidType: "Proxy",
    creatorName: "Iris Manalo",
    creatorEmail: "iris@gmail.com",
    startingPrice: 650,
    submitted: "2026-09-15T12:31:00",
    description:
      "Portrait study of a sampaguita garland vendor near Quiapo church, charcoal and pastel.",
    timeFrame: "24 hrs",
    paymentPeriod: "24 hrs",
    startPeriod: "Immediately",
    delivery: "5 days",
  },
  {
    id: 11,
    title: "Barangay Fiesta",
    bidType: "English",
    creatorName: "Enzo Lim",
    creatorEmail: "enzo@gmail.com",
    startingPrice: 1800,
    submitted: "2026-09-15T16:12:00",
    description:
      "Festival scene bursting with colour — banderitas, lechon, and a brass band — acrylic on canvas.",
    timeFrame: "24 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Sep 21, 2026",
    delivery: "7 days",
  },
  {
    id: 12,
    title: "Kubo sa Bukid",
    bidType: "Buy Now",
    creatorName: "Grace Espino",
    creatorEmail: "grace@gmail.com",
    startingPrice: 2900,
    submitted: "2026-09-14T08:40:00",
    description:
      "A quiet countryside nipa hut scene at golden hour, oil on canvas board.",
    timeFrame: "—",
    paymentPeriod: "24 hrs",
    startPeriod: "Immediately",
    delivery: "5 days",
  },
  {
    id: 13,
    title: "Adobo Sunday",
    bidType: "Dutch",
    creatorName: "Miguel Cruz",
    creatorEmail: "miguel@gmail.com",
    startingPrice: 1100,
    submitted: "2026-09-14T15:22:00",
    description:
      "Warm domestic still life of a family adobo lunch, part of Miguel's 'Sunday Table' series.",
    timeFrame: "12 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "7 days",
  },
  {
    id: 14,
    title: "Tinikling",
    bidType: "English",
    creatorName: "Patricia Uy",
    creatorEmail: "patricia@gmail.com",
    startingPrice: 3200,
    submitted: "2026-09-14T18:09:00",
    description:
      "Dynamic figure study of tinikling dancers mid-motion, ink wash and gouache.",
    timeFrame: "24 hrs",
    paymentPeriod: "48 hrs",
    startPeriod: "Immediately",
    delivery: "10 days",
  },
];

const adminAuctionQueueView = {
  template: `
        <div class="min-h-screen flex bg-[#F8FAFC]">

            <!-- ============ MOBILE SIDEBAR BACKDROP ============ -->
            <div v-if="sidebarOpen" @click="sidebarOpen = false"
                class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>

            <!-- ============ SIDEBAR ============ -->
            <aside
                class="fixed inset-y-0 left-0 z-50 w-72 bg-[#0F2245] text-white flex flex-col transition-transform duration-200 ease-out lg:static lg:translate-x-0 lg:w-64 lg:shrink-0"
                :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

                <div class="h-16 flex items-center justify-between gap-2 px-5 shrink-0 border-b border-white/10">
                    <div class="flex items-center gap-2 min-w-0">
                        <span class="font-serif font-bold text-lg tracking-tight truncate">CanvasBid</span>
                        <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5 shrink-0">Admin</span>
                    </div>
                    <button type="button" @click="sidebarOpen = false" aria-label="Close menu"
                        class="lg:hidden w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/10 transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
                    <template v-for="item in navItems" :key="item.label">
                        <router-link v-if="item.to" :to="item.to" @click="sidebarOpen = false"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
                            :class="isActive(item) ? 'bg-white/15 text-white font-medium' : 'text-white/70 hover:bg-white/5 hover:text-white'">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </router-link>
                        <span v-else
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/30 cursor-not-allowed">
                            <svg class="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" v-html="item.icon"></svg>
                            <span class="truncate">{{ item.label }}</span>
                        </span>
                    </template>
                </nav>

                <div class="shrink-0 border-t border-white/10 px-4 py-4 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-full bg-white/15 border border-white/20 flex items-center justify-center text-xs font-semibold tracking-wide shrink-0">
                        {{ adminInitials }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium truncate">{{ admin.name }}</p>
                        <p class="text-xs text-white/50 truncate">{{ admin.email }}</p>
                    </div>
                    <button type="button" aria-label="Log out"
                        class="w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors shrink-0">
                        <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                    </button>
                </div>
            </aside>

            <!-- ============ MAIN ============ -->
            <div class="flex-1 min-w-0 flex flex-col">

                <header class="h-16 shrink-0 bg-white border-b border-[#DEE2E8] flex items-center justify-between gap-4 px-4 sm:px-6 sticky top-0 z-30">
                    <div class="flex items-center gap-3 min-w-0">
                        <button type="button" @click="sidebarOpen = true" aria-label="Open menu"
                            class="lg:hidden w-9 h-9 -ml-1.5 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                        </button>
                        <p class="text-sm text-[#64748B] truncate">
                            <span>Admin</span>
                            <span class="mx-1.5 text-[#94A3B8]">/</span>
                            <span class="text-[#0F172A] font-medium">Auction Queue</span>
                        </p>
                    </div>

                    <button type="button" aria-label="Notifications"
                        class="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#374151] hover:bg-[#F8FAFC] transition-colors shrink-0">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
                        <span v-if="hasNotifications" class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F59E0B]"></span>
                    </button>
                </header>

                <main class="flex-1 px-4 sm:px-6 py-6 sm:py-8">

                    <!-- ============ PAGE HEADER ============ -->
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div class="min-w-0">
                            <h1 class="text-lg sm:text-xl font-semibold text-[#0F172A]">New Auction Queue</h1>
                            <p class="mt-0.5 text-sm text-[#64748B]">Auctions submitted by creators awaiting admin approval before going live</p>
                        </div>

                        <div class="flex items-center gap-2.5 shrink-0">
                            <div class="relative flex-1 sm:flex-none">
                                <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
                                <input v-model="searchQuery" type="text" placeholder="Search auctions..."
                                    class="w-full sm:w-56 h-10 pl-9 pr-3 rounded-lg border border-[#DEE2E8] bg-[#F8FAFC] text-sm placeholder:text-[#94A3B8] focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15 focus:bg-white transition-colors">
                            </div>
                            <span class="shrink-0 whitespace-nowrap inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide bg-amber-50 text-[#F59E0B] rounded-full px-3 py-2">
                                <span class="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></span>
                                {{ pendingCount }} Pending
                            </span>
                        </div>
                    </div>

                    <!-- ============ TABLE CARD ============ -->
                    <div class="mt-4 bg-white rounded-xl border border-[#DEE2E8] overflow-hidden">
                        <div v-if="tableError" class="p-6 text-sm text-red-600 bg-red-50">
                            <p class="font-medium">The auction table failed to load.</p>
                            <p class="mt-1 text-red-500">{{ tableError }}</p>
                            <p class="mt-1 text-red-500">Open the browser console for the full error, and confirm <code>js/tabulator.min.js</code> and <code>css/tabulator.min.css</code> are both being loaded (check the Network tab for a 404).</p>
                        </div>
                        <div v-show="!tableError" ref="tableEl"></div>
                        <div v-if="!tableError && auctions.length === 0" class="py-16 text-center">
                            <svg class="w-10 h-10 mx-auto text-[#94A3B8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                            <p class="mt-3 text-sm font-medium text-[#0F172A]">Queue is all caught up</p>
                            <p class="text-sm text-[#64748B]">No auctions are waiting on review right now.</p>
                        </div>
                    </div>

                </main>
            </div>

            <!-- ============ SUBMISSION MODAL ============ -->
            <div v-if="selected" class="fixed inset-0 z-[60] flex items-center justify-center p-4"
                @click.self="closeModal">
                <div class="absolute inset-0 bg-black/50"></div>

                <div class="relative bg-white w-full max-w-md rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">

                    <div class="sticky top-0 bg-white flex items-center justify-between px-5 py-4 border-b border-[#DEE2E8] rounded-t-2xl">
                        <h2 class="text-base font-semibold text-[#0F172A]">Auction Submission</h2>
                        <button type="button" @click="closeModal" aria-label="Close"
                            class="w-8 h-8 rounded-lg flex items-center justify-center text-[#64748B] hover:bg-[#F8FAFC] transition-colors">
                            <svg class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>

                    <div class="aspect-square w-full" :style="{ background: thumb(selected.id) }"></div>

                    <div class="p-5">
                        <div class="flex items-center gap-2 flex-wrap">
                            <h3 class="text-lg font-semibold text-[#0F172A]">{{ selected.title }}</h3>
                            <span class="text-xs font-semibold uppercase tracking-wide rounded-full px-2 py-0.5"
                                :class="bidTypeStyle(selected.bidType).badge">{{ selected.bidType }}</span>
                            <span class="text-xs font-semibold uppercase tracking-wide rounded-full px-2 py-0.5 bg-amber-50 text-[#F59E0B]">Pending Review</span>
                        </div>
                        <p class="mt-1 text-sm text-[#64748B]">by {{ selected.creatorName }} · {{ selected.creatorEmail }}</p>

                        <p class="mt-4 text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Description</p>
                        <p class="mt-1.5 text-sm text-[#0F172A] leading-relaxed">{{ selected.description }}</p>

                        <div class="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 bg-[#F8FAFC] rounded-lg p-4">
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Starting Price</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ formatPrice(selected.startingPrice) }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Bid Type</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.bidType }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Time Frame</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.timeFrame }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Payment Period</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.paymentPeriod }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Start Period</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.startPeriod }}</p>
                            </div>
                            <div>
                                <p class="text-xs font-semibold uppercase tracking-wider text-[#94A3B8]">Delivery</p>
                                <p class="mt-0.5 text-sm font-medium text-[#0F172A]">{{ selected.delivery }}</p>
                            </div>
                        </div>

                        <p class="mt-4 text-xs text-[#94A3B8]">Submitted {{ formatDateTime(selected.submitted) }}</p>

                        <div class="mt-5 flex flex-col sm:flex-row gap-3">
                            <button type="button" @click="approveAuction(selected)"
                                class="flex-1 h-11 rounded-lg bg-[#10B981] hover:bg-emerald-600 text-white text-sm font-medium transition-colors flex items-center justify-center gap-1.5">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                                Approve & Post
                            </button>
                            <button type="button" @click="rejectAuction(selected)"
                                class="flex-1 h-11 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-sm font-medium transition-colors flex items-center justify-center gap-1.5">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                                Reject
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
  data() {
    return {
      sidebarOpen: false,
      hasNotifications: true,
      admin: { name: "Super Admin", email: "admin@canvasbid.ph" },
      navItems: typeof ADMIN_NAV_ITEMS !== "undefined" ? ADMIN_NAV_ITEMS : [],
      auctions: AUCTION_QUEUE_DATA.slice(),
      searchQuery: "",
      selected: null,
      table: null,
      tableError: "",
    };
  },
  computed: {
    adminInitials() {
      return this.admin.name
        .split(" ")
        .map((w) => w[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
    },
    pendingCount() {
      return this.auctions.length;
    },
  },
  watch: {
    searchQuery(value) {
      if (!this.table) return;
      const q = value.trim().toLowerCase();
      if (!q) {
        this.table.clearFilter();
        return;
      }
      this.table.setFilter((data) =>
        [data.title, data.creatorName, data.creatorEmail, data.bidType]
          .join(" ")
          .toLowerCase()
          .includes(q),
      );
    },
  },
  mounted() {
    this.injectTableStyles();
    // Deferred + try/caught on purpose: a thrown error straight out of
    // mounted() can jam Vue's reactivity scheduler for the whole app (other
    // router-links stop responding), so a Tabulator/DOM problem here must
    // never escape uncaught.
    this.$nextTick(() => this.initTable());
  },
  beforeUnmount() {
    if (this.table) this.table.destroy();
  },
  methods: {
    isActive(item) {
      return item.to === this.$route.path;
    },
    thumb(id) {
      return thumbGradient(id);
    },
    bidTypeStyle(type) {
      return (
        BID_TYPE_STYLES[type] || {
          badge: "bg-slate-100 text-[#64748B]",
          dot: "#94A3B8",
        }
      );
    },
    formatPrice(value) {
      return "\u20B1" + Number(value).toLocaleString("en-PH");
    },
    formatDate(iso) {
      const d = new Date(iso);
      return d.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      });
    },
    formatDateTime(iso) {
      const d = new Date(iso);
      return (
        d.toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
        }) +
        " \u00B7 " +
        d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
      );
    },
    openAuction(data) {
      this.selected = data;
    },
    closeModal() {
      this.selected = null;
    },
    async approveAuction(auction) {
      const result = await Swal.fire({
        icon: "question",
        title: "Approve this auction?",
        html: `<span style="color:#64748B">"${auction.title}" will go live immediately for bidders to see.</span>`,
        showCancelButton: true,
        confirmButtonText: "Approve & Post",
        cancelButtonText: "Cancel",
        confirmButtonColor: "#10B981",
        cancelButtonColor: "#E2E8F0",
        reverseButtons: true,
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
      if (!result.isConfirmed) return;

      this.removeFromQueue(auction.id);
      this.closeModal();
      Swal.fire({
        icon: "success",
        title: "Auction approved",
        text: `"${auction.title}" is now live.`,
        timer: 1600,
        showConfirmButton: false,
        iconColor: "#10B981",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
    },
    async rejectAuction(auction) {
      const result = await Swal.fire({
        icon: "warning",
        title: "Reject this submission?",
        html: `<span style="color:#64748B">"${auction.title}" will be sent back to ${auction.creatorName} and removed from the queue.</span>`,
        showCancelButton: true,
        confirmButtonText: "Reject",
        cancelButtonText: "Cancel",
        confirmButtonColor: "#EF4444",
        cancelButtonColor: "#E2E8F0",
        reverseButtons: true,
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
      if (!result.isConfirmed) return;

      this.removeFromQueue(auction.id);
      this.closeModal();
      Swal.fire({
        icon: "success",
        title: "Submission rejected",
        text: `"${auction.title}" was removed from the queue.`,
        timer: 1600,
        showConfirmButton: false,
        iconColor: "#EF4444",
        customClass: {
          popup: "canvasbid-swal-popup",
          title: "canvasbid-swal-title",
        },
      });
    },
    removeFromQueue(id) {
      this.auctions = this.auctions.filter((a) => a.id !== id);
      if (this.table) this.table.deleteRow(id);
    },
    initTable() {
      const self = this;

      if (typeof Tabulator === "undefined") {
        this.tableError =
          "Tabulator library not found (window.Tabulator is undefined).";
        console.error(
          '[auction_queue] Tabulator is undefined — check that <script src="js/tabulator.min.js"> loads before router.js and returns 200, not 404.',
        );
        return;
      }
      if (!this.$refs.tableEl) return;

      try {
        this.table = new Tabulator(this.$refs.tableEl, {
          data: this.auctions,
          index: "id",
          layout: "fitColumns",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: false,
          placeholder: "No auctions found",
          headerSort: true,
          paginationCounter: "rows",
          columns: [
            {
              title: "Auction",
              field: "title",
              minWidth: 220,
              formatter(cell) {
                const d = cell.getRow().getData();
                return `
                <div class="cb-auction-cell">
                    <span class="cb-thumb" style="background:${thumbGradient(d.id)}"></span>
                    <span class="cb-auction-title">${d.title}</span>
                </div>`;
              },
            },
            {
              title: "Creator",
              field: "creatorName",
              minWidth: 190,
              formatter(cell) {
                const d = cell.getRow().getData();
                return `
                <div class="cb-creator-cell">
                    <span class="cb-creator-name">${d.creatorName}</span>
                    <span class="cb-creator-email">${d.creatorEmail}</span>
                </div>`;
              },
            },
            {
              title: "Bid Type",
              field: "bidType",
              minWidth: 130,
              formatter(cell) {
                const type = cell.getValue();
                const style = self.bidTypeStyle(type);
                return `<span class="cb-badge ${style.badge}">${type}</span>`;
              },
            },
            {
              title: "Starting Price",
              field: "startingPrice",
              minWidth: 160,
              formatter(cell) {
                return self.formatPrice(cell.getValue());
              },
            },
            {
              title: "Submitted",
              field: "submitted",
              minWidth: 150,
              formatter(cell) {
                return self.formatDateTime(cell.getValue());
              },
            },
            {
              title: "Actions",
              field: "id",
              minWidth: 110,
              hozAlign: "right",
              headerSort: false,
              formatter() {
                return `<button type="button" class="cb-view-btn" data-view>View</button>`;
              },
              cellClick(e, cell) {
                if (e.target.closest("[data-view]")) {
                  self.openAuction(cell.getRow().getData());
                }
              },
            },
          ],
        });
      } catch (err) {
        this.tableError = err && err.message ? err.message : String(err);
        console.error("[auction_queue] Tabulator failed to initialize:", err);
      }
    },
    injectTableStyles() {
      if (document.getElementById("cb-tabulator-theme")) return;
      const style = document.createElement("style");
      style.id = "cb-tabulator-theme";
      style.textContent = `
        .tabulator { border: none; background: transparent; font-family: inherit; font-size: 0.875rem; }
        .tabulator-header { background: #F8FAFC; border-bottom: 1px solid #DEE2E8; }
        .tabulator-headers { display: flex; }
        .tabulator-col { background: #F8FAFC !important; border-right: none !important; float: none !important; }
        .tabulator-col-title { color: #94A3B8; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; white-space: nowrap; }
        .tabulator-col-sorter { color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col-sorter .tabulator-arrow { border-bottom-color: #CBD5E1 !important; opacity: 0.9; }
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter,
        .tabulator-col.tabulator-sortable:hover .tabulator-col-sorter .tabulator-arrow { color: #94A3B8 !important; border-bottom-color: #94A3B8 !important; }
        .tabulator-row { border-bottom: 1px solid #DEE2E8; background: #fff !important; display: flex !important; align-items: stretch; float: none !important; }
        .tabulator-row:hover { background: #F8FAFC !important; }
        .tabulator-row .tabulator-cell { display: flex; align-items: center; padding: 10px 14px; color: #0F172A; box-sizing: border-box; overflow: hidden; float: none !important; }
        .tabulator-tableholder { overflow: auto; }
        .tabulator-table { display: block; width: 100%; }
        .cb-auction-cell { display: flex; align-items: center; gap: 10px; min-width: 0; }
        .cb-thumb { width: 36px; height: 36px; border-radius: 8px; flex-shrink: 0; }
        .cb-auction-title { font-weight: 500; color: #0F172A; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cb-creator-cell { display: flex; flex-direction: column; min-width: 0; }
        .cb-creator-name { color: #0F172A; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cb-creator-email { color: #94A3B8; font-size: 0.75rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .cb-badge { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; border-radius: 999px; padding: 2px 10px; }
        .cb-view-btn { height: 32px; padding: 0 14px; border-radius: 8px; border: 1px solid #DEE2E8; background: #fff; color: #0F172A; font-size: 0.8rem; font-weight: 500; cursor: pointer; transition: border-color .15s, color .15s; }
        .cb-view-btn:hover { border-color: #1A56DB; color: #1A56DB; }
        .tabulator .tabulator-footer { background: #fff !important; border-top: 1px solid #DEE2E8 !important; padding: 10px 14px; display: flex !important; align-items: center !important; justify-content: flex-end !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-footer-contents { display: flex !important; align-items: center !important; justify-content: flex-end !important; width: 100% !important; flex-wrap: wrap; gap: 12px; }
        .tabulator .tabulator-page-counter { color: #94A3B8; font-size: 0.8rem; margin-right: auto !important; order: 1; }
        .tabulator .tabulator-paginator { display: flex !important; align-items: center; gap: 4px; order: 2; margin-left: 0 !important; float: none !important; }
        .tabulator .tabulator-page { border-radius: 8px !important; border: 1px solid #DEE2E8 !important; background: #fff !important; color: #64748B !important; min-width: 30px; padding: 4px 8px !important; font-size: 0.8rem !important; }
        .tabulator .tabulator-page.active { background: #1A56DB !important; border-color: #1A56DB !important; color: #fff !important; }
        .tabulator .tabulator-page:disabled { opacity: 0.4; }
        @media (max-width: 640px) {
          .tabulator .tabulator-footer { display: flex; flex-wrap: wrap; gap: 8px; }
        }
      `;
      document.head.appendChild(style);
    },
  },
};
