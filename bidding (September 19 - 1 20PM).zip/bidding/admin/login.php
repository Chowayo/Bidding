<?php
session_start();
require_once __DIR__ . '/../dbconn.php';

// Kept deliberately separate from index.php's bidder/creator login: this way
// rate limiting, lockouts, and (later) 2FA can be added here later without
// touching or slowing down the public-facing form.

$error      = '';
$emailValue = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email      = trim($_POST['email'] ?? '');
    $password   = (string) ($_POST['password'] ?? '');
    $emailValue = $email;

    if ($email === '' || $password === '') {
        $error = 'Enter both email and password.';
    } else {
        $adminRole = 'admin';
        $stmt = $conn->prepare(
            'SELECT id, first_name, email, password_hash, is_verified FROM users WHERE email = ? AND role = ? LIMIT 1'
        );
        $stmt->bind_param('ss', $email, $adminRole);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$admin || !password_verify($password, $admin['password_hash'])) {
            // Same message either way — don't reveal whether the email exists.
            $error = 'Incorrect email or password.';
        } elseif ((int) $admin['is_verified'] === 0) {
            $error = 'This admin account is not verified yet. Contact another administrator.';
        } else {
            $_SESSION['user_id']    = $admin['id'];
            $_SESSION['user_role']  = 'admin';
            $_SESSION['user_email'] = $admin['email'];

            header('Location: ../index.php#/admin/dashboard');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign In · CanvasBid</title>
    <script src="../js/tailwind.js"></script>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
    </style>
</head>

<body class="min-h-screen bg-[#0F2245] flex items-center justify-center px-4 py-10">

    <div class="w-full max-w-sm">
        <div class="flex items-center justify-center gap-2 mb-6">
            <span class="flex items-center justify-center w-8 h-8 rounded-md bg-white/10 border border-white/15 text-white font-serif font-semibold text-sm">C</span>
            <span class="text-white font-medium tracking-wide">CanvasBid</span>
            <span class="text-[10px] font-semibold uppercase tracking-wider bg-[#10B981] text-white rounded-full px-2 py-0.5">Admin</span>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-7 sm:p-8">
            <h1 class="text-xl font-semibold text-[#0F172A]">Admin Sign In</h1>
            <p class="mt-1 text-sm text-[#64748B]">Restricted access. Authorized administrators only.</p>

            <?php if ($error): ?>
                <p class="mt-5 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm px-3.5 py-2.5"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>

            <form class="mt-6 space-y-5" method="POST" novalidate>
                <div>
                    <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#64748B] mb-1.5">Email address</label>
                    <input type="email" name="email" required value="<?= htmlspecialchars($emailValue) ?>"
                        placeholder="admin@canvasbid.ph" autocomplete="username"
                        class="w-full h-11 px-3.5 rounded-lg border border-[#DEE2E8] bg-white text-[15px] placeholder:text-gray-400 focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15">
                </div>

                <div>
                    <label class="block text-xs font-medium tracking-[0.08em] uppercase text-[#64748B] mb-1.5">Password</label>
                    <div class="relative">
                        <input id="password" type="password" name="password" required
                            placeholder="••••••••" autocomplete="current-password"
                            class="w-full h-11 pl-3.5 pr-11 rounded-lg border border-[#DEE2E8] bg-white text-[15px] placeholder:text-gray-400 focus:outline-none focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/15">
                        <button type="button" onclick="togglePassword()"
                            class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-[#64748B]"
                            aria-label="Show or hide password">
                            <svg id="eye-open" class="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
                                <circle cx="12" cy="12" r="3" />
                            </svg>
                            <svg id="eye-closed" class="hidden w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.3 20.3 0 0 1-2.68 3.64M14.12 14.12a3 3 0 1 1-4.24-4.24" />
                                <line x1="1" y1="1" x2="23" y2="23" />
                            </svg>
                        </button>
                    </div>
                </div>

                <button type="submit"
                    class="w-full h-12 rounded-lg bg-[#0F2245] hover:bg-[#0A1A36] text-white text-[15px] font-medium transition-colors">
                    Sign In
                </button>
            </form>
        </div>

        <p class="mt-6 text-center text-xs text-white/40">© 2026 CanvasBid. All rights reserved.</p>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('password');
            const eyeOpen = document.getElementById('eye-open');
            const eyeClosed = document.getElementById('eye-closed');
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            eyeOpen.classList.toggle('hidden', show);
            eyeClosed.classList.toggle('hidden', !show);
        }
    </script>
</body>

</html>