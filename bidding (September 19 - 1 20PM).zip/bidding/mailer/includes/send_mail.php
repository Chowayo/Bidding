<?php
/**
 * General-purpose email sender for the app.
 * Uses the PHPMailer already installed via Composer (vendor/autoload.php).
 *
 * Usage (from any page):
 *
 *     require_once __DIR__ . '/../mailer/includes/send_mail.php';
 *
 *     $result = send_email(
 *         'someone@example.com',              // to
 *         'Invoice INV-1024 Approved',        // subject
 *         '<p>Your invoice has been approved.</p>' // body (HTML allowed)
 *     );
 *
 *     if ($result['success']) {
 *         // sent
 *     } else {
 *         // $result['error'] has the reason
 *     }
 *
 * Optional extras:
 *
 *     send_email('someone@example.com', 'Subject', 'Body', [
 *         'cc'          => ['finance@example.com'],
 *         'bcc'         => ['audit@example.com'],
 *         'attachments' => ['/path/to/file.pdf'],
 *         'from_name'   => 'Finance Team',
 *         'is_html'     => true, // default true; set false for plain text
 *     ]);
 */

// Adjust this path if your phpmailer/ folder lives somewhere else relative to this file.
// Assumes this layout at your project root:
//   project-root/
//   ├── phpmailer/vendor/autoload.php   ← Composer-installed PHPMailer
//   ├── mailer/includes/send_mail.php   ← this file
//   └── ...
require_once __DIR__ . '/../../phpmailer/vendor/autoload.php';
require_once __DIR__ . '/../config/mail_config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Send an email via Gmail SMTP.
 *
 * @param string|array $to      A single email address, or an array of them.
 * @param string       $subject Email subject line.
 * @param string       $body    Email body. HTML by default (see $options['is_html']).
 * @param array        $options {
 *     @type array  $cc          Additional recipients (CC).
 *     @type array  $bcc         Hidden recipients (BCC).
 *     @type array  $attachments Absolute file paths to attach.
 *     @type string $from_name   Overrides the default "From" display name.
 *     @type bool   $is_html     Whether $body is HTML. Default true.
 *     @type string $alt_body    Plain-text fallback when $is_html is true.
 * }
 * @return array{success: bool, error: ?string}
 */
function send_email($to, string $subject, string $body, array $options = []): array
{
    $mail = new PHPMailer(true);

    try {
        // --- Server settings ---
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = MAIL_PASSWORD;
        $mail->SMTPSecure = MAIL_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;

        // --- Sender ---
        $mail->setFrom(MAIL_FROM_ADDRESS, $options['from_name'] ?? MAIL_FROM_NAME);

        // --- Recipients ---
        foreach ((array) $to as $address) {
            $mail->addAddress($address);
        }
        foreach ($options['cc'] ?? [] as $address) {
            $mail->addCC($address);
        }
        foreach ($options['bcc'] ?? [] as $address) {
            $mail->addBCC($address);
        }

        // --- Attachments ---
        foreach ($options['attachments'] ?? [] as $path) {
            if (is_file($path)) {
                $mail->addAttachment($path);
            }
        }

        // --- Content ---
        $isHtml = $options['is_html'] ?? true;
        $mail->isHTML($isHtml);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        if ($isHtml) {
            $mail->AltBody = $options['alt_body'] ?? strip_tags($body);
        }

        $mail->send();
        return ['success' => true, 'error' => null];

    } catch (PHPMailerException $e) {
        return ['success' => false, 'error' => $mail->ErrorInfo ?: $e->getMessage()];
    }
}
